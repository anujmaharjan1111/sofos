<?php
// Sync all product details between SwiftPOS and WooCommerce (images excluded).
ignore_user_abort(true);

// If cron doesn't doesn't execute correctly remove the following lines
$isRunningFromBrowser = !isset($GLOBALS['argv']);
if($isRunningFromBrowser == true){
	die();
}

// Don't make any changes below.
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );


$reupload_images = false;

$location = JVA__Functions::get_swiftpos_creds('locationId');
$user = JVA__Functions::get_swiftpos_creds('userId');
$pass = JVA__Functions::get_swiftpos_creds('password');

$sync = new SwiftPOS_Sync();
$ApiKey = $sync->assign_api_key($location, $user, $pass);
if($ApiKey == true){
	$response = $sync->sync_products($reupload_images);
	return $response;
}
