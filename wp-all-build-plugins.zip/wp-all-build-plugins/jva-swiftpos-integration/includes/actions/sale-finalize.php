<?php
// Process a new sale to SwiftPOS, this is set to run after order has been made in WooCommerce (cannot be executed with cron).

ignore_user_abort(true);

$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );


$order_id = $_POST['order_id'];
if(!empty($order_id)){
	
	$location = JVA__Functions::get_swiftpos_creds('locationId');
	$user = JVA__Functions::get_swiftpos_creds('userId');
	$pass = JVA__Functions::get_swiftpos_creds('password');
		
	$sync = new SwiftPOS_Sync();
	$ApiKey = $sync->assign_api_key($location, $user, $pass);
	if($ApiKey == true){
		$response = $sync->make_sale($order_id);
		return $response;
	}
}