(function($) {
	$(function() {
		$('select#swiftpos--select2').select2({
			allowClear: true
		})
	})
})(jQuery);
