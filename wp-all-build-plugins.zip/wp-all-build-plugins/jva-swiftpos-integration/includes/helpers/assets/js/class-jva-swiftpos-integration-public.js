jQuery(document).ready(function($) {
	function shippingNotice() {
		var notice = $('#jva-shipping-notice .jva-top-message')
		
		$.ajax({
			url 		: localizedVars.ajax_url,
			method  	: 'POST',
			dataType 	: 'json',
			data 		: {
				action 		: localizedVars.actions.getShippingNotice
			},
			beforeSend  : () => {
				notice.block({
					message 	: null,
					overlayCSS 	: {
						backgroundColor : '#fff'
					}
				})
			},
			success 	: (response) => {
				if( response.status ) {
					notice.show().html(response.text)
				} else {
					notice.hide()
				}
			},
			error  		: (error) => {
				console.log(error)
			}
		})
	}
	
	$(document).on('updated_wc_div updated_cart_totals', function(){
		shippingNotice()
	})
});

(function($) {
$(window).load(function() {
 
$('#mobile_menu > .menu-item-has-children > a').attr('href', 'javascript:void(0)');
$('#mobile_menu > .menu-item-has-children > a').each(function() {
$(this).next('.sub-menu').addClass('hide');
});
 
$('#mobile_menu > .menu-item-has-children > a').click(function(event) {
	event.preventDefault();
	event.stopPropagation();
	$(this).next('.sub-menu').toggleClass('visible');
	$(this).toggleClass('expanded-menu');
	 $('#et-top-navigation .mobile_menu_bar').trigger('click');
});

$('#mobile_menu > .menu-item-has-children > .sub-menu > .menu-item-has-children > a').attr('href', 'javascript:void(0)');
$('#mobile_menu > .menu-item-has-children > .sub-menu > .menu-item-has-children > a').each(function() {
$(this).next('.sub-menu').addClass('hide');
});
 
$('#mobile_menu > .menu-item-has-children > .sub-menu > .menu-item-has-children > a').click(function(event) {
	event.preventDefault();
	event.stopPropagation();
	$(this).next('.sub-menu').toggleClass('visible');
	$(this).toggleClass('expanded-menu');
	 $('#et-top-navigation .mobile_menu_bar').trigger('click');
});

 
});
})(jQuery);