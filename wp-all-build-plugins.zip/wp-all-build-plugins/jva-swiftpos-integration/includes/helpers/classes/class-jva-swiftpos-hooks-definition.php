<?php

class swiftpos_hooks_definition{
		public function __construct(){
			if(file_exists(PLUGIN_BASE_PATH . 'includes/classes/class-jva-swiftpos-connector.php')){
				require_once PLUGIN_BASE_PATH . 'includes/classes/class-jva-swiftpos-connector.php';
			}
			if(file_exists(PLUGIN_BASE_PATH . 'includes/class-jva-swiftpos-sync.php')){
				require_once PLUGIN_BASE_PATH . 'includes/class-jva-swiftpos-sync.php';
			}
			$this->_define_all_hooks();
		}

		private function _define_all_hooks(){
				// add_action('wp_ajax_jva_ajax', array($this, 'jva_ajax_callback_wp'));
				// add_action('wp_ajax_nopriv_jva_ajax', array($this, 'jva_ajax_callback_wp'));
				
				// add_action('woocommerce_thankyou', array($this, 'jva_order_thankyou'));
				// add_action( 'init', array($this, 'product_taxonomy_brand'));
				// add_action( 'woocommerce_product_meta_end',  array($this,'action_product_meta_end'));
				
				add_action('wp_ajax_jva_sync_product', array($this, 'jva_sync_product'));
				add_action('wp_ajax_jva_before_sync_product', array($this, 'jva_before_sync_product'));
				add_action('wp_ajax_jva_after_sync_product', array($this, 'jva_after_sync_product'));
				
				// // define the woocommerce_review_order_before_payment callback 		
				// add_action('woocommerce_checkout_process', array($this , 'jva_match_cart_quantity_with_swiftpost'));
				// add_action( 'woocommerce_thankyou',array($this , 'jva_action_swiftpos_make_sale'), 10, 1);
				
				// add_action('wp_ajax_nopriv_swiftpost_jva_ajax_product_sync', array($this, 'swiftpost_jva_ajax_product_sync'));
				// add_action('wp_ajax_swiftpost_jva_ajax_product_sync', array($this, 'swiftpost_jva_ajax_product_sync'));
				
				// add_action('wp_ajax_jva_product_sync_ajax', array($this, 'jva_ajax_product_sync'),10,3);
				// add_action('wp_ajax_nopriv_jva_product_sync_ajax', array($this, 'jva_ajax_product_sync'),10,3);

				// // CHECKING
				// add_action('wp_ajax_jva_product_sync_ajax2', array($this, 'jva_ajax_product_sync2'),10,3);
				// add_action('wp_ajax_nopriv_jva_product_sync_ajax2', array($this, 'jva_ajax_product_sync2'),10,3);
				// // CHECKING
				
				// add_action('wp_ajax_jva_product_inventory_sync_ajax', array($this, 'jva_ajax_product_inventory_sync'),10,3);
				// add_action('wp_ajax_nopriv_jva_product_inventory_sync_ajax', array($this, 'jva_ajax_product_inventory_sync'),10,3);
				
				
				// add_action('wp_ajax_nopriv_jvaWPAJAXGetShippingNotice', array($this, 'jvaWPAJAXGetShippingNotice'));
				// add_action('wp_ajax_jvaWPAJAXGetShippingNotice', array($this, 'jvaWPAJAXGetShippingNotice'));
				
				// add_filter('woocommerce_countries', array($this, 'jvaWooCountries'));
				// add_filter('woocommerce_states', array($this, 'jvaWooStates'));
				
				// add_action('init', array($this,'custom_filter_override'), 100);
				// add_filter( 'woocommerce_cart_subtotal', array($this, 'wc_apply_filter_checkout_for_coupons'), 9999999, 3 );
				// add_action( 'woocommerce_checkout_create_order', array($this, 'wc_before_woocommerce_checkout_create_order_for_coupons'), 9999999, 2);
				// add_action( 'woocommerce_order_status_on-hold', array($this, 'sync_SwiftPOS_Order'), 999, 1);
				// add_action( 'woocommerce_order_status_processing', array($this, 'sync_SwiftPOS_Order'), 999, 1);
		}

		public function jva_ajax_callback_wp() {
			wp_die();
		}

		public function jva_order_thankyou($order_id) {
				// Trigger a new sale on SwiftPOS and async order items stock.
				$url = PLUGIN_BASE_URL . 'includes/actions/sale-finalize.php';
				$params = array('order_id' => $order_id);
				$this->post_async($url, $params);
		}

		public function product_taxonomy_brand()  {
			$labels = array(
				'name'                       => 'Brands',
				'singular_name'              => 'Brand',
				'menu_name'                  => 'Brands',
				'all_items'                  => 'All Brands',
				'parent_item'                => 'Parent Brand',
				'parent_item_colon'          => 'Parent Brand:',
				'new_item_name'              => 'New Brand Name',
				'add_new_item'               => 'Add New Brand',
				'edit_item'                  => 'Edit Brand',
				'update_item'                => 'Update Brand',
				'separate_items_with_commas' => 'Separate Brand with commas',
				'search_items'               => 'Search Brands',
				'add_or_remove_items'        => 'Add or remove Brands',
				'choose_from_most_used'      => 'Choose from the most used Brands',
			);
			$args = array(
				'labels'                     => $labels,
				'hierarchical'               => true,
				'public'                     => true,
				'show_ui'                    => true,
				'show_admin_column'          => true,
				'show_in_nav_menus'          => true,
				'show_tagcloud'              => true,
			);
			register_taxonomy( 'brand', 'product', $args );
			register_taxonomy_for_object_type( 'brand', 'product' );
		}

		function action_product_meta_end() {
			global $product;
			$term_ids = wp_get_post_terms( $product->get_id(), 'brand', array('fields' => 'ids') );
			echo get_the_term_list( $product->get_id(), 'brand', '<span class="posted_in">' . _n( 'Brand:', 'Brands:', count( $term_ids ), 'woocommerce' ) . ' ', ', ', '</span>' );
		}

		public function jva_sync_product()  { 
			if ( !wp_verify_nonce( $_REQUEST['nonce'], "jva_ajax_sync_product")) {
				exit("No naughty business please");
			}
			$reupload_images = false;
			if($_REQUEST["reupload_images"] == 'true'){
				$reupload_images = true;
			}
			$offset = $_REQUEST["offset"];
			$limit = $_REQUEST["limit"];
			$force_sync = $_REQUEST["force_sync"];
			$syncWarehouse = $_REQUEST['sync_warehouse'];
			// $SwiftPOS_Sync = new SwiftPOS_Sync();
			// $SwiftPOS_Sync->ajax_sync_products($reupload_images, $force_sync, $offset, $limit, $syncWarehouse);
			$SwiftPOS_Sync = new jva_swiftpos_connector();
			$SwiftPOS_Sync->ajax_sync_products($reupload_images, $force_sync, $offset, $limit, $syncWarehouse);
		}

		public function jva_before_sync_product()  { 
			if ( !wp_verify_nonce( $_REQUEST['nonce'], "jva_ajax_sync_product")) {
				exit("No naughty business please");
			}
			$warehouse = $_REQUEST['warehouse'];
			if($warehouse != '') {
				$allWarehouse = explode(',', $warehouse);
				foreach($allWarehouse as $house) {
					update_option($house."_variationSync", 'false');
				}
			} 
			$SwiftPOS_Sync = new SwiftPOS_Sync();
			$SwiftPOS_Sync->ajax_before_sync_products();
		}

		public function jva_after_sync_product()  { 
			if ( !wp_verify_nonce( $_REQUEST['nonce'], "jva_ajax_sync_product")) {
				exit("No naughty business please");
			}
			$syncWarehouse = array();
			$warehouse = $_REQUEST['warehouse'];
			if($warehouse != '') {
				$allWarehouse = explode(',', $warehouse);
				foreach($allWarehouse as $house) { 
					$syncValue = get_option($house."_variationSync",true);
					if($syncValue == 'JVA' || $syncValue == 'Melbourne' || $syncValue == 'JAA') {
						$syncWarehouse[] = $syncValue;
					}
				}
			}
			sort($syncWarehouse); 
			sort($allWarehouse);
			if(count($syncWarehouse) == 3 ) {
				$SwiftPOS_Sync = new SwiftPOS_Sync();
				$SwiftPOS_Sync->ajax_after_sync_products();
			}
			//added by websupreme
	        $SwiftPOS_Sync = new SwiftPOS_Sync();
	        $SwiftPOS_Sync->heal_product_after_sync($allWarehouse);
		}

		public function jva_match_cart_quantity_with_swiftpost() {
	        global $woocommerce;
			$items = $woocommerce->cart->get_cart();
			$error = false;
			$notice = '';
			
	        foreach($items as $item => $values) {
	            $cartProduct =  wc_get_product( $values['data']->get_id()); 
				$productId = $values['product_id'];
				$variationId = $values['variation_id'];
	            $produtTitle = $cartProduct->get_title();
				$productQuantity = $values['quantity'];
	            $productPrice = get_post_meta($values['product_id'] , '_price', true);
				if($variationId != 0 && $variationId != '') {
					$result = $this->checkSwiftPostProductInventory($variationId, $produtTitle, $productQuantity);
				} else {
					$result = $this->checkSwiftPostProductInventory($productId, $produtTitle, $productQuantity);
				}
				if(!empty($result)) {
					$notice .= $result['notice'];
					$error = $result['error'];
				}
	        }
	        if($error) {
	            wc_add_notice($notice, 'error');
	        }
	    }

	    public function jva_action_swiftpos_make_sale(  $order_id ) {
			$_swiftpos_sale = get_post_meta( $order_id, '_swiftpost_sale_id', true);
			if ($_swiftpos_sale == '') {
				$this->make_swiftpost_sale($order_id);
			}
		}

		public function swiftpost_jva_ajax_product_sync(){
			self::clean_swiftpost_data();
			update_option("sync_cron_offset", '');
			update_option("sync_cron_limit", '');
			update_option("variationSync", '');
			$SwiftPOS_Sync = new SwiftPOS_Sync();
			$reupload_images = false;
			$force_sync = 'true';
			$syncResult = $SwiftPOS_Sync->ajax_sync_products_cron_start($reupload_images, $force_sync);
			wp_die();
		}

	public function jva_ajax_product_sync2($offset = '', $limit = '', $force_sync = false){
        global $woocommerce;
        $syncWarehouse = 'JVA';
        echo 'Synching Warehouse: '.$syncWarehouse.'<br>';
        switch ( $syncWarehouse ){
            case 'Melbourne':
                $location = self::get_swiftpos_creds_melbourne('locationId');
                $user = self::get_swiftpos_creds_melbourne('userId');
                $pass = self::get_swiftpos_creds_melbourne('password');
            break;
            case 'JVA' :
                $location = self::get_swiftpos_creds('locationId');
                $user = self::get_swiftpos_creds('userId');
                $pass = self::get_swiftpos_creds('password');
            break;
            case 'JAA':
                $location = self::get_swiftpos_creds_just_automiser('locationId');
                $user = self::get_swiftpos_creds_just_automiser('userId');
                $pass = self::get_swiftpos_creds_just_automiser('password');
            break;
        }

        $supplierData = self::getSupplier($location);
        if(!empty($supplierData)) {
            $supplierId = $supplierData->ID;
            $supplierName = $supplierData->post_title;
        }
        
        $sync = new SwiftPOS_Sync();
        $ApiKey = $sync->assign_api_key2($location, $user, $pass);
        
        echo "<br>-----1-----<br>";
        var_dump($ApiKey);
        echo "<br>-----1-----<br>";

        $allProducts = $this->get_all_products();

		if (!empty($allProducts)) {
			if($ApiKey == true){
				$i = 1;
				foreach($allProducts as $product) {
					$i++;
					$productId = $product->ID;
					$productObject = wc_get_product( $productId );

					if ($productObject->product_type == 'variable') {
						$productVariations = $productObject->get_available_variations();
						if(!empty($productVariations)) {
							foreach($productVariations as $variation) {
								
								$productTypeSKU = substr($variation['sku'], 7 ,1);
								
								// CHECK IF PRODUCT IS COIL
								if($productTypeSKU != false && strlen($productTypeSKU) == 1 && is_numeric($productTypeSKU) && ($productTypeSKU == 3 )) {
									
									$variationId = $productObject->get_id();

									$prodSKU = $productObject->get_sku();

									$typeSKU = substr($variation['sku'], 10 ,3);

									$packingSKU = substr($variation['sku'], 8 ,1);

									//$packingSKU = substr($variation['sku'], 8 ,1);

									$coil_box_products_ids = get_option('coil_box_products_ids_' . $prodSKU . '_' . $typeSKU, []);

									$function =  "Product/" . $coil_box_products_ids[0] . "";
									$data = '';
									$product_details = $sync->request($sync->key, $data, $function);

									echo "<br>-------------<br>";
									var_dump($product_details);
									echo "<br>-------------<br>";

									if(!empty($product_details)) {
										
										$boxes = [
											'A' 	=> 15,
											'B'		=> 30,
											'C'		=> 50,
											'D'		=> 100
										];

										$iinventorySStock = $product_details->StockLevel;
										if($iinventorySStock == null){ $iinventorySStock = 0; }
										elseif(empty($iinventorySStock)){ $iinventorySStock = 0; }
										elseif( $iinventorySStock < 0 ){ $iinventorySStock = 0; }

										$box_actual_stock = floatval(abs($iinventorySStock)) * floatval($boxes[$packingSKU]);

										if(!empty($box_actual_stock)){
											$inventory = floatval($box_actual_stock) / floatval($packingSKU);
										}
										else{
											$inventory = 0;
										}

										// update_post_meta( $variationId, '_stock', $inventory );

										$stockStatus = ($inventory > 0) ? 'instock' : 'outofstock';

										self::updateProductAutumInventory($variationId,  $supplierId, $supplierName, $inventory, $stockStatus);
										
									}

								} else {
									$variationId = $variation['variation_id'];
									$variationSwiftPosId = get_post_meta($variationId, 'swiftpost_id', true);
									$function =  "Product/".$variationSwiftPosId."";
									$data = '';
									$product_details = $sync->request($sync->key, $data, $function);
									echo "<br>-------------<br>";
									var_dump($product_details);
									echo "<br>-------------<br>";
									if(!empty($product_details)) {
										$inventory = $product_details->StockLevel;
										if($inventory == null){ $inventory = 0; }
										elseif(empty($inventory)){ $inventory = 0; }
										elseif( $inventory < 0 ){ $inventory = 0; }

										$sku = $product_details->InventoryCode;
										// update_post_meta( $variationId, '_stock', $inventory );
										$stockStatus = ($inventory > 0) ? 'instock' : 'outofstock';
										self::updateProductAutumInventory($variationId,  $supplierId, $supplierName, $inventory, $stockStatus);
									}
								}

								
							}
						}
					} else {
						$swiftPosId = get_post_meta($productId, 'swiftpost_id', true);
						$function =  "Product/".$swiftPosId."";
						$data = '';
						$product_details = $sync->request($sync->key, $data, $function);
						echo "<br>-------------<br>";
									var_dump($product_details);
									echo "<br>-------------<br>";
						if(!empty($product_details)) {
							$inventory = $product_details->StockLevel;
							if($inventory == null){ $inventory = 0; }
							elseif(empty($inventory)){ $inventory = 0; }
							elseif( $inventory < 0 ){ $inventory = 0; }

							$sku = $product_details->InventoryCode;
							$stockStatus = ($inventory > 0) ? 'instock' : 'outofstock';
							self::updateProductAutumInventory($productId,  $supplierId, $supplierName, $inventory, $stockStatus);
						}
					}
				}
			}

		}
		echo "Done"; die();
	}

	public function jva_ajax_product_inventory_sync(){
		global $woocommerce;
		$syncWarehouse = get_option("cronInventorySyncWarehouse", true);
		if($syncWarehouse == '') {
			update_option("cronInventorySyncWarehouse","Melbourne");
			$syncWarehouse = 'Melbourne';
		}
		echo 'Synching Warehouse: '.$syncWarehouse.'<br>';
		switch ( $syncWarehouse ){
			case 'Melbourne':
				$location = self::get_swiftpos_creds_melbourne('locationId');
				$user = self::get_swiftpos_creds_melbourne('userId');
				$pass = self::get_swiftpos_creds_melbourne('password');
			break;
			case 'JVA' :
				$location = self::get_swiftpos_creds('locationId');
				$user = self::get_swiftpos_creds('userId');
				$pass = self::get_swiftpos_creds('password');
			break;
			case 'JAA':
				$location = self::get_swiftpos_creds_just_automiser('locationId');
				$user = self::get_swiftpos_creds_just_automiser('userId');
				$pass = self::get_swiftpos_creds_just_automiser('password');
			break;
		}

		$supplierData = self::getSupplier($location);
		if(!empty($supplierData)) {
			$supplierId = $supplierData->ID;
			$supplierName = $supplierData->post_title;
		}
		
		$sync = new SwiftPOS_Sync();
		$ApiKey = $sync->assign_api_key($location, $user, $pass);
		$allProducts = $this->get_all_products();
		if (!empty($allProducts)) {
			if($ApiKey == true){
				$i = 1;
				foreach($allProducts as $product) {
					$i++;
					$productId = $product->ID;
					$productObject = wc_get_product( $productId );

					if ($productObject->product_type == 'variable') {
						$productVariations = $productObject->get_available_variations();
						if(!empty($productVariations)) {
							foreach($productVariations as $variation) {
								
								$productTypeSKU = substr($variation['sku'], 7 ,1);
								
								// CHECK IF PRODUCT IS COIL
								if($productTypeSKU != false && strlen($productTypeSKU) == 1 && is_numeric($productTypeSKU) && ($productTypeSKU == 3 )) {
									
									$variationId = $productObject->get_id();

									$prodSKU = $productObject->get_sku();

									$typeSKU = substr($variation['sku'], 10 ,3);

									$packingSKU = substr($variation['sku'], 8 ,1);

									//$packingSKU = substr($variation['sku'], 8 ,1);

									$coil_box_products_ids = get_option('coil_box_products_ids_' . $prodSKU . '_' . $typeSKU, []);

									$function =  "Product/" . $coil_box_products_ids[0] . "";
									$data = '';
									$product_details = $sync->request($sync->key, $data, $function);

									if(!empty($product_details)) {
										
										$boxes = [
											'A' 	=> 15,
											'B'		=> 30,
											'C'		=> 50,
											'D'		=> 100
										];

										$iinventorySStock = $product_details->StockLevel;
										if($iinventorySStock == null){ $iinventorySStock = 0; }
										elseif(empty($iinventorySStock)){ $iinventorySStock = 0; }
										elseif( $iinventorySStock < 0 ){ $iinventorySStock = 0; }

										$box_actual_stock = floatval(abs($iinventorySStock)) * floatval($boxes[$packingSKU]);

										if(!empty($box_actual_stock)){
											$inventory = floatval($box_actual_stock) / floatval($packingSKU);
										}
										else{
											$inventory = 0;
										}

										// update_post_meta( $variationId, '_stock', $inventory );

										$stockStatus = ($inventory > 0) ? 'instock' : 'outofstock';

										self::updateProductAutumInventory($variationId,  $supplierId, $supplierName, $inventory, $stockStatus);
										
									}

								} else {
									$variationId = $variation['variation_id'];
									$variationSwiftPosId = get_post_meta($variationId, 'swiftpost_id', true);
									$function =  "Product/".$variationSwiftPosId."";
									$data = '';
									$product_details = $sync->request($sync->key, $data, $function);
									if(!empty($product_details)) {
										$inventory = $product_details->StockLevel;
										if($inventory == null){ $inventory = 0; }
										elseif(empty($inventory)){ $inventory = 0; }
										elseif( $inventory < 0 ){ $inventory = 0; }

										$sku = $product_details->InventoryCode;
										// update_post_meta( $variationId, '_stock', $inventory );
										$stockStatus = ($inventory > 0) ? 'instock' : 'outofstock';
										self::updateProductAutumInventory($variationId,  $supplierId, $supplierName, $inventory, $stockStatus);
									}
								}

								
							}
						}
					} else {
						$swiftPosId = get_post_meta($productId, 'swiftpost_id', true);
						$function =  "Product/".$swiftPosId."";
						$data = '';
						$product_details = $sync->request($sync->key, $data, $function);
						if(!empty($product_details)) {
							$inventory = $product_details->StockLevel;
							if($inventory == null){ $inventory = 0; }
							elseif(empty($inventory)){ $inventory = 0; }
							elseif( $inventory < 0 ){ $inventory = 0; }

							$sku = $product_details->InventoryCode;
							$stockStatus = ($inventory > 0) ? 'instock' : 'outofstock';
							self::updateProductAutumInventory($productId,  $supplierId, $supplierName, $inventory, $stockStatus);
						}
					}
				}
			}
			if($syncWarehouse == 'Melbourne') {
				update_option("cronInventorySyncWarehouse","JVA");
			} else if ($syncWarehouse == 'JVA') {
				update_option("cronInventorySyncWarehouse","JAA");
			} else {
				update_option("cronInventorySyncWarehouse","Melbourne");
			}
		}
	}

	public function jvaWPAJAXGetShippingNotice() {
		$freeShipping = get_option('woocommerce_free_shipping_settings');
		$freeShippingMin = $freeShipping['min_amount'];
		$freeShippingMin = !empty($freeShippingMin) ? $freeShippingMin : 100;
		
		$cartSubtotal = WC()->cart->subtotal;
		
		$response = [
			'status' 			=> 0,
			'text' 				=> '',
			'free_shipping_min' => $freeShippingMin,
			'cart_subtotal' 	=> $cartSubtotal
		];
		
		if( $cartSubtotal < $freeShippingMin || $cartSubtotal == 0 ) {
			$response['status'] = 1;
			$response['text'] = $cartSubtotal < $freeShippingMin ? 'Spend an additional '. wc_price($freeShippingMin - $cartSubtotal) .', and get free shipping.' : 'Free shipping of orders over '. wc_price($freeShippingMin);
		}elseif($cartSubtotal >= $freeShippingMin){
			$response['status'] = 1;
			$response['text'] =  'Congratulations, you will now receive free shipping for your order';
		}

		
		wp_send_json($response);
	}

	public function jvaWooCountries($countries) {
		if( is_admin() )
			return $states;
			
		$excludedStates = get_option('swiftpos_exc_states');
		
		if( $excludedStates && (0 < count($excludedStates)) ) :
			foreach( $excludedStates as $state => $regions ) :
				if( is_array($regions) ) continue;
		
				unset($countries[$state]);
			endforeach;
		endif;

		return $countries;
	}

	public function jvaWooStates($states) {
		if( is_admin() )
			return $states;
			
		$excludedStates = get_option('swiftpos_exc_states');
		
		if( $excludedStates && (0 < count($excludedStates)) ) :
			foreach( $excludedStates as $state => $regions ) :
				if( !is_array($regions) ) continue;
		
				foreach( $regions as $region ) :
					unset($states[$state][$region]);
				endforeach;
			endforeach;
		endif;

		return $states;
	}

	public function custom_filter_override(){
		add_filter('woocommerce_placeholder_img_src', array($this,'custom_woocommerce_placeholder_img_src'));
		add_filter( 'woocommerce_placeholder_img', array($this,'wcdi_replace_wc_placeholder_img'),100,3);
	}

	public function wc_apply_filter_checkout_for_coupons( $subtotal, $compound, $cart_object ) {


        // Your logic to get store credit value for a user will go here
        $store_credit = 0;
        $total_price = 0;
        // This is necessary for WC 3.0+
	    if (is_admin() && ! defined( 'DOING_AJAX' ) )
	        return;

	    if(!$this->is_cart_price_rules_enabled())
	    	return;
	    // Avoiding hook repetition (when using price calculations for example)
	    if ( did_action( 'woocommerce_before_calculate_totals' ) >= 2 )
	        return;
	    
	    $cart_items = $cart_object->cart_contents;
	    $cart_price_rules = $this->get_cart_price_rules();

	  	if ( !empty( $cart_items ) && !empty($cart_price_rules) ) {
	  			$passed_rules = array();
				foreach ( $cart_object->get_cart() as $hash => $value ) {

					// Skip applying rules if Cart product is on sale
					 if(!empty($value['data']->get_sale_price()) && $value['data']->get_sale_price() < $value['data']->get_regular_price()){
					 	continue;
					 }
		 			foreach ($cart_price_rules as $key => $rule) {
		 				
		 				$product_cat_ids = wp_get_post_terms($value['product_id'],'product_cat',array('fields'=>'ids'));
		 				$common_cat = array_intersect($rule['product_category'], $product_cat_ids );
		 				if(empty($rule['product_category'])	|| (is_array($rule['product_category']) && 
		 					count($common_cat) >=1 )
		 				){
		 					$variations_on_rule = array();
		 					
		 					if(!empty($rule["size"])){
		 						$variations_on_rule[] = $rule["size"]->slug;
		 					}

		 					if(empty($variations_on_rule) || 
		 						(!empty($value["variation"]["attribute_pa_size"])  && in_array($value["variation"]["attribute_pa_size"], $variations_on_rule) )
		 					){
		 						$rule_cat = $common_cat[0];
		 						foreach ($common_cat as $r_cat) {
		 							$t_details = get_term($r_cat, 'product_cat');
									if(!empty($t_details->parent)){
										$rule_cat = $t_details->parent; // parent category id or $t_details->category_parent
									}
		 						}

		 						$rule_key = 'cat_'.$rule_cat.'_size_'.$value["variation"]["attribute_pa_size"];
		 						//$rule_key = $key;

		 						if(isset($passed_rules[$rule_key]["rule_passed_qty"])){
		 							
		 							if(!in_array($value['variation_id'], $passed_rules[$rule_key]['rule_passed_variation_ids'])){
		 								$passed_rules[$rule_key]['rule_passed_qty'] += $value['quantity'];
		 								$passed_rules[$rule_key]['rule_passed_variation_ids'][] = $value['variation_id'];
		 							}
		 						}else{
			 						
		 							$passed_rules[$rule_key]['rule_passed_qty'] = $value['quantity'];
		 							$passed_rules[$rule_key]['rule_passed_variation_ids'][] = $value['variation_id'];
		 						}
		 						$passed_rules[$rule_key]['rule_qty_arr'][] = $rule['product_quantity'];
		 						$passed_rules[$rule_key]['rules']['qty_'.$rule['product_quantity']] = $rule;
		 						
		 					}
		 				}

		 			}
				}

				if(!empty($passed_rules)){

					foreach ($passed_rules as $key => $passed_rule) {
						$rule_passed_qty_arr = array_unique($passed_rule['rule_qty_arr']);
						$rule_passed_qty_arr[] = 1;
						$qty_subset = $this->generate_combinational_sum($rule_passed_qty_arr, $passed_rule['rule_passed_qty']);
						$passed_rules[$key]['qty_subset'] = $qty_subset;
					}
					//var_dump($passed_rules);
					$arr_skip = array();
					foreach ( $cart_object->get_cart() as $hash => $value ) {
						// Skip applying rules if Cart product is on sale
						$product_cat_ids = wp_get_post_terms($value['product_id'],'product_cat',array('fields'=>'ids'));
						$total_price_added = 0;
			 			foreach ($product_cat_ids as $cat) {
			 				$t_details = get_term($r_cat, 'product_cat');

			 				if(empty($t_details))
			 					continue;

			 				$r_key = 'cat_'.$t_details->term_id.'_size_'.$value["variation"]["attribute_pa_size"];

			 				if(is_array($passed_rules[$r_key]['qty_subset']) && !empty($passed_rules[$r_key]['rules'])){
			 					foreach ($passed_rules[$r_key]['qty_subset'] as $s_key => $r_qty) {
			 						if(!empty($passed_rules[$r_key]['rules']['qty_'.$r_qty]) && !in_array($r_key.$s_key, $arr_skip)){
			 							$total_price += $passed_rules[$r_key]['rules']['qty_'.$r_qty]['product_price'];
			 							$arr_skip[] = $r_key.$s_key;
			 						}elseif($r_qty == 1 && !in_array($r_key.$s_key, $arr_skip)){
			 							$total_price += $value['data']->get_regular_price();
			 							$arr_skip[] = $r_key.$s_key;
			 						}
			 						$total_price_added = 1;
			 					}
			 				}elseif(is_array($passed_rules[$r_key]['rule_passed_variation_ids']) && in_array($value['variation_id'],  $passed_rules[$r_key]['rule_passed_variation_ids'])){
			 					$total_price_added = 1;
			 				}
			 			}

			 			if(!$total_price_added ){
			 				$total_price += $value['data']->get_regular_price() * intval($value['quantity']);
			 			}
			 			//$total_price = $value['data']->get_regular_price() * intval($value['quantity']);
					}

				$store_credit = $cart_object->subtotal - $total_price;
				//var_dump($store_credit, $cart_object->subtotal, $total_price);
				if($store_credit){
		            // Setup our virtual coupon
		            $coupon_name = 'bundle-discount';
		            $coupon = array($coupon_name => $store_credit);

		            // Apply the store credit coupon to the cart & update totals
		            $cart_object->applied_coupons = array($coupon_name);
		            $cart_object->set_discount_total($store_credit);
		            $cart_object->set_total( $cart_object->total - $store_credit);
		            $cart_object->coupon_discount_totals = $coupon;
		        }

				}



	     }

	        // We only need to add a store credit coupon if they have store credit
	    return $subtotal; 
	}

	public function wc_before_woocommerce_checkout_create_order_for_coupons( $order, $cart_object ) {
$cart_object = WC()->cart;
//var_dump($order, $cart_object); die;
        // Your logic to get store credit value for a user will go here
        $store_credit = 0;
        $total_price = 0;
        // This is necessary for WC 3.0+
	    if (is_admin() && ! defined( 'DOING_AJAX' ) )
	        return;

	    if(!$this->is_cart_price_rules_enabled())
	    	return;
	    // Avoiding hook repetition (when using price calculations for example)
	    if ( did_action( 'woocommerce_before_calculate_totals' ) >= 2 )
	        return;
	    
	    $cart_items = $cart_object->cart_contents;
	    $cart_price_rules = $this->get_cart_price_rules();

	  	if ( !empty( $cart_items ) && !empty($cart_price_rules) ) {
	  			$passed_rules = array();
				foreach ( $cart_object->get_cart() as $hash => $value ) {

					// Skip applying rules if Cart product is on sale
					 if(!empty($value['data']->get_sale_price()) && $value['data']->get_sale_price() < $value['data']->get_regular_price()){
					 	continue;
					 }
		 			foreach ($cart_price_rules as $key => $rule) {
		 				
		 				$product_cat_ids = wp_get_post_terms($value['product_id'],'product_cat',array('fields'=>'ids'));
		 				$common_cat = array_intersect($rule['product_category'], $product_cat_ids );
		 				if(empty($rule['product_category'])	|| (is_array($rule['product_category']) && 
		 					count($common_cat) >=1 )
		 				){
		 					$variations_on_rule = array();
		 					
		 					if(!empty($rule["size"])){
		 						$variations_on_rule[] = $rule["size"]->slug;
		 					}

		 					if(empty($variations_on_rule) || 
		 						(!empty($value["variation"]["attribute_pa_size"])  && in_array($value["variation"]["attribute_pa_size"], $variations_on_rule) )
		 					){
		 						$rule_cat = $common_cat[0];
		 						foreach ($common_cat as $r_cat) {
		 							$t_details = get_term($r_cat, 'product_cat');
									if(!empty($t_details->parent)){
										$rule_cat = $t_details->parent; // parent category id or $t_details->category_parent
									}
		 						}

		 						$rule_key = 'cat_'.$rule_cat.'_size_'.$value["variation"]["attribute_pa_size"];
		 						//$rule_key = $key;

		 						if(isset($passed_rules[$rule_key]["rule_passed_qty"])){
		 							
		 							if(!in_array($value['variation_id'], $passed_rules[$rule_key]['rule_passed_variation_ids'])){
		 								$passed_rules[$rule_key]['rule_passed_qty'] += $value['quantity'];
		 								$passed_rules[$rule_key]['rule_passed_variation_ids'][] = $value['variation_id'];
		 							}
		 						}else{
			 						
		 							$passed_rules[$rule_key]['rule_passed_qty'] = $value['quantity'];
		 							$passed_rules[$rule_key]['rule_passed_variation_ids'][] = $value['variation_id'];
		 						}
		 						$passed_rules[$rule_key]['rule_qty_arr'][] = $rule['product_quantity'];
		 						$passed_rules[$rule_key]['rules']['qty_'.$rule['product_quantity']] = $rule;
		 						
		 					}
		 				}

		 			}
				}

				if(!empty($passed_rules)){

					foreach ($passed_rules as $key => $passed_rule) {
						$rule_passed_qty_arr = array_unique($passed_rule['rule_qty_arr']);
						$rule_passed_qty_arr[] = 1;
						$qty_subset = $this->generate_combinational_sum($rule_passed_qty_arr, $passed_rule['rule_passed_qty']);
						$passed_rules[$key]['qty_subset'] = $qty_subset;
					}
					//var_dump($passed_rules);
					$arr_skip = array();
					foreach ( $cart_object->get_cart() as $hash => $value ) {
						// Skip applying rules if Cart product is on sale
						$product_cat_ids = wp_get_post_terms($value['product_id'],'product_cat',array('fields'=>'ids'));
						$total_price_added = 0;
			 			foreach ($product_cat_ids as $cat) {
			 				$t_details = get_term($r_cat, 'product_cat');

			 				if(empty($t_details))
			 					continue;

			 				$r_key = 'cat_'.$t_details->term_id.'_size_'.$value["variation"]["attribute_pa_size"];

			 				if(is_array($passed_rules[$r_key]['qty_subset']) && !empty($passed_rules[$r_key]['rules'])){
			 					foreach ($passed_rules[$r_key]['qty_subset'] as $s_key => $r_qty) {
			 						if(!empty($passed_rules[$r_key]['rules']['qty_'.$r_qty]) && !in_array($r_key.$s_key, $arr_skip)){
			 							$total_price += $passed_rules[$r_key]['rules']['qty_'.$r_qty]['product_price'];
			 							$arr_skip[] = $r_key.$s_key;
			 						}elseif($r_qty == 1 && !in_array($r_key.$s_key, $arr_skip)){
			 							$total_price += $value['data']->get_regular_price();
			 							$arr_skip[] = $r_key.$s_key;
			 						}
			 						$total_price_added = 1;
			 					}
			 				}elseif(is_array($passed_rules[$r_key]['rule_passed_variation_ids']) && in_array($value['variation_id'],  $passed_rules[$r_key]['rule_passed_variation_ids'])){
			 					$total_price_added = 1;
			 				}
			 			}

			 			if(!$total_price_added ){
			 				$total_price += $value['data']->get_regular_price() * intval($value['quantity']);
			 			}
			 			//$total_price = $value['data']->get_regular_price() * intval($value['quantity']);
					}

				$store_credit = $cart_object->subtotal - $total_price;


				//var_dump($store_credit, $cart_object->subtotal, $total_price);
				if($store_credit){
		            // Setup our virtual coupon
		            $coupon_name = 'bundle-discount';
		            $coupon = array($coupon_name => $store_credit);

		            // Apply the store credit coupon to the cart & update totals
		            $cart_object->applied_coupons = array($coupon_name);
		            $cart_object->set_discount_total($store_credit);
		            $cart_object->set_total( $cart_object->total - $store_credit);
		            $cart_object->coupon_discount_totals = $coupon;


		            $order->set_discount_total( $cart_object->get_discount_total() );
					$order->set_discount_tax($cart_object->get_discount_tax() );
					$order->set_total( $cart_object->get_total( 'edit' ) );
					$order->save();
		        }

				}



	     }

	        // We only need to add a store credit coupon if they have store credit
	    return $subtotal; 
	}

	public function sync_SwiftPOS_Order( $order_id ){
	    update_post_meta(67602, '_order_custom_data', 'payment_done-'. date('Y-m-d H:i:s'));
	}
		
}

$swiftpos_hooks_definition = new swiftpos_hooks_definition();


?>