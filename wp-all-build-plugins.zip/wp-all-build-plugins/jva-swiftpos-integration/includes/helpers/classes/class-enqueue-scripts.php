<?php

class enqueue_scripts{
		public function __construct(){
			add_action('admin_enqueue_scripts', array($this, 'enqueue_styles_admin'));
			add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts_admin'));
			add_action('wp_enqueue_scripts', array($this, 'enqueue_styles_public'));
			add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts_public'));
		}

		public function enqueue_styles_admin(){
			wp_enqueue_style( 'jva-select2', PLUGIN_BASE_URL . 'includes/helpers/assets/css/select2.min.css', array(), $this->version, 'all' );
			wp_enqueue_style( 'jva-managment', PLUGIN_BASE_URL . 'includes/helpers/assets/css/class-jva-swiftpos-integration-admin.css', array(), $this->version, 'all' );
		}

		public function enqueue_scripts_admin(){
			wp_register_script('jva-select2', PLUGIN_BASE_URL . 'includes/helpers/assets/js/select2.min.js', array('jquery'), $this->version, FALSE);
			wp_enqueue_script( 'jva-custom-js', PLUGIN_BASE_URL . 'includes/helpers/assets/js/class-jva-swiftpos-integration-admin.js', array( 'jquery', 'jva-select2' ), $this->version, false );
		}

		public function enqueue_styles_public(){
			wp_enqueue_style( 'jva-managment', PLUGIN_BASE_URL . 'includes/helpers/assets/css/class-jva-swiftpos-integration-public.css', array(), $this->version, 'all' );
		}

		public function enqueue_scripts_public(){
			wp_enqueue_script( 'jva-man', PLUGIN_BASE_URL . 'includes/helpers/assets/js/class-jva-swiftpos-integration-public.js', array( 'jquery' ), $this->version, false );
			$localizations = array( 
				'ajax_url' => admin_url( 'admin-ajax.php'), 
				'plugin_url' =>  plugin_dir_url( __FILE__ ),
				'actions' 		=> array(
					'getShippingNotice' 	=> 'jvaWPAJAXGetShippingNotice'
				)
			);
			wp_localize_script( 'jva-man', 'localizedVars', $localizations );
		}
}

$enqueue_scripts = new enqueue_scripts();


?>