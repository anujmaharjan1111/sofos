<?php

class wp_admin_pages_controller{
		public function __construct(){
			$this->_create_admin_pages();
		}

		private function _create_admin_pages(){
			add_action('admin_menu', array($this, 'swiftpost_integration_admin_page'));
		}

		public function swiftpost_integration_admin_page() {
			 add_menu_page('SwiftPOS Integration','SwiftPOS','manage_options','swiftpost-integration',array($this, 'swiftpost_integration_callback'),'');
			
			add_submenu_page( 'swiftpost-integration', 'Manage Products', 'Manage Products', 'manage_options', 'swiftpost-products', array($this, 'swiftpost_integration_category_callback'));

			add_submenu_page( 'swiftpost-integration', 'Manage States/Regions', 'Manage States/Regions', 'manage_options', 'swiftpost-states', array($this, 'swiftpost_integration_states_callback'));

			add_submenu_page( 'swiftpost-integration', 'Settings', 'Settings', 'manage_options', 'swiftpost-creds', array($this, 'swiftpost_integration_creds_callback'));
			
			add_submenu_page( 'swiftpost-integration', 'API Test', 'API Test', 'manage_options', 'swiftpost-apitest', array($this, 'swiftpost_integration_apitest_callback'));

			if( function_exists('acf_add_options_page') ) {
				$option_page = acf_add_options_page(array(
					'page_title' 		=> 'Lookup Options',
					'menu_title' 		=> 'Lookup Options',
					'menu_slug' 		=> 'lookup-options',
					'position' 			=> true,
					'parent_slug'		=> 'swiftpost-integration',
					'capability' 		=> 'edit_posts',
					'autoload' 			=> true,
					'update_button'		=> __('Update', 'acf'),
					'updated_message'	=> __("Lookup Data Updated", 'acf'),
					'redirect'			=> false
				));

				$cart_rules_page = acf_add_options_page(array(
					'page_title' 		=> 'Cart Rules',
					'menu_title' 		=> 'Cart Rules',
					'menu_slug' 		=> 'cart-rules',
					'position' 			=> true,
					'parent_slug'		=> 'swiftpost-integration',
					'capability' 		=> 'edit_posts',
					'autoload' 			=> true,
					'update_button'		=> __('Update', 'acf'),
					'updated_message'	=> __("Cart Rules Updated", 'acf'),
					'redirect'			=> false
				));
			}
			
		}

			/**
	 *  SwiftPOS integration page callback (swiftpost_integration_admin_page)
	 *
	 * @since    1.0.0
	 */	
	public function swiftpost_integration_callback() {
			if(file_exists(PLUGIN_BASE_PATH . 'includes/helpers/views/admin/swift-pos-integration.php')){
				require_once PLUGIN_BASE_PATH . 'includes/helpers/views/admin/swift-pos-integration.php';
			}	
	}

	public function swiftpost_integration_category_callback() {
			if(file_exists(PLUGIN_BASE_PATH . 'includes/helpers/views/admin/swift-pos-manage-products.php')){
				require_once PLUGIN_BASE_PATH . 'includes/helpers/views/admin/swift-pos-manage-products.php';
			}
	}

	public function swiftpost_integration_states_callback() {
			if(file_exists(PLUGIN_BASE_PATH . 'includes/helpers/views/admin/swift-pos-state-integration.php')){
				require_once PLUGIN_BASE_PATH . 'includes/helpers/views/admin/swift-pos-state-integration.php';
			}
	}

	public function swiftpost_integration_creds_callback() {
			if(file_exists(PLUGIN_BASE_PATH . 'includes/helpers/views/admin/swift-pos-settings.php')){
				require_once PLUGIN_BASE_PATH . 'includes/helpers/views/admin/swift-pos-settings.php';
			}
	}

	public function swiftpost_integration_apitest_callback (){
			if(file_exists(PLUGIN_BASE_PATH . 'includes/helpers/views/admin/swift-pos-apit-test.php')){
				require_once PLUGIN_BASE_PATH . 'includes/helpers/views/admin/swift-pos-apit-test.php';
			}
	}
}

$wp_admin_pages_controller = new wp_admin_pages_controller();


?>