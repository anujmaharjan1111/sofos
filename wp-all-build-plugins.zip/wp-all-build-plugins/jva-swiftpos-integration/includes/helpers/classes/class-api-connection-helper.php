<?php

class jva_api_connection_helper{
	function __construct(){

	}

	public static function get_swiftpos_creds($key) {
		$creds = get_option( 'swiftpos_creds' );
		if($key == 'locationId'){
			return (int)$creds['locationId'];
		}elseif($key == 'userId'){
			return (int)$creds['userId'];
		}elseif($key == 'password'){
			return $creds['password'];
		}
		return false;
	}

	public static function get_swiftpos_creds_melbourne($key) {
		$creds = get_option( 'swiftpos_creds_melbourne' );
		if($key == 'locationId'){
			return (int)$creds['melbourne_locationId'];
		}elseif($key == 'userId'){
			return (int)$creds['melbourne_userId'];
		}elseif($key == 'password'){
			return $creds['melbourne_password'];
		}
		return false;
	}

	public static function get_swiftpos_creds_just_automiser($key) {
		$creds = get_option( 'swiftpos_creds_jaa' );
		if($key == 'locationId'){
			return (int)$creds['jaa_locationId'];
		}elseif($key == 'userId'){
			return (int)$creds['jaa_userId'];
		}elseif($key == 'password'){
			return $creds['jaa_password'];
		}
		return false;
	}
	
}

?>