<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>	
<style>
	div#swiftpost_integration, div#swiftpost_integration_sync  {
		background: #fff;
		padding: 30px;
		margin-top: 20px;
		box-shadow: 0 0px 19px rgba(130, 130, 130, 0.12), 0 1px 4px rgba(132, 132, 132, 0.16);
	}
	ul {
		list-style: inside;
	}
	.divider {
		border-top: 3px solid #f1f1f1;
	}
	#swiftpost_integration h1 {
		font-size: 2em !important; 
		margin: .67em 0 !important; 
	}
	#swiftpost_integration h3 {
		font-size: 1.3em !important; 
		margin: 1em 0 !important; 
	}
	#swiftpost_integration label {
		margin-bottom: 0px !important;
		vertical-align: -webkit-baseline-middle !important;
	}
	.progress {
		margin-bottom: 5px !important;
	}
</style>
	<div id="swiftpost_integration">
		<h1>SwiftPOS Synchronization</h1>
			<h3>The button below will sync the following:</h3>
				<ul>
					<li>Product information</li>
					<li>Stock of items</li>
					<li>Client information</li>
				</ul>
			<form method="post" enctype="multipart/form-data">
							<input type='hidden' id='sync_swiftpost' name='sync_swiftpost' value="sync" />
							<label for="warehouse">
								<b><span style="position:relative;top: -2px;">Select Warehouse:</span></b>
							</label>
							<input type='checkbox' id='sync_warehouse_melbourne' name='sync_warehouse[]' value="Melbourne" checked="checked" disabled /> 
							<span style="position:relative;top: 3px;">Melbourne</span>
							<input type='checkbox' id='sync_warehouse_jva' name='sync_warehouse[]' value="JVA" checked="checked" disabled /> 
							<span style="position:relative;top: 3px;">Just Vapours Australia</span>
							<input type='checkbox' id='sync_warehouse_jaa' name='sync_warehouse[]' value="JAA" checked="checked" disabled />
							<span style="position:relative;top: 3px;">Just Atomisers Australia </span>
							<br/>
							<label for="reupload_images">
								<b><span style="position:relative;top: -2px;">Re-upload images for existing products:</span></b>
							</label>
							<input type='checkbox' id='reupload_images' name='reupload_images' value="image_refresh" />
							<br/>
							<label for="sync_swiftpost">
								<b><span style="position:relative;top: -2px;">Force Sync SwiftApi: </span></b>
							</label>
							<input type='checkbox' id='reupload_images' name='force_sync' value="image_refresh" />
							<?php //submit_button('Start Synchronization', 'primary', 'submit', true ); ?>
					</form>
					<div>&nbsp;</div>
					<p class="asyncButton">
						<?php 
						update_option("variationSync", "");
						$nonce = wp_create_nonce("jva_ajax_sync_product");
						$link = admin_url('admin-ajax.php?action=jva_sync_product&nonce='.$nonce);
						echo '<a class="button button-primary" href="javascript:void(0)">Start Synchronization</a>';
						?>
					</p>
					<div class="sync progress hidden">
						<div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width:0%">
						  0% Completed
						</div>
					</div>
					<p class="Synched"></p>
					<p class="loading hidden">Syncing <b><span class="warehouse"></span> Warehouse</b> Products, Please wait <img style="vertical-align:bottom;" src="<?php echo plugins_url(); ?>/jva-swiftpos-integration/includes/images/loader.gif" /></p>
					
					
				<?php
				if(!empty($_POST['sync_swiftpost']) && $_POST['sync_swiftpost'] == 'sync'){
					$reupload_images = !empty($_POST['reupload_images']) ? true : false;
					$force_sync = !empty($_POST['force_sync']) ? true : false;
					$sync = $this->swiftpost_synchronization_callback($reupload_images,$force_sync);
					if($sync->status == true){
						?>
							<div class="divider"></div>
							<p style="font-weight:bold; color:green;">Synchronization was successfully completed</p>
							<?php echo $sync->msg; ?>
						<?php
					}else{
						?>
							<div class="divider"></div>
							<p style="font-weight:bold; color:red;">Synchronization was not successfully completed</p>
							<?php echo $sync->msg; ?>
						<?php
					}
				}
				?>
				</div>
				<div id="swiftpost_integration_sync" class="hidden">
					<p class="sync logs hidden">Sync Logs :</p>
					<p class="statusSync"></p>
				</div>
				<script>
					jQuery(document).ready(function(){
						jQuery(".asyncButton").click(function(){
							var updateTotal = '<?php update_option("totalVariation",""); ?>';
							var warehouseTitle = { 'JVA' : 'Just Vapours Australia', 'Melbourne': 'Melbourne', 'JAA' : 'Just Atomisers Australia'};
							var offset = 0;
							var limit = 5;
							jQuery("p.statusSync").html("");
							jQuery(".sync.progress .progress-bar").css("width","0%");
							jQuery(".sync.progress .progress-bar").html("0% Completed");
							var force_sync =  jQuery('input[name="force_sync"]'). prop("checked");
							var syncWarehouseJva = jQuery('input#sync_warehouse_jva'). prop("checked");
							var syncWarehouseMelbourne = jQuery('input#sync_warehouse_melbourne'). prop("checked");
							var syncWarehouseJaa = jQuery('input#sync_warehouse_jaa'). prop("checked");
							var syncWarehouse = [];
							if(syncWarehouseMelbourne) { 
								syncWarehouse.push('Melbourne');
							}
							if(syncWarehouseJva) { 
								syncWarehouse.push('JVA');
							}
							if(syncWarehouseJaa) { 
								syncWarehouse.push('JAA');
							}
							updateAllProductMeta(syncWarehouse);
							var warehouse = syncWarehouse[0];
							if(warehouse != '' && warehouse != undefined) {
								jQuery("p.statusSync").append('Syncing Warehouse :<b>' + warehouseTitle[warehouse] + '</b><br/>');
								do_ajax(offset, limit, force_sync, warehouse, syncWarehouse);
							} else {
								jQuery("p.statusSync").append('Please select a warehouse.<br/>');
							}
						});
						function do_ajax(offset, limit, force_sync, warehouse, syncWarehouse) {
							var warehouseTitle = { 'JVA' : 'Just Vapours Australia', 'Melbourne': 'Melbourne', 'JAA' : 'Just Atomisers Australia'};
							jQuery("p.asyncButton").addClass("hidden");
							jQuery("p.loading").removeClass("hidden");
							jQuery("p.loading span.warehouse").html(warehouseTitle[warehouse]);
							jQuery(".sync.progress").removeClass("hidden");
							jQuery("#swiftpost_integration_sync").removeClass("hidden");
							jQuery(".sync.logs").removeClass("hidden");
							var reupload_images =  jQuery('input[name="reupload_images"]'). prop("checked");
							jQuery.ajax({
								url: '<?php echo $link; ?>&force_sync='+force_sync+'&reupload_images='+reupload_images+'&sync_warehouse='+warehouse+'&offset='+offset+'&limit='+limit,
								success: function(result){
									var result = JSON.parse(result);
									if(result != undefined) {
										var msg = result['msg'];
										var variation = result['variation'];
										var totalVariation =  result['totalVariation'];
										var status = result['status'];
										if(status == false) {
											jQuery("p.loading").addClass("hidden");
										}
										
										console.log(result);
										console.log(warehouse+' - '+totalVariation);
										
										jQuery("p.statusSync").append(msg);
										if(parseFloat(variation) >= parseFloat(totalVariation)) {
											jQuery(".sync.progress .progress-bar").css("width","100%");
											jQuery(".sync.progress .progress-bar").html("100% Completed");
											if(warehouse == 'Melbourne' && syncWarehouse[0] == 'Melbourne' && syncWarehouse[1] != '' && syncWarehouse[1] != undefined) {
												jQuery("p.Synched").append(warehouseTitle[warehouse]+ " 100% Completed. <br>");
												warehouse = syncWarehouse[1];
												offset = 0;
												limit = 5;
												jQuery(".sync.progress .progress-bar").css("width","0%");
												jQuery(".sync.progress .progress-bar").html("0% Completed");
												force_sync =  jQuery('input[name="force_sync"]'). prop("checked");
												jQuery("p.statusSync").append('Syncing Warehouse :<b>' + warehouseTitle[warehouse] + '</b><br/>');
												do_ajax(offset, limit, force_sync, warehouse, syncWarehouse);
											} else if(warehouse == 'JVA' && syncWarehouse[0] == 'JVA' && syncWarehouse[1] != '' && syncWarehouse[1] != undefined) {
												jQuery("p.Synched").append(warehouseTitle[warehouse]+ " 100% Completed. <br>");
												warehouse = syncWarehouse[1];
												offset = 0;
												limit = 5;
												jQuery(".sync.progress .progress-bar").css("width","0%");
												jQuery(".sync.progress .progress-bar").html("0% Completed");
												force_sync =  jQuery('input[name="force_sync"]'). prop("checked");
												jQuery("p.statusSync").append('Syncing Warehouse :<b>' + warehouseTitle[warehouse] + '</b><br/>');
												do_ajax(offset, limit, force_sync, warehouse, syncWarehouse);
											} else if(warehouse == 'JVA' && syncWarehouse[1] == 'JVA' && syncWarehouse[2] != '' && syncWarehouse[2] != undefined) {
												jQuery("p.Synched").append(warehouseTitle[warehouse]+ " 100% Completed. <br>");
												warehouse = syncWarehouse[2];
												offset = 0;
												limit = 5;
												jQuery(".sync.progress .progress-bar").css("width","0%");
												jQuery(".sync.progress .progress-bar").html("0% Completed");
												force_sync =  jQuery('input[name="force_sync"]'). prop("checked");
												jQuery("p.statusSync").append('Syncing Warehouse :<b>' + warehouseTitle[warehouse] + '</b><br/>');
												do_ajax(offset, limit, force_sync, warehouse, syncWarehouse);
											}else {
												jQuery("p.Synched").append(warehouseTitle[warehouse]+ " 100% Completed. <br>");
												jQuery("p.asyncButton").removeClass("hidden");
												jQuery("p.loading").addClass("hidden");
											}
										} else if(variation <= limit && parseFloat(variation) < parseFloat(totalVariation)) {
											var percentageCompleted = (parseFloat(variation) / parseFloat(totalVariation))*100;
											jQuery(".sync.progress .progress-bar").css("width",percentageCompleted+"%");
											jQuery(".sync.progress .progress-bar").html(parseFloat(percentageCompleted).toFixed(0)+" % Completed");
											offset = offset + 5;
											limit = limit + 5;
											force_sync = false
											do_ajax(offset, limit, force_sync, warehouse, syncWarehouse);
										}
									} else {
										jQuery("p.loading").addClass("hidden");
										jQuery(".sync.progress .progress-bar").addClass("hidden");
										jQuery("p.asyncButton").removeClass("hidden");
									}
									
								},
								complete: function(result){
									trashProduct(syncWarehouse);
								}
							});
						}
						
						function updateAllProductMeta(syncWarehouse){
							jQuery.ajax({
								url: '<?php echo admin_url("admin-ajax.php?action=jva_before_sync_product&nonce=".$nonce); ?>&warehouse='+syncWarehouse,
								success: function(result){
									console.log(result);
								}
							});
						}
						
						function trashProduct(syncWarehouse){
							jQuery.ajax({
								url: '<?php echo admin_url("admin-ajax.php?action=jva_after_sync_product&nonce=".$nonce); ?>&warehouse='+syncWarehouse,
								success: function(result){
									console.log(result);
								}
							});
						}

					});
				</script>
			<?php