<?php
global $pagenow;
		if(!empty($_POST)){
			if(isset($_POST['wharehouse']) && $_POST['wharehouse'] == 'jva') {
				$locationId = isset($_POST['locationId']) ? $_POST['locationId'] : "";
				$userId = isset($_POST['userId']) ? $_POST['userId'] : "";
				$password = isset($_POST['password']) ? $_POST['password'] : "";

				$swiftpos_creds = array(
									'locationId'=> $locationId,
									'userId'=> $userId,
									'password'=> $password,
									);
									
				update_option( 'swiftpos_creds', $swiftpos_creds );
			}
			if(isset($_POST['wharehouse']) && $_POST['wharehouse'] == 'melbourne') {
				$locationId = isset($_POST['melbourne_locationId']) ? $_POST['melbourne_locationId'] : "";
				$userId = isset($_POST['melbourne_userId']) ? $_POST['melbourne_userId'] : "";
				$password = isset($_POST['melbourne_password']) ? $_POST['melbourne_password'] : "";

				$swiftpos_creds = array(
									'melbourne_locationId'=> $locationId,
									'melbourne_userId'=> $userId,
									'melbourne_password'=> $password,
									);
									
				update_option( 'swiftpos_creds_melbourne', $swiftpos_creds );
			}
			
			if(isset($_POST['wharehouse']) && $_POST['wharehouse'] == 'jaa') {
				$locationId = isset($_POST['jaa_locationId']) ? $_POST['jaa_locationId'] : "";
				$userId = isset($_POST['jaa_userId']) ? $_POST['jaa_userId'] : "";
				$password = isset($_POST['jaa_password']) ? $_POST['jaa_password'] : "";

				$swiftpos_creds = array(
									'jaa_locationId'=> $locationId,
									'jaa_userId'=> $userId,
									'jaa_password'=> $password,
									);
									
				update_option( 'swiftpos_creds_jaa', $swiftpos_creds );
			}
		}
		
		$creds = get_option( 'swiftpos_creds' );
		$melbourne_creds = get_option( 'swiftpos_creds_melbourne' );
		$jaa_creds = get_option( 'swiftpos_creds_jaa' );
?>
		<style>
		div#swiftpost_integration {
			background: #fff;
			padding: 30px;
			margin-top: 20px;
			box-shadow: 0 0px 19px rgba(130, 130, 130, 0.12), 0 1px 4px rgba(132, 132, 132, 0.16);
		}
		ul {
			list-style: inside;
		}
		.divider {
			border-top: 3px solid #f1f1f1;
		}
		</style>
		<div id="swiftpost_integration">
			<h1>SwiftPOS Settings</h1>
			<h3>Authenticatation details:</h3>
			<h2 class="nav-tab-wrapper">
				<?php if ( isset ( $_GET['tab'] ) ) $tab = $_GET['tab']; else $tab = 'jva'; ?>
				<a class='nav-tab <?php echo ( $tab == "jva" ) ? " nav-tab-active" : "";?>' href='?page=swiftpost-creds&tab=jva'>Just Vapours Australia (Main Wharehouse)</a>
				<a class='nav-tab <?php echo ( $tab == "melbourne" ) ? " nav-tab-active" : "";?>' href='?page=swiftpost-creds&tab=melbourne'>Melbourne Wharehouse</a>
				<a class='nav-tab <?php echo ( $tab == "jaa" ) ? " nav-tab-active" : "";?>' href='?page=swiftpost-creds&tab=jaa'>Just Atomisers Australia Wharehouse</a>
			</h2>
			<?php 
				if ( $pagenow == 'admin.php' && $_GET['page'] == 'swiftpost-creds' ){
					if ( isset ( $_GET['tab'] ) ) $tab = $_GET['tab']; 
					else $tab = 'jva';
					?>
					<table class="form-table">
						<?php
						switch ( $tab ){
							case 'jva' :
						?>
								<tr>
									<th>Just Vapours Australia (Main Wharehouse)</th>
								</tr>
								<tr>
									<td>
										<form method="post" enctype="multipart/form-data">
											<input type="hidden" name="wharehouse" value="jva"/>
											<p>
												<label for="locationId"><b><span style="position:relative;top: -2px;display:block;">Location to request an api key for :</span></b></label>
												<input type='text' id='locationId' name='locationId' value="<?php if(isset($creds['locationId'])){ echo $creds['locationId']; } ?>" placeholder="locationId"></input>
											</p>
											<p>
												<label for="userId"><b><span style="position:relative;top: -2px;display:block;">Clerk Id:</span></b></label>
												<input type='text' id='userId' name='userId' value="<?php if(isset($creds['userId'])){ echo $creds['userId']; } ?>" placeholder="userId"></input>
											</p>
											<p>
												<label for="locationId"><b><span style="position:relative;top: -2px;display:block;">Clerk Password:</span></b></label>
												<input type='text' id='password' name='password' value="<?php if(isset($creds['password'])){ echo $creds['password']; } ?>" placeholder="password"></input>
											</p>
												<?php submit_button('Save') ?>
										</form>
									</td>
								</tr>
							<?php break; 
							case 'melbourne':
							?>
								<tr>
									<th>Melbourne Wharehouse</th>
								</tr>
								<tr>
									<td>
										<form method="post" enctype="multipart/form-data">
											<input type="hidden" name="wharehouse" value="melbourne"/>
											<p>
												<label for="melbourne_locationId"><b><span style="position:relative;top: -2px;display:block;">Location to request an api key for :</span></b></label>
												<input type='text' id='melbourne_locationId' name='melbourne_locationId' value="<?php if(isset($melbourne_creds['melbourne_locationId'])){ echo $melbourne_creds['melbourne_locationId']; } ?>" placeholder="locationId"></input>
											</p>
											<p>
												<label for="melbourne_userId"><b><span style="position:relative;top: -2px;display:block;">Clerk Id:</span></b></label>
												<input type='text' id='melbourne_userId' name='melbourne_userId' value="<?php if(isset($melbourne_creds['melbourne_userId'])){ echo $melbourne_creds['melbourne_userId']; } ?>" placeholder="userId"></input>
											</p>
											<p>
												<label for="melbourne_locationId"><b><span style="position:relative;top: -2px;display:block;">Clerk Password:</span></b></label>
												<input type='text' id='melbourne_password' name='melbourne_password' value="<?php if(isset($melbourne_creds['melbourne_password'])){ echo $melbourne_creds['melbourne_password']; } ?>" placeholder="password"></input>
											</p>
												<?php submit_button('Save') ?>
										</form>
									</td>
								</tr>
							<?php
								break; 
							case 'jaa':
							?>
								<tr>
									<th>Just Atomisers Australia Wharehouse</th>
								</tr>
								<tr>
									<td>
										<form method="post" enctype="multipart/form-data">
											<input type="hidden" name="wharehouse" value="jaa"/>
											<p>
												<label for="jaa_locationId"><b><span style="position:relative;top: -2px;display:block;">Location to request an api key for :</span></b></label>
												<input type='text' id='jaa_locationId' name='jaa_locationId' value="<?php if(isset($jaa_creds['jaa_locationId'])){ echo $jaa_creds['jaa_locationId']; } ?>" placeholder="locationId"></input>
											</p>
											<p>
												<label for="jaa_userId"><b><span style="position:relative;top: -2px;display:block;">Clerk Id:</span></b></label>
												<input type='text' id='jaa_userId' name='jaa_userId' value="<?php if(isset($jaa_creds['jaa_userId'])){ echo $jaa_creds['jaa_userId']; } ?>" placeholder="userId"></input>
											</p>
											<p>
												<label for="jaa_locationId"><b><span style="position:relative;top: -2px;display:block;">Clerk Password:</span></b></label>
												<input type='text' id='jaa_password' name='jaa_password' value="<?php if(isset($jaa_creds['jaa_password'])){ echo $jaa_creds['jaa_password']; } ?>" placeholder="password"></input>
											</p>
												<?php submit_button('Save') ?>
										</form>
									</td>
								</tr>
							<?php
						}
						?>		
					</table>
			<?php } ?>
		</div>