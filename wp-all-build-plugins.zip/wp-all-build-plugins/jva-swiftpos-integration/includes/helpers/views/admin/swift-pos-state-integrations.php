<?php
global $woocommerce;
		
		if( isset($_POST['swiftpos_exc_states']) && $_POST['swiftpos_exc_states'] ) :
			$excStatesArr = [];
			$excStates = $_POST['swiftpos_exc_states'];
		
			if( 0 < count($excStates) ) :
				foreach( $excStates as $state ) :
					if( strpos($state, '--') ) :
						$state = explode('--', $state);
		
						$excStatesArr[$state[0]][] = $state[1];
					else :
						$excStatesArr[$state] = '';
					endif;
				endforeach;
			endif;
		
			update_option('swiftpos_exc_states', $excStatesArr);
		endif;
	?>
		<style>
		div#swiftpost_integration {
			background: #fff;
			padding: 30px;
			margin-top: 20px;
			box-shadow: 0 0px 19px rgba(130, 130, 130, 0.12), 0 1px 4px rgba(132, 132, 132, 0.16);
		}
		ul {
			list-style: inside;
		}
		.divider {
			border-top: 3px solid #f1f1f1;
		}
		p.submit {
			display: inline-block;
			margin: 0px;
			margin-left: 5px;
		}
		</style>
		<div id="swiftpost_integration">
			<h1>Manage States/Regions</h1>
			<h3>Exclude states or regions</h3>
			<form method="post" enctype="multipart/form-data">
				<?php 
				$wcCountries = new WC_Countries();
				$countries = $wcCountries->__get('countries');
				$defaultCountry = $wcCountries->get_base_country();
				$excludedStates = get_option('swiftpos_exc_states');
				?>
				<select id="swiftpos--select2" name="swiftpos_exc_states[]" multiple>
					<?php 
					foreach( $countries as $countryCode => $country ) :
						$states = $wcCountries->get_states($countryCode); 
						
						if( $states ) :
					?>
						<optgroup label="<?php echo $country; ?>">
					<?php
							foreach( $states as $stateCode => $state ) :
						?>
							<option value="<?php echo $countryCode.'--'. $stateCode; ?>" <?php echo array_key_exists($countryCode, $excludedStates) && in_array($stateCode, $excludedStates[$countryCode]) ? 'selected=""' : ''; ?>><?php echo $state; ?></option>
						<?php 
							endforeach; 
					?>
						</optgroup>	
					<?php
						else :
						?>
						<option value="<?php echo $countryCode; ?>" <?php echo array_key_exists($countryCode, $excludedStates) ? 'selected=""' : ''; ?>><?php echo $country; ?></option>
						<?php
						endif; 
					endforeach; 
					?>
				</select>
				
				<div class="clear"></div>
				<?php submit_button('Save', 'save', 'save' ) ?>
			</form>

		</div>
	<?php