<table class="form-table">
			<tr>
				<td>
					<form method="post" enctype="multipart/form-data">
						<select name="wharehouse" >
							<option value="JVA">Just Vapours Australia</option>
							<option value="Melbourne">Melbourne</option>
							<option value="JAA">Just Atomisers Australia</option>
						</select>
						<?php submit_button('Save'); ?>
					</form>
				</td>
			</tr>
		</table>
		<?php
		if(isset($_POST) && $_POST['wharehouse'] == 'JVA') {
			$key = 0;
			$location = self::get_swiftpos_creds('locationId');
			$user = self::get_swiftpos_creds('userId');
			$pass = self::get_swiftpos_creds('password');
			$sync = new SwiftPOS_Sync();
			$ApiKey = $sync->assign_api_key($location, $user, $pass);
			if($ApiKey == true){
				$family = $sync->get_family();
				if($family == false){
					return false;
				}
				$data = array('includeImage' => true, 'familyId'=> $family[0]);
				$all_products = $sync->request($sync->key, $data, "Product");
			}
		} else if(isset($_POST) && $_POST['wharehouse'] == 'Melbourne') {
			$key = 0;
			$location = self::get_swiftpos_creds_melbourne('locationId');
			$user = self::get_swiftpos_creds_melbourne('userId');
			$pass = self::get_swiftpos_creds_melbourne('password');
			$sync = new SwiftPOS_Sync();
			$ApiKey = $sync->assign_api_key($location, $user, $pass);
			if($ApiKey == true){
				$family = $sync->get_family();
				if($family == false){
					return false;
				}
				$data = array('includeImage' => true, 'familyId'=> $family[0]);
				$all_products = $sync->request($sync->key, $data, "Product");
			}
		} else if(isset($_POST) && $_POST['wharehouse'] == 'JAA') {
			$key = 0;
			$location = self::get_swiftpos_creds_just_automiser('locationId');
			$user = self::get_swiftpos_creds_just_automiser('userId');
			$pass = self::get_swiftpos_creds_just_automiser('password');
			$sync = new SwiftPOS_Sync();
			$ApiKey = $sync->assign_api_key($location, $user, $pass);
			if($ApiKey == true){
				$family = $sync->get_family();
				if($family == false){
					return false;
				}
				$data = array('includeImage' => true, 'familyId'=> $family[0]);
				$all_products = $sync->request($sync->key, $data, "Product");
			}
		}
		echo '<br>Location: '.$location;
		echo '<br>User: '.$user;
		echo '<br>Pass: '.$pass;
		echo '<br>ApiKey: '.$ApiKey;
		echo '<br>family: '; print_r($family);
		echo '<br>Data: '; print_r($data);
		echo '<br>All Products: '; 
		echo '<pre>';
		print_r($all_products);
		echo '</pre>';