<?php
// if(!empty($_POST)){
// 			$selected_cat = $_POST['category-select'];
			
// 			$args = array(
// 			'post_type'             => 'product',
// 			'post_status'           => 'publish',
// 			'posts_per_page'        => -1,
// 			'tax_query'             => array(
// 					array(
// 						'taxonomy'      => 'product_cat',
// 						'field' 		=> 'term_id', //This is optional, as it defaults to 'term_id'
// 						'terms'         => $selected_cat,
// 						'operator'      => 'IN' // Possible values are 'IN', 'NOT IN', 'AND'.
// 					),
// 				)
// 			);
		

// 			if( !empty($_POST['publish']) ){
// 				$args['post_status'] = 'draft';
// 				$products = new WP_Query($args);
				
// 				while ( $products->have_posts() ) { $products->the_post();
// 					global $product; 
// 					$product_id = $product->get_id();
					
// 					wp_update_post(array(
// 						'ID'    =>  $product_id,
// 						'post_status'   =>  'publish'
// 					));
// 				}
// 				wp_reset_query(); 
				
// 				echo '<p style="color:green;">Product in the selected category were successfully published</p>';

// 			}elseif( !empty($_POST['unpublish']) ){
// 				$products = new WP_Query($args);
				
// 				while ( $products->have_posts() ) { $products->the_post();
// 					global $product; 
// 					$product_id = $product->get_id();
// 					wp_update_post(array(
// 						'ID'    =>  $product_id,
// 						'post_status'   =>  'draft'
// 					));
// 				}
// 				wp_reset_query(); 
// 				echo '<p style="color:green;">Product in the selected category were successfully unpublished</p>';
// 			}
// 		}
		
?>
<style>
	div#swiftpost_integration {
	    background: #fff;
	    padding: 30px;
	    margin-top: 20px;
	    box-shadow: 0 0px 19px rgba(130, 130, 130, 0.12), 0 1px 4px rgba(132, 132, 132, 0.16);
	}
	ul {
	    list-style: inside;
	}
	.divider {
	    border-top: 3px solid #f1f1f1;
	}
	p.submit {
	    display: inline-block;
	    margin: 0px;
	    margin-left: 5px;
	}
</style>
<div id="swiftpost_integration">
	<h1>Manage Products status</h1>
	<h3>Publish or unpublish product of a specific category</h3>

	<form method="post" enctype="multipart/form-data">
		<?php
		$taxonomy     = 'product_cat';
		$orderby      = 'name';  
		$show_count   = 0;      // 1 for yes, 0 for no
		$pad_counts   = 0;      // 1 for yes, 0 for no
		$hierarchical = 1;      // 1 for yes, 0 for no  
		$empty        = 0;

		$args = array(
			 'taxonomy'     => $taxonomy,
			 'orderby'      => $orderby,
			 'show_count'   => $show_count,
			 'pad_counts'   => $pad_counts,
			 'hierarchical' => $hierarchical,
			 'hide_empty'   => $empty
		);
		$all_categories = get_categories( $args );
		echo '<label for="category-select" class="cat-select">Category: </label>';
		echo '<select id="category-select" name= "category-select" >';
		foreach ($all_categories as $cat) {
			if($cat->category_parent == 0) {
				$category_slug = $cat->slug;
				echo '<option value="'. $cat->term_id .'">'. $cat->name .'</option>';
			}
		}
		echo '</select>';
		?>
		<?php submit_button('Publish Products', 'publish', 'publish' ) ?> <?php submit_button('Unpublish Products', 'unpublish', 'unpublish') ?>
	</form>

</div>