<?php

class jva_swiftpos_main_integration{
		protected $api_key,$location;

		public function __construct(){
				$this->_enqueue_scripts();
				$this->_load_dependencies();
				$this->_define_hooks();
				$this->_load_admin_pages();
		}
		
		private function _enqueue_scripts() {
				if(file_exists(PLUGIN_BASE_PATH . 'includes/helpers/classes/class-enqueue-scripts.php')){
					require_once PLUGIN_BASE_PATH . 'includes/helpers/classes/class-enqueue-scripts.php';
				}
		}

		private function _load_dependencies() {
				if(file_exists(PLUGIN_BASE_PATH . 'includes/class-jva-swiftpos-sync.php')){
					require_once PLUGIN_BASE_PATH . 'includes/class-jva-swiftpos-sync.php';
				}
				if(file_exists(PLUGIN_BASE_PATH . 'includes/jva-swiftpos-freeshipping.php')){
					require_once PLUGIN_BASE_PATH . 'includes/jva-swiftpos-freeshipping.php';
				}
		}

		private function _define_hooks() {
				if(file_exists(PLUGIN_BASE_PATH . 'includes/helpers/classes/class-jva-swiftpos-hooks-definition.php')){
					require_once PLUGIN_BASE_PATH . 'includes/helpers/classes/class-jva-swiftpos-hooks-definition.php';
				}
		}

		private function _load_admin_pages() {
				if(file_exists(PLUGIN_BASE_PATH . 'includes/helpers/classes/class-admin-pages-handler.php')){
					require_once PLUGIN_BASE_PATH . 'includes/helpers/classes/class-admin-pages-handler.php';
				}
		}

		private function update_api_key() {

		}

		private function before_sync() {
			
		}

		private function after_sync() {
			
		}

		private function process_swift_products() {
			
		}
}

?>