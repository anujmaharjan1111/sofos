<?php

class jva_utility_functions{

	public function __construct(){

	}
	
	public get_woo_id($swift_id){

	}

	public get_swift_id($woo_id){
		
	}
}

?>