<?php

class pws_wp{
	protected $swift_project_obj;

	public function __construct(){

	}

	public function check_product_type(){

	}

	public function update_post_meta($meta_key,$meta_value){
		
	}

	public function update_atum_value(){
		
	}

	public function update_category(){
		
	}

	public function update_coil_inventory(){
		
	}

	public function update_concentrate_inventory(){
		
	}

	public function single_woo_update(){
		
	}

}

?>