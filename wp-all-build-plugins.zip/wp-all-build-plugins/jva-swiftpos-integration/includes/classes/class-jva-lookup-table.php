
<?php

class jva_lookup_table{

	protected $name,$key;

	public function __construct(){

	}

	public sync_product(){

	}
	public get_lookup_value(){

	}

	public set_lookup_value(){
		
	}
}

?>