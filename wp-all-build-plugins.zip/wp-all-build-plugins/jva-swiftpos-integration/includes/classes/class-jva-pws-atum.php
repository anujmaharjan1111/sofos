<?php

class pws_atum{
	protected $swift_project_obj;

	public function __construct(){

	}

	public function check_product_type(){

	}

	public function update_atum(){
		
	}

}

?>