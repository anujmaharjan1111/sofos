<?php

class jva_order_handler{
	protected $order_id,$order_obj;

	public function __construct(){

	}
	
	public update_order_pos(){

	}

	public update_inventory(){
		
	}
}

?>