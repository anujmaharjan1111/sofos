<?php

class jva_products{

	protected $wirehouse,$api_key;

	public function __construct(){

	}

	public sync_product(){

	}
	public check_product_type(){

	}

	public calculate_inventory(){

	}
}

?>