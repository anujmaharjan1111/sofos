<?php
class JVA__Functions {
	protected $plugin_name;
	protected $version;
	public function __construct() {
		if ( defined( 'JVA_PLUGIN' ) ) {
			$this->version = JVA_PLUGIN;
		} else {
			$this->version = '1.0.0';
		}
		$this->plugin_name = 'jva-swiftpos-integration';
		$this->load_dependencies();
		$this->define_hooks();
	}
	/**
	 * Load the required dependencies for this plugin.
	 *
	 * @since    1.0.0
	 * @access   public
	 */
	public function load_dependencies() {
			require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/jva-swiftpos-integration-metaboxes.php';
			require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-jva-swiftpos-sync.php';
			
			// Free shipping thresholds 
			require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/jva-swiftpos-freeshipping.php';
	}
	/**
	 * Register all of the hooks related to the admin and public functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_hooks() {

		add_action('admin_enqueue_scripts', array($this, 'enqueue_styles_admin'));
		add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts_admin'));
		add_action('wp_enqueue_scripts', array($this, 'enqueue_styles_public'));
		add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts_public'));
		add_action('wp_ajax_jva_ajax', array($this, 'jva_ajax_callback_wp'));
		add_action('wp_ajax_nopriv_jva_ajax', array($this, 'jva_ajax_callback_wp'));
		
		add_action('woocommerce_thankyou', array($this, 'jva_order_thankyou'));

		add_action('admin_menu', array($this, 'swiftpost_integration_admin_page'));
		add_action( 'init', array($this, 'product_taxonomy_brand'));
		add_action( 'woocommerce_product_meta_end',  array($this,'action_product_meta_end'));
		
		add_action('wp_ajax_jva_sync_product', array($this, 'jva_sync_product'));
		add_action('wp_ajax_jva_before_sync_product', array($this, 'jva_before_sync_product'));
		add_action('wp_ajax_jva_after_sync_product', array($this, 'jva_after_sync_product'));
		
		// define the woocommerce_review_order_before_payment callback 		
		add_action('woocommerce_checkout_process', array($this , 'jva_match_cart_quantity_with_swiftpost'));
		//add_action( 'woocommerce_checkout_order_processed',array($this , 'jva_action_swiftpos_process_sale'), 10, 3);
		add_action( 'woocommerce_thankyou',array($this , 'jva_action_swiftpos_make_sale'), 10, 1);
		
		add_action('wp_ajax_nopriv_swiftpost_jva_ajax_product_sync', array($this, 'swiftpost_jva_ajax_product_sync'));
		add_action('wp_ajax_swiftpost_jva_ajax_product_sync', array($this, 'swiftpost_jva_ajax_product_sync'));
		
		add_action('wp_ajax_jva_product_sync_ajax', array($this, 'jva_ajax_product_sync'),10,3);
		add_action('wp_ajax_nopriv_jva_product_sync_ajax', array($this, 'jva_ajax_product_sync'),10,3);

		// CHECKING
		add_action('wp_ajax_jva_product_sync_ajax2', array($this, 'jva_ajax_product_sync2'),10,3);
		add_action('wp_ajax_nopriv_jva_product_sync_ajax2', array($this, 'jva_ajax_product_sync2'),10,3);
		// CHECKING
		
		add_action('wp_ajax_jva_product_inventory_sync_ajax', array($this, 'jva_ajax_product_inventory_sync'),10,3);
		add_action('wp_ajax_nopriv_jva_product_inventory_sync_ajax', array($this, 'jva_ajax_product_inventory_sync'),10,3);
		
		
		add_action('wp_ajax_nopriv_jvaWPAJAXGetShippingNotice', array($this, 'jvaWPAJAXGetShippingNotice'));
		add_action('wp_ajax_jvaWPAJAXGetShippingNotice', array($this, 'jvaWPAJAXGetShippingNotice'));
		
		add_filter('woocommerce_countries', array($this, 'jvaWooCountries'));
		add_filter('woocommerce_states', array($this, 'jvaWooStates'));
		
		add_action('init', array($this,'custom_filter_override'), 100);
		//add_action( 'woocommerce_before_calculate_totals', array($this, 'wc_apply_custom_cart_rules_update_price'), 9999999, 1);
		add_filter( 'woocommerce_cart_subtotal', array($this, 'wc_apply_filter_checkout_for_coupons'), 9999999, 3 );
		add_action( 'woocommerce_checkout_create_order', array($this, 'wc_before_woocommerce_checkout_create_order_for_coupons'), 9999999, 2);
		add_action( 'woocommerce_order_status_on-hold', array($this, 'sync_SwiftPOS_Order'), 999, 1);
		add_action( 'woocommerce_order_status_processing', array($this, 'sync_SwiftPOS_Order'), 999, 1);
	}

	public function get_cart_price_rules(){
		$cart_rules = array();
		$cart_rules_option = get_field('cart_price_rules', 'option');
		if(!empty($cart_rules_option)) {
			foreach($cart_rules_option as $lookup) {
				$brand_sku = $lookup['10th_sku_character'];
				$brand_title = $lookup['brand_name'];
				$brandLookUp[$brand_sku] = $brand_title;
			}
		}
		return $cart_rules_option;
	}

	public function is_cart_price_rules_enabled(){
		return get_field('enable_cart_rules', 'option');
	}

	private function subset_sum($numbers, $target, $partial=array(), $result = array()){
	    $s = array_sum($partial);
	    $partial = array_filter($partial);
	    
	    # check if the partial sum is equals to target
	    	
	    if($s == $target){
	        if(empty( $result)){
	        	$result[] = $partial;
	        }else{
	        	$result_exists = 0;
	        	foreach ($result as $res) {
	        		if(count(array_diff($res, $partial)) == 0){
	        			$result_exists = 1;
	        			break;
	        		}
	        	}
	        	if(!$result_exists){
	        		$result[] = $partial;
	        	}
	        }

	    } 	
	    for($i=0; $i < count($numbers); $i++) {
	    	$remaining = $numbers;
	    	array_shift($remaining);
	    	$n = $numbers[$i];
	    	$result = $this->subset_sum($remaining, $target, array_merge($partial, array($n)), $result);
	    	
	    }
	    return $result;
	}

	public function generate_combinational_sum($numbers /*= array(1,5,3,7)*/, $target /*= 1*/){
	    $r = array();

	    if(!is_array($numbers) || ! is_numeric($target)){
	        return $r;
	    }
	    $numbers = array_unique($numbers);
	    rsort($numbers);
	    $subset2 = $numbers;
	    $max_subset_n = array_shift($subset2);
	    $pre_filled_array = array(0,0);

	    $numbers = array_merge($pre_filled_array,$numbers);
	    $subset2 = array_merge($pre_filled_array,$subset2);
	    
	    if($target < 10){
	        $r = $this->subset_sum($numbers, $target);

	        if(is_array($r[0]))
	            $r = $r[0];
	        
	    }else{
	        $rem = $target % $max_subset_n;
	        $multiplire = ($target - $rem) / $max_subset_n;
	        $r2 = array_fill(0, $multiplire , $max_subset_n);
	        $r = $this->subset_sum($subset2,$rem);

	        if(isset($r[0]))
	            $r = array_merge($r[0], $r2);
	        else{
	            $r = array_merge($r, $r2);
	        }
	    }

	    return $r;
	}
	
	public function custom_filter_override(){
		add_filter('woocommerce_placeholder_img_src', array($this,'custom_woocommerce_placeholder_img_src'));
		add_filter( 'woocommerce_placeholder_img', array($this,'wcdi_replace_wc_placeholder_img'),100,3);
		//add_filter( 'wp_get_attachment_url', array( $this, 'wp_get_attachment_url' ), 99, 2 );
		//add_filter( 'wp_get_attachment_image_src', array( $this, 'maybe_encode_wp_get_attachment_image_src' ), 99, 4 );
		//add_filter( 'wp_prepare_attachment_for_js', array( $this, 'maybe_encode_wp_prepare_attachment_for_js', ), 99, 3 );
	}
	
	public function custom_woocommerce_placeholder_img_src( $src ) {
		$src = site_url() . '/product_images/jva-comming-soon.png';
		return $src;
	}
	
	public function wcdi_replace_wc_placeholder_img( $html, $size, $dimensions ){
		$img_id = 69828;
		return $img_id ? wp_get_attachment_image( $img_id, $size ) : $html;
	}
	
	public function wp_get_attachment_url($url, $attachmentId ){
		$parentPost = get_post_ancestors( $attachmentId );
		$parentPostId = $parentPost[0];
		$postSku = get_post_meta($parentPostId,'_sku', true);
		$productGallery = get_post_meta($parentPostId, '_product_image_gallery', true);
		if($productGallery != '') {
			$productGalleryId = explode(',', $productGallery);
		}
		
		if($postSku != '' && $parentPostId != '') {
			$siteUrl = site_url();
			$rootBaseDirectory = ABSPATH;
			if(!empty($productGalleryId)) {
				$attachmentKey = array_search ($attachmentId, $productGalleryId);
			}
			if(is_numeric($attachmentKey)) {
				$sharePointImageUrl = $rootBaseDirectory.'product_images/'.$postSku.'-'.($attachmentKey+1).'.jpg';
				$url = $siteUrl.'/product_images/'.$postSku.'-'.($attachmentKey+1).'.jpg';
			} else {
				$sharePointImageUrl = $rootBaseDirectory.'product_images/'.$postSku.'.jpg';
				$url = $siteUrl.'/product_images/'.$postSku.'.jpg';
			}
			if(@file_exists($sharePointImageUrl)){
			} else {
				$url = site_url() . '/product_images/jva-comming-soon.png';
			}
		}
		return $url;
	}
	
	public function maybe_encode_wp_get_attachment_image_src( $image, $attachmentId, $size, $icon ) {
		$parentPost = get_post_ancestors( $attachmentId );
		$parentPostId = $parentPost[0];
		$postSku = get_post_meta($parentPostId,'_sku', true);
		$productGallery = get_post_meta($parentPostId, '_product_image_gallery', true);
		if($productGallery != '') {
			$productGalleryId = explode(',', $productGallery);
		}
		if($postSku != '' && $parentPostId != '') {
			$siteUrl = site_url();
			$rootBaseDirectory = ABSPATH;
			if(!empty($productGalleryId)) {
				$attachmentKey = array_search ($attachmentId, $productGalleryId);
			}
			if(is_numeric($attachmentKey)) {
				$sharePointImageUrl = $rootBaseDirectory.'product_images/'.$postSku.'-'.($attachmentKey+1).'.jpg';
				$image[0] = $siteUrl.'/product_images/'.$postSku.'-'.($attachmentKey+1).'.jpg';
			} else {
				$sharePointImageUrl = $rootBaseDirectory.'product_images/'.$postSku.'.jpg';
				$image[0] = $siteUrl.'/product_images/'.$postSku.'.jpg';
			}
			if(@file_exists($sharePointImageUrl)){
			} else {
				$image[0] = site_url() . '/product_images/jva-comming-soon.png';
			}
		}
		if ( isset( $image[0] ) ) {
			$url = $image[0];
			$url = $this->encode_filename_in_path( $url );
			$image[0] = $url;
		}
		return $image;
	}
	
	public function maybe_encode_wp_prepare_attachment_for_js( $response, $attachment, $meta ) {
		if ( isset( $response['url'] ) && !is_array($response['sizes'])) {
			$response['url'] = $this->encode_filename_in_path( $response['url'] );
			$sizeArray = get_intermediate_image_sizes();
			foreach ( $sizeArray as $size ) {
				$response['sizes'][ $size ]['url'] = $url;
			}
		} else {
			$response['url'] = $this->encode_filename_in_path( $response['url'] );
		}

		if ( isset( $response['sizes'] ) && is_array( $response['sizes'] ) ) {
			foreach ( $response['sizes'] as $size => $value ) {
				$url = $response['url'];
				$url = $this->encode_filename_in_path( $url );

				$response['sizes'][ $size ]['url'] = $url;
			}
		}
		return $response;
	}

	public function encode_filename_in_path( $file ) {
		$url = parse_url( $file );
		if ( ! isset( $url['path'] ) ) {
			// Can't determine path, return original
			return $file;
		}
		if ( isset( $url['query'] ) ) {
			// Manually strip query string, as passing $url['path'] to basename results in corrupt � characters
			$file_name = wp_basename( str_replace( '?' . $url['query'], '', $file ) );
		} else {
			$file_name = wp_basename( $file );
		}
		if ( false !== strpos( $file_name, '%' ) ) {
			// File name already encoded, return original
			return $file;
		}
		$encoded_file_name = rawurlencode( $file_name );
		if ( $file_name === $encoded_file_name ) {
			// File name doesn't need encoding, return original
			return $file;
		}
		return str_replace( $file_name, $encoded_file_name, $file );
	}
	
	public function UR_Exists($url){
		if($url == '' || $url == null) { return false;}
		$response = wp_remote_head($url,array('timeout' => 5));
		$acceptedStatus = array(200);
		if(!is_wp_error($response) && in_array(wp_remote_retrieve_response_code($response), $acceptedStatus)) {
			return true;
		}
		return false;
	}
	
	public function clean_swiftpost_data() {
		global $wpdb;
		$query = 'update `'.$wpdb->prefix.'swiftpost_products` set meta = 1';
		
		$product_table_name = $wpdb->prefix . 'swiftpost_products';
		$wpdb->query($query);
		$args = array(
			'post_type'      => 'product',
			'numberposts' => -1,
			'post_status' => array('any','trash')
		);
		$allProducts = get_posts($args);
		if(!empty($allProducts)) {
			foreach($allProducts as $product){
				$productID = $product->ID;
				$response = $wpdb->get_results("SELECT * FROM $product_table_name WHERE woocommerce_id = $productID");
				if(!empty($response)) {
					$wpdb->update(
								$product_table_name, 
								array(
									'meta' => '0'
								), 
								array( 
									'woocommerce_id' => $productID
								), 
								array( 
									'%s'
								), 
								array( '%d' ) 
							);
				}
			}
			$result = $wpdb->get_results("SELECT * FROM $product_table_name WHERE meta = 1");
			if(!empty($result)) {
				foreach($result as $dta) {
					$id = $dta->id;
					$wpdb->delete( $product_table_name, array('id' => $id ), array('%d'));
				}
			}
		} 
	}
	
	public function swiftpost_jva_ajax_product_sync(){
		self::clean_swiftpost_data();
		update_option("sync_cron_offset", '');
		update_option("sync_cron_limit", '');
		update_option("variationSync", '');
		$SwiftPOS_Sync = new SwiftPOS_Sync();
		$reupload_images = false;
		$force_sync = 'true';
		$syncResult = $SwiftPOS_Sync->ajax_sync_products_cron_start($reupload_images, $force_sync);
		wp_die();
	}
	private function get_all_products_csv(){
		global $wpdb;
		$jva_all_products = get_option("swiftPostApi_data");
		$mel_all_products = get_option("swiftPostApi_melbourne_data");
		$jaa_all_products = get_option("swiftPostApi_jaa_data");

		$products_arr = array();
		$i = 0;
		$products_arr[$i]['ID'] = 'ID';
		$products_arr[$i]['InventoryCode'] = 'InventoryCode';
		$products_arr[$i]['Warehouse'] = 'Warehouse';
		$products_arr[$i]['Standard'] = 'Standard';
		$products_arr[$i]['Short'] = 'Short';
		$products_arr[$i]['Long'] = 'Short';
		$products_arr[$i]['CategoryId'] = 'CategoryId';
		$products_arr[$i]['CategoryName'] = 'CategoryName';
		$products_arr[$i]['GroupId'] = 'GroupId';
		$products_arr[$i]['GroupName'] = 'GroupName';
		$products_arr[$i]['StockLevel'] = 'StockLevel';

		$i++;

		if(is_array($jva_all_products)){
			foreach($jva_all_products as $product){
				$products_arr[$i]['ID'] = $product->Id;
				$products_arr[$i]['InventoryCode'] = $product->InventoryCode;
				$products_arr[$i]['Warehouse'] = 'JVA';
				$products_arr[$i]['Standard'] = $product->Description->Standard;
				$products_arr[$i]['Short'] = $product->Description->Short;
				$products_arr[$i]['Long'] = $product->Description->Long;
				$products_arr[$i]['CategoryId'] = $product->Category->Id;
				$products_arr[$i]['CategoryName'] = $product->Category->Name;
				$products_arr[$i]['GroupId'] = $product->Group->Id;
				$products_arr[$i]['GroupName'] = $product->Group->Name;
				$products_arr[$i]['StockLevel'] = $product->StockLevel;
				$i++;
			}
		}

		if(is_array($mel_all_products)){
			foreach($mel_all_products as $product){
				$products_arr[$i]['ID'] = $product->Id;
				$products_arr[$i]['InventoryCode'] = $product->InventoryCode;
				$products_arr[$i]['Warehouse'] = 'Melbourne';
				$products_arr[$i]['Standard'] = $product->Description->Standard;
				$products_arr[$i]['Short'] = $product->Description->Short;
				$products_arr[$i]['Long'] = $product->Description->Long;
				$products_arr[$i]['CategoryId'] = $product->Category->Id;
				$products_arr[$i]['CategoryName'] = $product->Category->Name;
				$products_arr[$i]['GroupId'] = $product->Group->Id;
				$products_arr[$i]['GroupName'] = $product->Group->Name;
				$products_arr[$i]['StockLevel'] = $product->StockLevel;
				$i++;
			}
		}
		if(is_array($jaa_all_products)){
			foreach($jaa_all_products as $product){
				$i = $product->Id;
				$products_arr[$i]['ID'] = $product->Id;
				$products_arr[$i]['InventoryCode'] = $product->InventoryCode;
				$products_arr[$i]['Warehouse'] = 'JAA';
				$products_arr[$i]['Standard'] = $product->Description->Standard;
				$products_arr[$i]['Short'] = $product->Description->Short;
				$products_arr[$i]['Long'] = $product->Description->Long;
				$products_arr[$i]['CategoryId'] = $product->Category->Id;
				$products_arr[$i]['CategoryName'] = $product->Category->Name;
				$products_arr[$i]['GroupId'] = $product->Group->Id;
				$products_arr[$i]['GroupName'] = $product->Group->Name;
				$products_arr[$i]['StockLevel'] = $product->StockLevel;
				$i++;
			}
		}
		$f_name = 'all-products-'.date('Y-m-d-H-i-s').'.csv';
		header('Content-Type: application/csv; charset=UTF-8');
		header('Content-Disposition: attachment; filename="'.$f_name.'";');
		$f = fopen('php://output', 'w');
		foreach ($products_arr as $line) {
		    fputcsv($f, $line, ',');
		}
		/*fseek($f, 0);
		
		fpassthru($f);*/
		die;
	}

	private function get_all_wc_products_csv(){
		global $wpdb;
		set_time_limit(300);
		$jva_all_products = get_option("swiftPostApi_data");
		$mel_all_products = get_option("swiftPostApi_melbourne_data");
		$jaa_all_products = get_option("swiftPostApi_jaa_data");

		$products_arr = array();
		$i = 0;
		$products_arr[$i]['ID'] = 'ID';
		$products_arr[$i]['WooId'] = 'WooId';
		$products_arr[$i]['InventoryCode'] = 'InventoryCode';
		$products_arr[$i]['Warehouse'] = 'Warehouse';
		$products_arr[$i]['Standard'] = 'Standard';
		$products_arr[$i]['Short'] = 'Short';
		$products_arr[$i]['Long'] = 'Long';
		$products_arr[$i]['CategoryId'] = 'CategoryId';
		$products_arr[$i]['CategoryName'] = 'CategoryName';
		$products_arr[$i]['GroupId'] = 'GroupId';
		$products_arr[$i]['GroupName'] = 'GroupName';

		if(is_array($jva_all_products)){
			foreach($jva_all_products as $product){
				$i = $product->InventoryCode;
				$products_arr[$i]['ID'] = $product->Id;
				$products_arr[$i]['InventoryCode'] = $product->InventoryCode;
				$products_arr[$i]['Warehouse'] = 'JVA';
				$products_arr[$i]['Standard'] = $product->Description->Standard;
				$products_arr[$i]['Short'] = $product->Description->Short;
				$products_arr[$i]['Long'] = $product->Description->Long;
				$products_arr[$i]['CategoryId'] = $product->Category->Id;
				$products_arr[$i]['CategoryName'] = $product->Category->Name;
				$products_arr[$i]['GroupId'] = $product->Group->Id;
				$products_arr[$i]['GroupName'] = $product->Group->Name;
			}
		}

		if(is_array($mel_all_products)){
			foreach($mel_all_products as $product){
				$i = $product->InventoryCode;
				$products_arr[$i]['ID'] = $product->Id;
				$products_arr[$i]['InventoryCode'] = $product->InventoryCode;
				$products_arr[$i]['Warehouse'] = 'Melbourne';
				$products_arr[$i]['Standard'] = $product->Description->Standard;
				$products_arr[$i]['Short'] = $product->Description->Short;
				$products_arr[$i]['Long'] = $product->Description->Long;
				$products_arr[$i]['CategoryId'] = $product->Category->Id;
				$products_arr[$i]['CategoryName'] = $product->Category->Name;
				$products_arr[$i]['GroupId'] = $product->Group->Id;
				$products_arr[$i]['GroupName'] = $product->Group->Name;
			}
		}
		if(is_array($jaa_all_products)){
			foreach($jaa_all_products as $product){
				$i = $product->InventoryCode;
				$products_arr[$i]['ID'] = $product->Id;
				$products_arr[$i]['InventoryCode'] = $product->InventoryCode;
				$products_arr[$i]['Warehouse'] = 'JAA';
				$products_arr[$i]['Standard'] = $product->Description->Standard;
				$products_arr[$i]['Short'] = $product->Description->Short;
				$products_arr[$i]['Long'] = $product->Description->Long;
				$products_arr[$i]['CategoryId'] = $product->Category->Id;
				$products_arr[$i]['CategoryName'] = $product->Category->Name;
				$products_arr[$i]['GroupId'] = $product->Group->Id;
				$products_arr[$i]['GroupName'] = $product->Group->Name;
			}
		}


		// WC products
		$wc_sku_list = array();
		$wc_sku_list[0] = $products_arr[0];
		$results = $wpdb->get_results("SELECT DISTINCT meta_value, post_id FROM `wp_postmeta` WHERE `meta_key` LIKE '%sku%';");
		foreach ($results as $row) {
			if(!empty($products_arr[$row->meta_value])){
				$i = $row->meta_value;
				$wc_sku_list[$i]['ID'] = $products_arr[$row->meta_value]['ID'];
				$wc_sku_list[$i]['WooId'] = $row->post_id;
				$wc_sku_list[$i]['InventoryCode'] = $row->meta_value;
				$wc_sku_list[$i]['Warehouse'] = $products_arr[$row->meta_value]['Warehouse'];
				$wc_sku_list[$i]['Standard'] = $products_arr[$row->meta_value]['Standard'];
				$wc_sku_list[$i]['Short'] = $products_arr[$row->meta_value]['Short'];
				$wc_sku_list[$i]['Long'] = $products_arr[$row->meta_value]['Long'];
				$wc_sku_list[$i]['CategoryId'] = $products_arr[$row->meta_value]['CategoryId'];
				$wc_sku_list[$i]['CategoryName'] = $products_arr[$row->meta_value]['CategoryName'];
				$wc_sku_list[$i]['GroupId'] = $products_arr[$row->meta_value]['GroupId'];
				$wc_sku_list[$i]['GroupName'] = $products_arr[$row->meta_value]['GroupName'];
			}
			else{
				$i = $row->meta_value;
				$wc_sku_list[$i]['ID'] = '';
				$wc_sku_list[$i]['WooId'] = $row->post_id;
				$wc_sku_list[$i]['InventoryCode'] = $row->meta_value;
				$wc_sku_list[$i]['Warehouse'] = '';
				$wc_sku_list[$i]['Standard'] = '';
				$wc_sku_list[$i]['Short'] = '';
				$wc_sku_list[$i]['Long'] = '';
				$wc_sku_list[$i]['CategoryId'] = '';
				$wc_sku_list[$i]['CategoryName'] = '';
				$wc_sku_list[$i]['GroupId'] = '';
				$wc_sku_list[$i]['GroupName'] = '';
			}
		}
		$products_arr = $wc_sku_list;
		//$wc_sku_list = array_unique($wc_sku_list);
		// WC products


		$f_name = 'all-wc-products-after-removing-comment-'.date('Y-m-d-H-i-s').'.csv';
		header('Content-Type: application/csv; charset=UTF-8');
		header('Content-Disposition: attachment; filename="'.$f_name.'";');
		$f = fopen('php://output', 'w');
		foreach ($products_arr as $line) {
		    fputcsv($f, $line, ',');
		}
		/*fseek($f, 0);
		
		fpassthru($f);*/
		die;
	}

	private function get_products_not_synced_csv(){
		global $wpdb;
		
		$jva_all_products = get_option("test_swiftPostApi_data");
		$mel_all_products = get_option("test_swiftPostApi_melbourne_data");
		$jaa_all_products = get_option("test_swiftPostApi_jaa_data");

		$products_arr = array();
		$i = 0;
		$products_arr[$i]['ID'] = 'ID';
		$products_arr[$i]['InventoryCode'] = 'InventoryCode';
		$products_arr[$i]['Warehouse'] = 'Warehouse';
		$products_arr[$i]['Standard'] = 'Standard';
		$products_arr[$i]['Short'] = 'Short';
		$products_arr[$i]['Long'] = 'Long';
		$products_arr[$i]['CategoryId'] = 'CategoryId';
		$products_arr[$i]['CategoryName'] = 'CategoryName';
		$products_arr[$i]['GroupId'] = 'GroupId';
		$products_arr[$i]['GroupName'] = 'GroupName';

		if(is_array($jva_all_products)){
			foreach($jva_all_products as $product){
				$i = $product->Id;
				$products_arr[$i]['ID'] = $product->Id;
				$products_arr[$i]['InventoryCode'] = $product->InventoryCode;
				$products_arr[$i]['Warehouse'] = 'JVA';
				$products_arr[$i]['Standard'] = $product->Description->Standard;
				$products_arr[$i]['Short'] = $product->Description->Short;
				$products_arr[$i]['Long'] = $product->Description->Long;
				$products_arr[$i]['CategoryId'] = $product->Category->Id;
				$products_arr[$i]['CategoryName'] = $product->Category->Name;
				$products_arr[$i]['GroupId'] = $product->Group->Id;
				$products_arr[$i]['GroupName'] = $product->Group->Name;
				
			}
		}

		if(is_array($mel_all_products)){
			foreach($mel_all_products as $product){
				$i = $product->Id;
				$products_arr[$i]['ID'] = $product->Id;
				$products_arr[$i]['InventoryCode'] = $product->InventoryCode;
				$products_arr[$i]['Warehouse'] = 'Melbourne';
				$products_arr[$i]['Standard'] = $product->Description->Standard;
				$products_arr[$i]['Short'] = $product->Description->Short;
				$products_arr[$i]['Long'] = $product->Description->Long;
				$products_arr[$i]['CategoryId'] = $product->Category->Id;
				$products_arr[$i]['CategoryName'] = $product->Category->Name;
				$products_arr[$i]['GroupId'] = $product->Group->Id;
				$products_arr[$i]['GroupName'] = $product->Group->Name;
				
			}
		}
		if(is_array($jaa_all_products)){
			foreach($jaa_all_products as $product){
				$i = $product->Id;
				$products_arr[$i]['ID'] = $product->Id;
				$products_arr[$i]['InventoryCode'] = $product->InventoryCode;
				$products_arr[$i]['Warehouse'] = 'JAA';
				$products_arr[$i]['Standard'] = $product->Description->Standard;
				$products_arr[$i]['Short'] = $product->Description->Short;
				$products_arr[$i]['Long'] = $product->Description->Long;
				$products_arr[$i]['CategoryId'] = $product->Category->Id;
				$products_arr[$i]['CategoryName'] = $product->Category->Name;
				$products_arr[$i]['GroupId'] = $product->Group->Id;
				$products_arr[$i]['GroupName'] = $product->Group->Name;
				
			}
		}
		$f_name = 'products-not-synced-'.date('Y-m-d-H-i-s').'.csv';
		header('Content-Type: application/csv; charset=UTF-8');
		header('Content-Disposition: attachment; filename="'.$f_name.'";');
		$f = fopen('php://output', 'w');
		foreach ($products_arr as $line) {
		    fputcsv($f, $line, ',');
		}
		/*fseek($f, 0);
		
		fpassthru($f);*/
		die;
	}

	private function get_products_not_synced(){
		global $wpdb;
		$jva_all_products = get_option("swiftPostApi_data");
		$mel_all_products = get_option("swiftPostApi_melbourne_data");
		$jaa_all_products = get_option("swiftPostApi_jaa_data");

		/*$jva_all_creds = get_option("swiftpos_creds");
		$mel_all_creds = get_option("swiftpos_creds_melbourne");
		$jaa_all_creds = get_option("swiftpos_creds_jaa");*/
		$all_not_synced = array();
		$products_not_synced = array();
		$sku_list = array();
		$products_list = array();

		$wc_sku_list = array();
		$results = $wpdb->get_results("SELECT DISTINCT meta_value, `meta_key` FROM `".$wpdb->prefix."postmeta` WHERE `meta_key` LIKE '%sku%';");
		foreach ($results as $row) {
			$wc_sku_list[] = $row->meta_value;
		}
		$wc_sku_list = array_unique($wc_sku_list);

		foreach ($jva_all_products as $product) {
			$sku_list[] = $product->InventoryCode;
			$products_list[] = $product;
		}
		$sku_list = array_unique($sku_list);
		$no_synced_skus = array_diff($sku_list, $wc_sku_list);

		foreach ($products_list as $product) {
			if(in_array($product->InventoryCode, $no_synced_skus)){
				$products_not_synced[] = $product;
			}
		}
		$all_not_synced['jva'] = $products_not_synced;
		echo 'jav: '.count($products_not_synced);
		update_option("test_swiftPostApi_data", $products_not_synced);
		$sku_list = array();
		$products_list = array();
		$products_not_synced = array();

		foreach ($mel_all_products as $product) {
			$sku_list[] = $product->InventoryCode;
			$products_list[] = $product;
		}

		$sku_list = array_unique($sku_list);
		$no_synced_skus = array_diff($sku_list, $wc_sku_list);

		foreach ($products_list as $product) {
			if(in_array($product->InventoryCode, $no_synced_skus)){
				$products_not_synced[] = $product;
			}
		}
		$all_not_synced['melbourne'] = $products_not_synced;
		echo 'mel: '.count($products_not_synced);
		update_option("test_swiftPostApi_melbourne_data", $products_not_synced);
		$sku_list = array();
		$products_list = array();
		$products_not_synced = array();

		foreach ($jaa_all_products as $product) {
			$sku_list[] = $product->InventoryCode;
			$products_list[] = $product;
		}
		$sku_list = array_unique($sku_list);
		$no_synced_skus = array_diff($sku_list, $wc_sku_list);

		foreach ($products_list as $product) {
			if(in_array($product->InventoryCode, $no_synced_skus)){
				$products_not_synced[] = $product;
			}
		}
		$all_not_synced['jaa'] = $products_not_synced;
		echo 'jaa: '.count($products_not_synced);
		update_option("test_swiftPostApi_jaa_data", $products_not_synced);
		$sku_list = array();
		$products_list = array();
		$products_not_synced = array();

		/*$sku_list = array_unique($sku_list);


		

		$no_synced_skus = array_diff($sku_list, $wc_sku_list);

		foreach ($products_list as $product) {
			if(in_array($product->InventoryCode, $no_synced_skus)){
				$products_not_synced[$product->InventoryCode] = $product;
			}
		}

		echo json_encode($products_not_synced);*/
		//echo json_encode($all_not_synced);
		//var_dump($jva_all_creds, $mel_all_creds, $jaa_all_creds);
		//var_dump($jva_all_products, $mel_all_products, $jaa_all_products);
		//echo json_encode($jva_all_products);
		//echo json_encode($mel_all_products);
		//echo json_encode($jaa_all_products);
		die;
	}

	private function get_all_products_test(){
		global $wpdb;
		$jva_all_products = get_option("swiftPostApi_data");
		$mel_all_products = get_option("swiftPostApi_melbourne_data");
		$jaa_all_products = get_option("swiftPostApi_jaa_data");

		$products_list = array();
		
		foreach ($jva_all_products as $product) {
			if(!empty($product->Image))
				$products_list[] = $product->InventoryCode.'.jpg';
		}
		
		foreach ($mel_all_products as $product) {
			if(!empty($product->Image))
				$products_list[] = $product->InventoryCode.'.jpg';
		}

		foreach ($jaa_all_products as $product) {
			if(!empty($product->Image)){
				$products_list[] = $product->InventoryCode.'.jpg';
				//echo '<img src="'.site_url().'/product_images/'.$product->InventoryCode.'.jpg" alt="'.$product->InventoryCode.'" style="width:100px" /><br>';
			}
		}
		$products_list = array_unique($products_list);
		$directory = ABSPATH.'/product_images/';
		$scanned_directory = array_diff(scandir($directory), array('..', '.', '.ftpquota'));

		$images_not_found = array_diff($products_list, $scanned_directory);
		$images_not_found = array_unique($images_not_found);
		var_dump(count($images_not_found), count($products_list), count($scanned_directory));
		var_dump($images_not_found);

		/*$images_not_found_final = array();
		foreach ($images_not_found as $key => $value) {
			$images_not_found_final[$key] = substr($key, 0, 7).'.jpg';
		}
		echo implode(',', array_keys(array_diff($images_not_found_final,  $scanned_directory)));*/

		die;
	}
	
	// CHECKING
	public function jva_ajax_product_sync2($offset = '', $limit = '', $force_sync = false){
		// echo "<br>--------------------------------<br>";
		// echo "jva_ajax_product_sync2";
		// echo "<br>--------------------------------<br>";

		// $reupload_images = false;
		// $syncWarehouse = 'JVA';
		// $SwiftPOS_Sync = new SwiftPOS_Sync();
		// $syncResult = $SwiftPOS_Sync->ajax_sync_products_cron2($reupload_images, $force_sync, $offset, $limit, $syncWarehouse);
		// var_dump($syncResult); die();

		// $SwiftPOS_Sync = new SwiftPOS_Sync();
  //       $reupload_images = false;
  //       $force_sync = 'true';
  //       $syncResult = $SwiftPOS_Sync->ajax_sync_products_cron_start2($reupload_images, $force_sync);
  //       die();

        
        // die();
        // SINGLE PRODUCT
        global $woocommerce;
        $syncWarehouse = 'JVA';
        echo 'Synching Warehouse: '.$syncWarehouse.'<br>';
        switch ( $syncWarehouse ){
            case 'Melbourne':
                $location = self::get_swiftpos_creds_melbourne('locationId');
                $user = self::get_swiftpos_creds_melbourne('userId');
                $pass = self::get_swiftpos_creds_melbourne('password');
            break;
            case 'JVA' :
                $location = self::get_swiftpos_creds('locationId');
                $user = self::get_swiftpos_creds('userId');
                $pass = self::get_swiftpos_creds('password');
            break;
            case 'JAA':
                $location = self::get_swiftpos_creds_just_automiser('locationId');
                $user = self::get_swiftpos_creds_just_automiser('userId');
                $pass = self::get_swiftpos_creds_just_automiser('password');
            break;
        }

        $supplierData = self::getSupplier($location);
        if(!empty($supplierData)) {
            $supplierId = $supplierData->ID;
            $supplierName = $supplierData->post_title;
        }

        // echo 'location -> ' . $location . '<br><br>' ;
        // echo 'user -> ' . $user . '<br><br>' ;
        // echo 'pass -> ' . $pass . '<br><br>' ;
        // echo 'supplierId -> ' . $supplierId . '<br><br>' ;
        // echo 'supplierName -> ' . $supplierName . '<br><br>' ;
        
        $sync = new SwiftPOS_Sync();
        $ApiKey = $sync->assign_api_key2($location, $user, $pass);
        
        echo "<br>-----1-----<br>";
        var_dump($ApiKey);
        echo "<br>-----1-----<br>";

        $allProducts = $this->get_all_products();

        // echo "<pre>";
        // print_r($allProducts);
        // echo "</pre>";


		if (!empty($allProducts)) {
			if($ApiKey == true){
				$i = 1;
				foreach($allProducts as $product) {
					$i++;
					$productId = $product->ID;
					$productObject = wc_get_product( $productId );

					/** 
					 * COILS INVENTORY UPDATE EXCLUSION
					 * 
					 * Due to complicated stock quantity determination of coils
					 * I temporarily write this code to exclude the coils 
					 * in updating the inventory in this cron job
					 * 
					*/
					/* $product_categories = $productObject->get_category_ids();

					$_coils_slug = get_term_by('slug', 'coils', 'product_cat');

					if( ! empty($_coils_slug) && in_array( $_coils_slug->term_id, $product_categories) ) continue;
					
					 END OF COILS INVENTORY UPDATE EXCLUSION */

					if ($productObject->product_type == 'variable') {
						$productVariations = $productObject->get_available_variations();
						if(!empty($productVariations)) {
							foreach($productVariations as $variation) {
								
								$productTypeSKU = substr($variation['sku'], 7 ,1);
								
								// CHECK IF PRODUCT IS COIL
								if($productTypeSKU != false && strlen($productTypeSKU) == 1 && is_numeric($productTypeSKU) && ($productTypeSKU == 3 )) {
									
									$variationId = $productObject->get_id();

									$prodSKU = $productObject->get_sku();

									$typeSKU = substr($variation['sku'], 10 ,3);

									$packingSKU = substr($variation['sku'], 8 ,1);

									//$packingSKU = substr($variation['sku'], 8 ,1);

									$coil_box_products_ids = get_option('coil_box_products_ids_' . $prodSKU . '_' . $typeSKU, []);

									$function =  "Product/" . $coil_box_products_ids[0] . "";
									$data = '';
									$product_details = $sync->request($sync->key, $data, $function);

									echo "<br>-------------<br>";
									var_dump($product_details);
									echo "<br>-------------<br>";

									if(!empty($product_details)) {
										
										$boxes = [
											'A' 	=> 15,
											'B'		=> 30,
											'C'		=> 50,
											'D'		=> 100
										];

										$iinventorySStock = $product_details->StockLevel;
										if($iinventorySStock == null){ $iinventorySStock = 0; }
										elseif(empty($iinventorySStock)){ $iinventorySStock = 0; }
										elseif( $iinventorySStock < 0 ){ $iinventorySStock = 0; }

										$box_actual_stock = floatval(abs($iinventorySStock)) * floatval($boxes[$packingSKU]);

										if(!empty($box_actual_stock)){
											$inventory = floatval($box_actual_stock) / floatval($packingSKU);
										}
										else{
											$inventory = 0;
										}

										// update_post_meta( $variationId, '_stock', $inventory );

										$stockStatus = ($inventory > 0) ? 'instock' : 'outofstock';

										self::updateProductAutumInventory($variationId,  $supplierId, $supplierName, $inventory, $stockStatus);
										
									}

								} else {
									$variationId = $variation['variation_id'];
									$variationSwiftPosId = get_post_meta($variationId, 'swiftpost_id', true);
									$function =  "Product/".$variationSwiftPosId."";
									$data = '';
									$product_details = $sync->request($sync->key, $data, $function);
									echo "<br>-------------<br>";
									var_dump($product_details);
									echo "<br>-------------<br>";
									if(!empty($product_details)) {
										$inventory = $product_details->StockLevel;
										if($inventory == null){ $inventory = 0; }
										elseif(empty($inventory)){ $inventory = 0; }
										elseif( $inventory < 0 ){ $inventory = 0; }

										$sku = $product_details->InventoryCode;
										// update_post_meta( $variationId, '_stock', $inventory );
										$stockStatus = ($inventory > 0) ? 'instock' : 'outofstock';
										self::updateProductAutumInventory($variationId,  $supplierId, $supplierName, $inventory, $stockStatus);
									}
								}

								
							}
						}
					} else {
						$swiftPosId = get_post_meta($productId, 'swiftpost_id', true);
						$function =  "Product/".$swiftPosId."";
						$data = '';
						$product_details = $sync->request($sync->key, $data, $function);
						echo "<br>-------------<br>";
									var_dump($product_details);
									echo "<br>-------------<br>";
						if(!empty($product_details)) {
							$inventory = $product_details->StockLevel;
							if($inventory == null){ $inventory = 0; }
							elseif(empty($inventory)){ $inventory = 0; }
							elseif( $inventory < 0 ){ $inventory = 0; }

							$sku = $product_details->InventoryCode;
							$stockStatus = ($inventory > 0) ? 'instock' : 'outofstock';
							self::updateProductAutumInventory($productId,  $supplierId, $supplierName, $inventory, $stockStatus);
						}
					}
				}
			}


			// if($syncWarehouse == 'Melbourne') {
			// 	update_option("cronInventorySyncWarehouse","JVA");
			// } else if ($syncWarehouse == 'JVA') {
			// 	update_option("cronInventorySyncWarehouse","JAA");
			// } else {
			// 	update_option("cronInventorySyncWarehouse","Melbourne");
			// }
		}

        // $productId = 95916;
        // // $productId = 95882;
        // $productObject = wc_get_product( $productId );
        // $swiftPosId = get_post_meta($productId, 'swiftpost_id', true);
        // $function =  "Product/".$swiftPosId."";

        // echo "<br>-----2-----<br>";
        // echo $function;
        // echo "<br>-----2-----<br>";

        // $data = '';
        // $product_details = $sync->request($sync->key, $data, $function);
        // echo "<br>-----3-----<br>";
        // var_dump($product_details);
        // echo "<br>-----3-----<br>";

        // $inventory = 5;
        // // if($inventory == null){ $inventory = 0; }
        // // elseif(empty($inventory)){ $inventory = 0; }
        // // elseif( $inventory < 0 ){ $inventory = 0; }

        // // $sku = '966466744V8';
        // $stockStatus = ($inventory > 0) ? 'instock' : 'outofstock';
        // self::updateProductAutumInventory($productId,  $supplierId, $supplierName, $inventory, $stockStatus);
        
        // echo "done"; die();




        //////////////////////////////

  //       $update_product_ids = array(956985698, 95916, 94205, 94207, 94209, 94207);
		// $product_ids_for_inventory_update = array();
		// foreach( $update_product_ids as $updated_product_id ){
		// 	$updated_product = wc_get_product( $updated_product_id );
		// 	if(!empty($updated_product)){
		// 		if($updated_product->product_type == 'variation'){
		// 			$product_ids_for_inventory_update[ $updated_product->parent_id ] = $updated_product->parent_id;
		// 		}
		// 		else{
		// 			$product_ids_for_inventory_update[ $updated_product_id ] = $updated_product_id;
		// 		}
		// 	}
		// }

		// if(!empty($product_ids_for_inventory_update)){
		// 	// echo "<pre>";
		// 	// print_r($product_ids_for_inventory_update);
		// 	// die();

		// 	$this->update_product_inventory_by_product_ids( $product_ids_for_inventory_update, 'JVA' );
		// }

  //       //////////////////////////////
		// echo "string";
		// die();
        // MULTIPLE PRODUCT
        // global $woocommerce;
        // $syncWarehouse = 'JVA';
        // switch ( $syncWarehouse ){
        //     case 'Melbourne':
        //         $location = self::get_swiftpos_creds_melbourne('locationId');
        //         $user = self::get_swiftpos_creds_melbourne('userId');
        //         $pass = self::get_swiftpos_creds_melbourne('password');
        //     break;
        //     case 'JVA' :
        //         $location = self::get_swiftpos_creds('locationId');
        //         $user = self::get_swiftpos_creds('userId');
        //         $pass = self::get_swiftpos_creds('password');
        //     break;
        //     case 'JAA':
        //         $location = self::get_swiftpos_creds_just_automiser('locationId');
        //         $user = self::get_swiftpos_creds_just_automiser('userId');
        //         $pass = self::get_swiftpos_creds_just_automiser('password');
        //     break;
        // }

        // $supplierData = self::getSupplier($location);
        // if(!empty($supplierData)) {
        //     $supplierId = $supplierData->ID;
        //     $supplierName = $supplierData->post_title;
        // }

        // // echo 'location -> ' . $location . '<br><br>' ;
        // // echo 'user -> ' . $user . '<br><br>' ;
        // // echo 'pass -> ' . $pass . '<br><br>' ;
        // // echo 'supplierId -> ' . $supplierId . '<br><br>' ;
        // // echo 'supplierName -> ' . $supplierName . '<br><br>' ;
        
        // $sync = new SwiftPOS_Sync();
        // $ApiKey = $sync->assign_api_key($location, $user, $pass);
        
        // // echo "<br>-----1-----------<br>";
        // // echo $ApiKey;
        // // echo "<br>-----1-----------<br>";

        // $productId = 94205;
        // // $productId = 94207;
        // // $productId = 94209;
        // $productObject = wc_get_product( $productId );
        




        // // // $productVariations = $productObject->get_available_variations();
        // // echo "<pre>";
        // // var_dump( wc_get_product( 956985698 ) ); // false
        // // var_dump( wc_get_product( 95916 )->product_type ); // simple
        // // var_dump( wc_get_product( 94205 )->product_type ); // variable
        // // var_dump( wc_get_product( 94207 )->product_type ); // variation
        // // var_dump( wc_get_product( 94209 )->product_type ); // variation
        // // var_dump( wc_get_product( 94207 )->parent_id ); // 94205
        // // die();

        // if ($productObject->product_type == 'variable') {
        //     $productVariations = $productObject->get_available_variations();
        //     if(!empty($productVariations)) {
        //         foreach($productVariations as $variation) {
                    
        //             $productTypeSKU = substr($variation['sku'], 7 ,1);
                    
        //             $variationId = $variation['variation_id'];
        //             $variationSwiftPosId = get_post_meta($variationId, 'swiftpost_id', true);
        //             $function =  "Product/".$variationSwiftPosId."";

        //             echo "<br>-----2-----<br>";
        //             echo $function;
        //             echo "<br>-----2-----<br>";

        //             if( $variationSwiftPosId == '5020' )
        //                 $inventory = 39;
        //             else
        //                 $inventory = 0;
                    

        //             if($inventory == null){ $inventory = 0; }
        //             // update_post_meta( $variationId, '_stock', $inventory );
        //             $stockStatus = ($inventory > 0) ? 'instock' : 'outofstock';
        //             self::updateProductAutumInventory($variationId,  $supplierId, $supplierName, $inventory, $stockStatus);
        //         }
        //     }
        // }

		echo "Done"; die();
	}
	// CHECKING

	public function jva_ajax_product_sync($offset = '', $limit = '', $force_sync = false){
		set_time_limit(300);
		if(isset($_GET['test_run']) && $_GET['test_run'] == 'debug@123'){
			//$this->get_products_not_synced();
			//$SwiftPOS_Sync_Obj = new SwiftPOS_Sync();
			//$this->get_products_not_synced_csv();
			$this->get_all_products_csv();
			//$this->get_all_wc_products_csv();
			//$this->get_products_not_synced();
			//$this->get_products_not_synced_csv();
			//$this->get_all_products_test();

			die;
		}
		$syncWarehouse = get_option("cronSyncWarehouse", true);
		echo '<br>'.$syncWarehouse.'<br>';
		$totalVariation = get_option("totalVariation", true);
		$offset = get_option("sync_cron_offset", true);
		$limit = get_option("sync_cron_limit", true);
		if($limit >= $totalVariation) {
			//exit;
			//wp_die();
		}
		if($offset == '') {
			$offset = 0;
		}
		if($limit == '') {
			$limit = 15;
		}
		echo '<br>Limit '.$limit.'<br>';
		/*if(isset($_GET['test_run'])){
			echo '<pre>';
			var_dump('JVA', count(get_option('swiftPostApi_data', true)));
			echo '<br>/<br>/<br>/<br>/<br>/<br>/<br>/<br>/<br>/<br>/';
			var_dump('Melbourne', count(get_option('swiftPostApi_melbourne_data', true)));
			echo '<br>/<br>/<br>/<br>/<br>/<br>/<br>/<br>/<br>/<br>/';
			var_dump('JAA', count(get_option('swiftPostApi_jaa_data', true)));
			echo '</pre>';
		}*/
		/*if(isset($_GET['test_run1'])){
			echo '<pre>';
			var_dump(get_option('swiftpos_creds', true));
			echo '<br>/<br>/<br>/<br>/<br>/<br>/<br>/<br>/<br>/<br>/';
			var_dump(get_option('swiftpos_creds_melbourne', true));
			echo '<br>/<br>/<br>/<br>/<br>/<br>/<br>/<br>/<br>/<br>/';
			var_dump(get_option('swiftpos_creds_jaa', true));
			echo '<pre>';
		}*/
		$reupload_images = false;
		$SwiftPOS_Sync = new SwiftPOS_Sync();
		$syncResult = $SwiftPOS_Sync->ajax_sync_products_cron($reupload_images, $force_sync, $offset, $limit, $syncWarehouse);
		if(!empty($syncResult)) {
			if(isset($syncResult->update_product_ids)){
				if(is_array($syncResult->update_product_ids)){
					if(!empty($syncResult->update_product_ids)){
						$update_product_ids = $syncResult->update_product_ids;
						$product_ids_for_inventory_update = array();
						foreach( $update_product_ids as $updated_product_id ){
							$updated_product = wc_get_product( $updated_product_id );
							if(!empty($updated_product)){
								if($updated_product->product_type == 'variation'){
									$product_ids_for_inventory_update[ $updated_product->parent_id ] = $updated_product->parent_id;
								}
								else{
									$product_ids_for_inventory_update[ $updated_product_id ] = $updated_product_id;
								}
							}
						}

						if(!empty($product_ids_for_inventory_update)){
							$this->update_product_inventory_by_product_ids( $product_ids_for_inventory_update, $syncWarehouse );
							if($syncWarehouse != 'Melbourne'){
								$this->update_product_inventory_by_product_ids( $product_ids_for_inventory_update, 'Melbourne' );
							}
							if($syncWarehouse != 'JVA'){
								$this->update_product_inventory_by_product_ids( $product_ids_for_inventory_update, 'JVA' );
							}
							if($syncWarehouse != 'JAA'){
								$this->update_product_inventory_by_product_ids( $product_ids_for_inventory_update, 'JAA' );
							}
						}
					}
				}
			}

			$key = $syncResult->key;
			$status = $syncResult->status;
			$msg = $syncResult->msg;
			$errors = $syncResult->errors;
			$total = $syncResult->total;
			$variation = $syncResult->variation;
			$totalVariation = get_option("totalVariation", true);
			echo '<br>'.$variation. ' --- '.$totalVariation.'<br>';
			?>
			<script type="text/javascript">
				location = location;
			</script>
			<?php
			if(trim($variation) >= trim($totalVariation)) {
				echo '<br>'.$syncWarehouse.' '.$totalVariation." Products Sync Completed.  <br>";
				if($syncWarehouse == 'Melbourne') {
					update_option("sync_cron_offset", '');
					update_option("sync_cron_limit", '');
					update_option("variationSync",'');
					update_option("cronSyncWarehouse", 'JVA');
				} else if ($syncWarehouse == 'JVA') {
					update_option("sync_cron_offset", '');
					update_option("sync_cron_limit", '');
					update_option("variationSync",'');
					update_option("cronSyncWarehouse", 'JAA');
				} else {
					update_option("sync_cron_offset", '');
					update_option("sync_cron_limit", '');
					update_option("variationSync",'');
					update_option("cronSyncWarehouse", 'Complete');
					$SwiftPOS_Sync->ajax_after_sync_products();
					exit;
					wp_die();
				}
			} else if($variation <= $limit && trim($variation) < trim($totalVariation)) {
				$percentageCompleted = (trim($variation) / trim($totalVariation))*100;
				echo '<br>'.$syncWarehouse.' '.$percentageCompleted.' Completed.  <br>';
				$offset = $offset + 15;
				$limit = $limit + 15;
				update_option("sync_cron_offset", $offset);
				update_option("sync_cron_limit", $limit);
				exit;
				wp_die();
			} else {
				echo 'break';
				exit;
				wp_die();
			}
		}
		wp_die();
	}
	
	public function get_all_products2( $id='' ){
		global $wpdb;
		$postTable = $wpdb->prefix . 'posts';
		if(!empty($id)){
			$allProducts = $wpdb->get_results( 'SELECT ID FROM '.$postTable.' WHERE post_type = "product" AND ID = "'.$id.'"');
		}
		else{
			$allProducts = $wpdb->get_results( 'SELECT ID FROM '.$postTable.' WHERE post_type = "product"');
		}

		return $allProducts;
	}

	public function get_all_products(){
		global $wpdb;
		$postTable = $wpdb->prefix . 'posts';
		$allProducts = $wpdb->get_results( 'SELECT ID FROM '.$postTable.' WHERE post_type = "product"');
		return $allProducts;
	}
	
	public function jva_ajax_product_inventory_sync(){
		global $woocommerce;
		$syncWarehouse = get_option("cronInventorySyncWarehouse", true);
		if($syncWarehouse == '') {
			update_option("cronInventorySyncWarehouse","Melbourne");
			$syncWarehouse = 'Melbourne';
		}
		echo 'Synching Warehouse: '.$syncWarehouse.'<br>';
		switch ( $syncWarehouse ){
			case 'Melbourne':
				$location = self::get_swiftpos_creds_melbourne('locationId');
				$user = self::get_swiftpos_creds_melbourne('userId');
				$pass = self::get_swiftpos_creds_melbourne('password');
			break;
			case 'JVA' :
				$location = self::get_swiftpos_creds('locationId');
				$user = self::get_swiftpos_creds('userId');
				$pass = self::get_swiftpos_creds('password');
			break;
			case 'JAA':
				$location = self::get_swiftpos_creds_just_automiser('locationId');
				$user = self::get_swiftpos_creds_just_automiser('userId');
				$pass = self::get_swiftpos_creds_just_automiser('password');
			break;
		}

		$supplierData = self::getSupplier($location);
		if(!empty($supplierData)) {
			$supplierId = $supplierData->ID;
			$supplierName = $supplierData->post_title;
		}
		
		$sync = new SwiftPOS_Sync();
		$ApiKey = $sync->assign_api_key($location, $user, $pass);
		$allProducts = $this->get_all_products();
		if (!empty($allProducts)) {
			if($ApiKey == true){
				$i = 1;
				foreach($allProducts as $product) {
					$i++;
					$productId = $product->ID;
					$productObject = wc_get_product( $productId );

					/** 
					 * COILS INVENTORY UPDATE EXCLUSION
					 * 
					 * Due to complicated stock quantity determination of coils
					 * I temporarily write this code to exclude the coils 
					 * in updating the inventory in this cron job
					 * 
					*/
					/* $product_categories = $productObject->get_category_ids();

					$_coils_slug = get_term_by('slug', 'coils', 'product_cat');

					if( ! empty($_coils_slug) && in_array( $_coils_slug->term_id, $product_categories) ) continue;
					
					 END OF COILS INVENTORY UPDATE EXCLUSION */

					if ($productObject->product_type == 'variable') {
						$productVariations = $productObject->get_available_variations();
						if(!empty($productVariations)) {
							foreach($productVariations as $variation) {
								
								$productTypeSKU = substr($variation['sku'], 7 ,1);
								
								// CHECK IF PRODUCT IS COIL
								if($productTypeSKU != false && strlen($productTypeSKU) == 1 && is_numeric($productTypeSKU) && ($productTypeSKU == 3 )) {
									
									$variationId = $productObject->get_id();

									$prodSKU = $productObject->get_sku();

									$typeSKU = substr($variation['sku'], 10 ,3);

									$packingSKU = substr($variation['sku'], 8 ,1);

									//$packingSKU = substr($variation['sku'], 8 ,1);

									$coil_box_products_ids = get_option('coil_box_products_ids_' . $prodSKU . '_' . $typeSKU, []);

									$function =  "Product/" . $coil_box_products_ids[0] . "";
									$data = '';
									$product_details = $sync->request($sync->key, $data, $function);

									if(!empty($product_details)) {
										
										$boxes = [
											'A' 	=> 15,
											'B'		=> 30,
											'C'		=> 50,
											'D'		=> 100
										];

										$iinventorySStock = $product_details->StockLevel;
										if($iinventorySStock == null){ $iinventorySStock = 0; }
										elseif(empty($iinventorySStock)){ $iinventorySStock = 0; }
										elseif( $iinventorySStock < 0 ){ $iinventorySStock = 0; }

										$box_actual_stock = floatval(abs($iinventorySStock)) * floatval($boxes[$packingSKU]);

										if(!empty($box_actual_stock)){
											$inventory = floatval($box_actual_stock) / floatval($packingSKU);
										}
										else{
											$inventory = 0;
										}

										// update_post_meta( $variationId, '_stock', $inventory );

										$stockStatus = ($inventory > 0) ? 'instock' : 'outofstock';

										self::updateProductAutumInventory($variationId,  $supplierId, $supplierName, $inventory, $stockStatus);
										
									}

								} else {
									$variationId = $variation['variation_id'];
									$variationSwiftPosId = get_post_meta($variationId, 'swiftpost_id', true);
									$function =  "Product/".$variationSwiftPosId."";
									$data = '';
									$product_details = $sync->request($sync->key, $data, $function);
									if(!empty($product_details)) {
										$inventory = $product_details->StockLevel;
										if($inventory == null){ $inventory = 0; }
										elseif(empty($inventory)){ $inventory = 0; }
										elseif( $inventory < 0 ){ $inventory = 0; }

										$sku = $product_details->InventoryCode;
										// update_post_meta( $variationId, '_stock', $inventory );
										$stockStatus = ($inventory > 0) ? 'instock' : 'outofstock';
										self::updateProductAutumInventory($variationId,  $supplierId, $supplierName, $inventory, $stockStatus);
									}
								}

								
							}
						}
					} else {
						$swiftPosId = get_post_meta($productId, 'swiftpost_id', true);
						$function =  "Product/".$swiftPosId."";
						$data = '';
						$product_details = $sync->request($sync->key, $data, $function);
						if(!empty($product_details)) {
							$inventory = $product_details->StockLevel;
							if($inventory == null){ $inventory = 0; }
							elseif(empty($inventory)){ $inventory = 0; }
							elseif( $inventory < 0 ){ $inventory = 0; }

							$sku = $product_details->InventoryCode;
							$stockStatus = ($inventory > 0) ? 'instock' : 'outofstock';
							self::updateProductAutumInventory($productId,  $supplierId, $supplierName, $inventory, $stockStatus);
						}
					}
				}
			}
			if($syncWarehouse == 'Melbourne') {
				update_option("cronInventorySyncWarehouse","JVA");
			} else if ($syncWarehouse == 'JVA') {
				update_option("cronInventorySyncWarehouse","JAA");
			} else {
				update_option("cronInventorySyncWarehouse","Melbourne");
			}
		}
	}

	public function update_product_inventory_by_product_ids( $product_ids_for_inventory_update = array(), $syncWarehouse = '' ){
		global $woocommerce;

		if(empty($syncWarehouse)){
			$syncWarehouse = 'JVA';
		}

		switch ( $syncWarehouse ){
			case 'Melbourne':
				$location = self::get_swiftpos_creds_melbourne('locationId');
				$user = self::get_swiftpos_creds_melbourne('userId');
				$pass = self::get_swiftpos_creds_melbourne('password');
			break;
			case 'JVA' :
				$location = self::get_swiftpos_creds('locationId');
				$user = self::get_swiftpos_creds('userId');
				$pass = self::get_swiftpos_creds('password');
			break;
			case 'JAA':
				$location = self::get_swiftpos_creds_just_automiser('locationId');
				$user = self::get_swiftpos_creds_just_automiser('userId');
				$pass = self::get_swiftpos_creds_just_automiser('password');
			break;
		}

		$supplierData = self::getSupplier($location);
		if(!empty($supplierData)) {
			$supplierId = $supplierData->ID;
			$supplierName = $supplierData->post_title;
		}
		
		$sync = new SwiftPOS_Sync();
		$ApiKey = $sync->assign_api_key($location, $user, $pass);

		// var_dump($ApiKey);
		// var_dump($location);
		// var_dump($user);
		// var_dump($pass);
		// var_dump($supplierId);
		// var_dump($supplierName);

		$allProducts = $product_ids_for_inventory_update;
		if (!empty($allProducts)) {
			if($ApiKey == true){
				$i = 1;
				foreach($allProducts as $productId) {
					$i++;
					$productObject = wc_get_product( $productId );

					/** 
					 * COILS INVENTORY UPDATE EXCLUSION
					 * 
					 * Due to complicated stock quantity determination of coils
					 * I temporarily write this code to exclude the coils 
					 * in updating the inventory in this cron job
					 * 
					*/
					/* $product_categories = $productObject->get_category_ids();

					$_coils_slug = get_term_by('slug', 'coils', 'product_cat');

					if( ! empty($_coils_slug) && in_array( $_coils_slug->term_id, $product_categories) ) continue;
					
					 END OF COILS INVENTORY UPDATE EXCLUSION */

					if ($productObject->product_type == 'variable') {
						$productVariations = $productObject->get_available_variations();
						if(!empty($productVariations)) {
							foreach($productVariations as $variation) {
								
								$productTypeSKU = substr($variation['sku'], 7 ,1);
								
								// CHECK IF PRODUCT IS COIL
								if($productTypeSKU != false && strlen($productTypeSKU) == 1 && is_numeric($productTypeSKU) && ($productTypeSKU == 3 )) {
									
									$variationId = $productObject->get_id();

									$prodSKU = $productObject->get_sku();

									$typeSKU = substr($variation['sku'], 10 ,3);

									$packingSKU = substr($variation['sku'], 8 ,1);

									//$packingSKU = substr($variation['sku'], 8 ,1);

									$coil_box_products_ids = get_option('coil_box_products_ids_' . $prodSKU . '_' . $typeSKU, []);

									$function =  "Product/" . $coil_box_products_ids[0] . "";
									$data = '';
									$product_details = $sync->request($sync->key, $data, $function);

									if(!empty($product_details)) {
										
										$boxes = [
											'A' 	=> 15,
											'B'		=> 30,
											'C'		=> 50,
											'D'		=> 100
										];

										$iinventorySStock = $product_details->StockLevel;
										if($iinventorySStock == null){ $iinventorySStock = 0; }
										elseif(empty($iinventorySStock)){ $iinventorySStock = 0; }
										elseif( $iinventorySStock < 0 ){ $iinventorySStock = 0; }

										$box_actual_stock = floatval(abs($iinventorySStock)) * floatval($boxes[$packingSKU]);

										if(!empty($box_actual_stock)){
											$inventory = floatval($box_actual_stock) / floatval($packingSKU);
										}
										else{
											$inventory = 0;
										}

										// update_post_meta( $variationId, '_stock', $inventory );

										$stockStatus = ($inventory > 0) ? 'instock' : 'outofstock';

										self::updateProductAutumInventory($variationId,  $supplierId, $supplierName, $inventory, $stockStatus);
										
									}

								} else {
									$variationId = $variation['variation_id'];
									$variationSwiftPosId = get_post_meta($variationId, 'swiftpost_id', true);
									$function =  "Product/".$variationSwiftPosId."";
									$data = '';
									$product_details = $sync->request($sync->key, $data, $function);
									if(!empty($product_details)) {
										$inventory = $product_details->StockLevel;
										if($inventory == null){ $inventory = 0; }
										elseif(empty($inventory)){ $inventory = 0; }
										elseif( $inventory < 0 ){ $inventory = 0; }

										$sku = $product_details->InventoryCode;
										// update_post_meta( $variationId, '_stock', $inventory );
										$stockStatus = ($inventory > 0) ? 'instock' : 'outofstock';
										self::updateProductAutumInventory($variationId,  $supplierId, $supplierName, $inventory, $stockStatus);
									}
								}

								
							}
						}
					} else {
						$swiftPosId = get_post_meta($productId, 'swiftpost_id', true);
						$function =  "Product/".$swiftPosId."";
						$data = '';
						$product_details = $sync->request($sync->key, $data, $function);
						if(!empty($product_details)) {
							$inventory = $product_details->StockLevel;
							if($inventory == null){ $inventory = 0; }
							elseif(empty($inventory)){ $inventory = 0; }
							elseif( $inventory < 0 ){ $inventory = 0; }

							$sku = $product_details->InventoryCode;
							$stockStatus = ($inventory > 0) ? 'instock' : 'outofstock';
							self::updateProductAutumInventory($productId,  $supplierId, $supplierName, $inventory, $stockStatus);
						}
					}
				}
			}
		}
	}
	
    public function jva_match_cart_quantity_with_swiftpost() {
        global $woocommerce;
		$items = $woocommerce->cart->get_cart();
		$error = false;
		$notice = '';
		
        foreach($items as $item => $values) {
            $cartProduct =  wc_get_product( $values['data']->get_id()); 
			$productId = $values['product_id'];
			$variationId = $values['variation_id'];
            $produtTitle = $cartProduct->get_title();
			$productQuantity = $values['quantity'];
            $productPrice = get_post_meta($values['product_id'] , '_price', true);
			if($variationId != 0 && $variationId != '') {
				$result = $this->checkSwiftPostProductInventory($variationId, $produtTitle, $productQuantity);
			} else {
				$result = $this->checkSwiftPostProductInventory($productId, $produtTitle, $productQuantity);
			}
			if(!empty($result)) {
				$notice .= $result['notice'];
				$error = $result['error'];
			}
        }
        if($error) {
            wc_add_notice($notice, 'error');
        }
    }
	
	public function checkSwiftPostProductInventory($productId, $produtTitle, $productQuantity) {
		$syncWarehouse = array('Melbourne', 'JVA', 'JAA');
		$notice = '';
		$ID = get_post_meta($productId, 'swiftpost_id', true);
		$inventoryStock = 0;
		$totalInventoryStock = 0;
		$sync = new SwiftPOS_Sync();
		foreach($syncWarehouse as $warehouse) {
			switch ( $warehouse ){
				case 'JVA' :
					$location = self::get_swiftpos_creds('locationId');
					$user = self::get_swiftpos_creds('userId');
					$pass = self::get_swiftpos_creds('password');
				break;
				case 'Melbourne':
					$location = self::get_swiftpos_creds_melbourne('locationId');
					$user = self::get_swiftpos_creds_melbourne('userId');
					$pass = self::get_swiftpos_creds_melbourne('password');
				break;
				case 'JAA':
					$location = self::get_swiftpos_creds_just_automiser('locationId');
					$user = self::get_swiftpos_creds_just_automiser('userId');
					$pass = self::get_swiftpos_creds_just_automiser('password');
				break;
			}
			if($ID != false){
				$supplierData = self::getSupplier($location);
				if(!empty($supplierData)) {
					$supplierId = $supplierData->ID;
					$supplierName = $supplierData->post_title;
				}
				$ApiKey = $sync->assign_api_key($location, $user, $pass);
				$function =  "Product/".$ID."";
				$data = '';
				if($ApiKey == true){
					$product_details = $sync->request($sync->key, $data, $function);
					if(!empty($product_details)) {
						$inventoryStock = $product_details->StockLevel;
						if($inventoryStock == null){ $inventoryStock = 0; }
						elseif(empty($inventoryStock)){ $inventoryStock = 0; }
						elseif( $inventoryStock < 0 ){ $inventoryStock = 0; }

						$sku = $product_details->InventoryCode;
						$swiftpost_id = $product_details->Id;
						$stockStatus = ($inventoryStock > 0) ? 'instock' : 'outofstock';
						$this->updateProductAutumInventory($productId,  $supplierId, $supplierName, $inventoryStock, $stockStatus);
						$totalInventoryStock = $totalInventoryStock + $inventoryStock;
					}					
				}
			}
		}
		if($totalInventoryStock < $productQuantity) {
			$notice =  '<strong>'.$produtTitle.'</strong> quantity count ('.$productQuantity.') is not available. Update Quantity on <a href="/cart" style="color:#fff;"><strong>Cart</strong></a> Page. <br>';
			return array('notice' => $notice, 'error' => true);
		}
	}
	
	public function jva_action_swiftpos_process_sale(  $order_id, $posted_data, $order  ) { 
		$this->process_swiftpost_sale($order_id);
	}
	public function jva_action_swiftpos_make_sale(  $order_id ) {
		$_swiftpos_sale = get_post_meta( $order_id, '_swiftpost_sale_id', true);
		if ($_swiftpos_sale == '') {
			$this->make_swiftpost_sale($order_id);
		}
	}
	
	public function jva_sync_product()  { 
		if ( !wp_verify_nonce( $_REQUEST['nonce'], "jva_ajax_sync_product")) {
			exit("No naughty business please");
		}
		$reupload_images = false;
		if($_REQUEST["reupload_images"] == 'true'){
			$reupload_images = true;
		}
		$offset = $_REQUEST["offset"];
		$limit = $_REQUEST["limit"];
		$force_sync = $_REQUEST["force_sync"];
		$syncWarehouse = $_REQUEST['sync_warehouse'];
		$SwiftPOS_Sync = new SwiftPOS_Sync();
		$SwiftPOS_Sync->ajax_sync_products($reupload_images, $force_sync, $offset, $limit, $syncWarehouse);
	}
	
	public function jva_before_sync_product()  { 
		if ( !wp_verify_nonce( $_REQUEST['nonce'], "jva_ajax_sync_product")) {
			exit("No naughty business please");
		}
		$warehouse = $_REQUEST['warehouse'];
		if($warehouse != '') {
			$allWarehouse = explode(',', $warehouse);
			foreach($allWarehouse as $house) {
				update_option($house."_variationSync", 'false');
			}
		} 
		$SwiftPOS_Sync = new SwiftPOS_Sync();
		$SwiftPOS_Sync->ajax_before_sync_products();
	}
	
	public function jva_after_sync_product()  { 
		if ( !wp_verify_nonce( $_REQUEST['nonce'], "jva_ajax_sync_product")) {
			exit("No naughty business please");
		}
		$syncWarehouse = array();
		$warehouse = $_REQUEST['warehouse'];
		if($warehouse != '') {
			$allWarehouse = explode(',', $warehouse);
			foreach($allWarehouse as $house) { 
				$syncValue = get_option($house."_variationSync",true);
				if($syncValue == 'JVA' || $syncValue == 'Melbourne' || $syncValue == 'JAA') {
					$syncWarehouse[] = $syncValue;
				}
			}
		}
		sort($syncWarehouse); 
		sort($allWarehouse);
		if(count($syncWarehouse) == 3 ) {
			$SwiftPOS_Sync = new SwiftPOS_Sync();
			$SwiftPOS_Sync->ajax_after_sync_products();
		}
		//added by websupreme
        $SwiftPOS_Sync = new SwiftPOS_Sync();
        $SwiftPOS_Sync->heal_product_after_sync($allWarehouse);
	}
	
	
	/**
	 *	Create custom taxonomy for products 
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   static
	 */
	public function product_taxonomy_brand()  {
		$labels = array(
			'name'                       => 'Brands',
			'singular_name'              => 'Brand',
			'menu_name'                  => 'Brands',
			'all_items'                  => 'All Brands',
			'parent_item'                => 'Parent Brand',
			'parent_item_colon'          => 'Parent Brand:',
			'new_item_name'              => 'New Brand Name',
			'add_new_item'               => 'Add New Brand',
			'edit_item'                  => 'Edit Brand',
			'update_item'                => 'Update Brand',
			'separate_items_with_commas' => 'Separate Brand with commas',
			'search_items'               => 'Search Brands',
			'add_or_remove_items'        => 'Add or remove Brands',
			'choose_from_most_used'      => 'Choose from the most used Brands',
		);
		$args = array(
			'labels'                     => $labels,
			'hierarchical'               => true,
			'public'                     => true,
			'show_ui'                    => true,
			'show_admin_column'          => true,
			'show_in_nav_menus'          => true,
			'show_tagcloud'              => true,
		);
		register_taxonomy( 'brand', 'product', $args );
		register_taxonomy_for_object_type( 'brand', 'product' );
	}
	/**
	 *	Create brand taxonomy for products single page
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   static
	 */
	function action_product_meta_end() {
		global $product;
		$term_ids = wp_get_post_terms( $product->get_id(), 'brand', array('fields' => 'ids') );
		echo get_the_term_list( $product->get_id(), 'brand', '<span class="posted_in">' . _n( 'Brand:', 'Brands:', count( $term_ids ), 'woocommerce' ) . ' ', ', ', '</span>' );
	}
	/**
	 * Register all of the hooks related to the admin and public functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   static
	 */
	static function jvai_on_plugin_activation_tasks() {
		global $wpdb;
		$charset_collate = $wpdb->get_charset_collate();
		$swiftpost_products = $wpdb->prefix . "swiftpost_products"; 
		if($wpdb->get_var("SHOW TABLES LIKE '$swiftpost_products'") != $swiftpost_products) {
			
			$sql1 = "CREATE TABLE $swiftpost_products (
				id mediumint(9) NOT NULL AUTO_INCREMENT,
				title varchar(255) NOT NULL,
				swiftpost_id int NOT NULL,
				woocommerce_id int NOT NULL,
				inventory int NOT NULL,
				meta varchar(255) NOT NULL,
				UNIQUE KEY id (id)
			) $charset_collate;";

			require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
			dbDelta( $sql1 );
		}
	}
	/**
	 * Enqueue style and javascript files
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   public
	 */
	public function enqueue_styles_admin($hook) {
		wp_enqueue_style( 'jva-select2', '//cdn.jsdelivr.net/npm/select2@4.0.12/dist/css/select2.min.css', array(), $this->version, 'all' );
		wp_enqueue_style( 'jva-managment', plugin_dir_url( __FILE__ ) . 'css/class-jva-swiftpos-integration-admin.css', array(), $this->version, 'all' );
	}
	public function enqueue_scripts_admin($hook) {
		wp_register_script('jva-select2', '//cdn.jsdelivr.net/npm/select2@4.0.12/dist/js/select2.min.js', array('jquery'), $this->version, FALSE);
		wp_enqueue_script( 'jva-custom-js', plugin_dir_url( __FILE__ ) . 'js/class-jva-swiftpos-integration-admin.js', array( 'jquery', 'jva-select2' ), $this->version, false );
	}
	
	public function enqueue_styles_public($hook) {
		wp_enqueue_style( 'jva-managment', plugin_dir_url( __FILE__ ) . 'css/class-jva-swiftpos-integration-public.css', array(), $this->version, 'all' );


	}
	public function enqueue_scripts_public($hook) {

		wp_enqueue_script( 'jva-man', plugin_dir_url( __FILE__ ) . 'js/class-jva-swiftpos-integration-public.js', array( 'jquery' ), $this->version, false );
		$localizations = array( 
			'ajax_url' => admin_url( 'admin-ajax.php'), 
			'plugin_url' =>  plugin_dir_url( __FILE__ ),
			'actions' 		=> array(
				'getShippingNotice' 	=> 'jvaWPAJAXGetShippingNotice'
			)
		);
		wp_localize_script( 'jva-man', 'localizedVars', $localizations );
	}
	
	/**
	 * Returns the details needed for SwiftPOS API authentication.
	 * only accepts the following arguements: locationId, userId, password
	 *
	 * @since    1.0.0
	 * @access   static
	 */
	public static function get_swiftpos_creds($key) {
		$creds = get_option( 'swiftpos_creds' );
		if($key == 'locationId'){
			return (int)$creds['locationId'];
		}elseif($key == 'userId'){
			return (int)$creds['userId'];
		}elseif($key == 'password'){
			return $creds['password'];
		}
		return false;
	}
	
	public static function get_swiftpos_creds_melbourne($key) {
		$creds = get_option( 'swiftpos_creds_melbourne' );
		if($key == 'locationId'){
			return (int)$creds['melbourne_locationId'];
		}elseif($key == 'userId'){
			return (int)$creds['melbourne_userId'];
		}elseif($key == 'password'){
			return $creds['melbourne_password'];
		}
		return false;
	}
	
	public static function get_swiftpos_creds_just_automiser($key) {
		$creds = get_option( 'swiftpos_creds_jaa' );
		if($key == 'locationId'){
			return (int)$creds['jaa_locationId'];
		}elseif($key == 'userId'){
			return (int)$creds['jaa_userId'];
		}elseif($key == 'password'){
			return $creds['jaa_password'];
		}
		return false;
	}
	
	/**
	 *  Ajax Function
	 *
	 * @since    1.0.0
	 */	
	public function jva_ajax_callback_wp() {

		wp_die();
	}
	
	/**
	 *  Register SwiftPOS page and sub-page to wordpress dashboard
	 *
	 * @since    1.0.0
	 */
	public function swiftpost_integration_admin_page() {
		 add_menu_page(
			'SwiftPOS Integration',
			'SwiftPOS',
			'manage_options',
			'swiftpost-integration',
			array($this, 'swiftpost_integration_callback'),
			''
		);
		
		add_submenu_page( 'swiftpost-integration', 'Manage Products', 'Manage Products', 'manage_options', 'swiftpost-products', array($this, 'swiftpost_integration_category_callback'));
		
		add_submenu_page( 'swiftpost-integration', 'Manage States/Regions', 'Manage States/Regions', 'manage_options', 'swiftpost-states', array($this, 'swiftpost_integration_states_callback'));
		
		add_submenu_page( 'swiftpost-integration', 'Settings', 'Settings', 'manage_options', 'swiftpost-creds', array($this, 'swiftpost_integration_creds_callback'));
		
		if( function_exists('acf_add_options_page') ) {
 
			$option_page = acf_add_options_page(array(
				'page_title' 		=> 'Lookup Options',
				'menu_title' 		=> 'Lookup Options',
				'menu_slug' 		=> 'lookup-options',
				'position' 			=> true,
				'parent_slug'		=> 'swiftpost-integration',
				'capability' 		=> 'edit_posts',
				'autoload' 			=> true,
				'update_button'		=> __('Update', 'acf'),
				'updated_message'	=> __("Lookup Data Updated", 'acf'),
				'redirect'			=> false
			));

			$cart_rules_page = acf_add_options_page(array(
				'page_title' 		=> 'Cart Rules',
				'menu_title' 		=> 'Cart Rules',
				'menu_slug' 		=> 'cart-rules',
				'position' 			=> true,
				'parent_slug'		=> 'swiftpost-integration',
				'capability' 		=> 'edit_posts',
				'autoload' 			=> true,
				'update_button'		=> __('Update', 'acf'),
				'updated_message'	=> __("Cart Rules Updated", 'acf'),
				'redirect'			=> false
			));
 
		}
		
		add_submenu_page( 'swiftpost-integration', 'API Test', 'API Test', 'manage_options', 'swiftpost-apitest', array($this, 'swiftpost_integration_apitest_callback'));
		
	}
	
	public function swiftpost_integration_apitest_callback (){
		?>
		
		<table class="form-table">
			<tr>
				<td>
					<form method="post" enctype="multipart/form-data">
						<select name="wharehouse" >
							<option value="JVA">Just Vapours Australia</option>
							<option value="Melbourne">Melbourne</option>
							<option value="JAA">Just Atomisers Australia</option>
						</select>
						<?php submit_button('Save'); ?>
					</form>
				</td>
			</tr>
		</table>
		<?php
		if(isset($_POST) && $_POST['wharehouse'] == 'JVA') {
			$key = 0;
			$location = self::get_swiftpos_creds('locationId');
			$user = self::get_swiftpos_creds('userId');
			$pass = self::get_swiftpos_creds('password');
			$sync = new SwiftPOS_Sync();
			$ApiKey = $sync->assign_api_key($location, $user, $pass);
			if($ApiKey == true){
				$family = $sync->get_family();
				if($family == false){
					return false;
				}
				$data = array('includeImage' => true, 'familyId'=> $family[0]);
				$all_products = $sync->request($sync->key, $data, "Product");
			}
		} else if(isset($_POST) && $_POST['wharehouse'] == 'Melbourne') {
			$key = 0;
			$location = self::get_swiftpos_creds_melbourne('locationId');
			$user = self::get_swiftpos_creds_melbourne('userId');
			$pass = self::get_swiftpos_creds_melbourne('password');
			$sync = new SwiftPOS_Sync();
			$ApiKey = $sync->assign_api_key($location, $user, $pass);
			if($ApiKey == true){
				$family = $sync->get_family();
				if($family == false){
					return false;
				}
				$data = array('includeImage' => true, 'familyId'=> $family[0]);
				$all_products = $sync->request($sync->key, $data, "Product");
			}
		} else if(isset($_POST) && $_POST['wharehouse'] == 'JAA') {
			$key = 0;
			$location = self::get_swiftpos_creds_just_automiser('locationId');
			$user = self::get_swiftpos_creds_just_automiser('userId');
			$pass = self::get_swiftpos_creds_just_automiser('password');
			$sync = new SwiftPOS_Sync();
			$ApiKey = $sync->assign_api_key($location, $user, $pass);
			if($ApiKey == true){
				$family = $sync->get_family();
				if($family == false){
					return false;
				}
				$data = array('includeImage' => true, 'familyId'=> $family[0]);
				$all_products = $sync->request($sync->key, $data, "Product");
			}
		}
		echo '<br>Location: '.$location;
		echo '<br>User: '.$user;
		echo '<br>Pass: '.$pass;
		echo '<br>ApiKey: '.$ApiKey;
		echo '<br>family: '; print_r($family);
		echo '<br>Data: '; print_r($data);
		echo '<br>All Products: '; 
		echo '<pre>';
		print_r($all_products);
		echo '</pre>';
	}
	public function api_key_get($key, $data, $function, $request = "GET"){
		
		if($key === 0){
			$headers = array(
				'Content-Type: application/json',
				'Accept' => 'application/json',
			);
		}else{
			$headers = array(
				'Content-Type: application/json',
				'Accept' => 'application/json',
				'ApiKey: '.$key.''
			);
		}

		if($request == "GET" && !empty($data)){
			if(!empty($data['includeImage']) && $data['includeImage'] == true){
				unset($data['includeImage']);
				$query = http_build_query($data, '', '&');
				$query .= "&includeImage=true";
				
			}else{
				$query = http_build_query($data, '', '&');
			}
			//$url = "http://webstores.swiftpos.com.au:4000/SwiftApi/api/".$function."?".$query."";
			$url = "http://52.255.32.168:4000/WebApi/api/".$function."?".$query."";
		}else{
			//$url = "http://webstores.swiftpos.com.au:4000/SwiftApi/api/".$function."";
			$url = "http://52.255.32.168:4000/WebApi/api/".$function."";
		}
		$ccurl = curl_init($url); 
		curl_setopt($ccurl, CURLOPT_CUSTOMREQUEST, $request); 
		curl_setopt($ccurl, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($ccurl, CURLOPT_SSL_VERIFYPEER, 0 );
		curl_setopt($ccurl, CURLOPT_RETURNTRANSFER, 1 );
		if($request == "POST"){
			curl_setopt($ccurl, CURLOPT_POSTFIELDS, json_encode($data));
		}
		$result = curl_exec($ccurl);
		$httpcode = curl_getinfo($ccurl, CURLINFO_HTTP_CODE);
		curl_close($ccurl);
		$decoded_result = json_decode($result);
		if($httpcode == 200 || $httpcode == 201){
			return $decoded_result;
		}else{
			$this->errors = array('key'=> $key, 'data'=> $data, 'function'=> $function, 'response'=> $decoded_result);
			return false;
		}
	}
	/**
	 *  SwiftPOS credentials settings page callback (swiftpost_integration_admin_page)
	 *
	 * @since    1.0.0
	 */	
	public function swiftpost_integration_category_callback() {
		if(!empty($_POST)){
			$selected_cat = $_POST['category-select'];
			
			$args = array(
			'post_type'             => 'product',
			'post_status'           => 'publish',
			'posts_per_page'        => -1,
			'tax_query'             => array(
					array(
						'taxonomy'      => 'product_cat',
						'field' 		=> 'term_id', //This is optional, as it defaults to 'term_id'
						'terms'         => $selected_cat,
						'operator'      => 'IN' // Possible values are 'IN', 'NOT IN', 'AND'.
					),
				)
			);
		

			if( !empty($_POST['publish']) ){
				$args['post_status'] = 'draft';
				$products = new WP_Query($args);
				
				while ( $products->have_posts() ) { $products->the_post();
					global $product; 
					$product_id = $product->get_id();
					
					wp_update_post(array(
						'ID'    =>  $product_id,
						'post_status'   =>  'publish'
					));
				}
				wp_reset_query(); 
				
				echo '<p style="color:green;">Product in the selected category were successfully published</p>';

			}elseif( !empty($_POST['unpublish']) ){
				$products = new WP_Query($args);
				
				while ( $products->have_posts() ) { $products->the_post();
					global $product; 
					$product_id = $product->get_id();
					wp_update_post(array(
						'ID'    =>  $product_id,
						'post_status'   =>  'draft'
					));
				}
				wp_reset_query(); 
				echo '<p style="color:green;">Product in the selected category were successfully unpublished</p>';
			}
		}
		
?>
<style>
div#swiftpost_integration {
    background: #fff;
    padding: 30px;
    margin-top: 20px;
    box-shadow: 0 0px 19px rgba(130, 130, 130, 0.12), 0 1px 4px rgba(132, 132, 132, 0.16);
}
ul {
    list-style: inside;
}
.divider {
    border-top: 3px solid #f1f1f1;
}
p.submit {
    display: inline-block;
    margin: 0px;
    margin-left: 5px;
}
</style>
		<div id="swiftpost_integration">
			<h1>Manage Products status</h1>
			<h3>Publish or unpublish product of a specific category</h3>

			<form method="post" enctype="multipart/form-data">
				<?php
				$taxonomy     = 'product_cat';
				$orderby      = 'name';  
				$show_count   = 0;      // 1 for yes, 0 for no
				$pad_counts   = 0;      // 1 for yes, 0 for no
				$hierarchical = 1;      // 1 for yes, 0 for no  
				$empty        = 0;

				$args = array(
					 'taxonomy'     => $taxonomy,
					 'orderby'      => $orderby,
					 'show_count'   => $show_count,
					 'pad_counts'   => $pad_counts,
					 'hierarchical' => $hierarchical,
					 'hide_empty'   => $empty
				);
				$all_categories = get_categories( $args );
				echo '<label for="category-select" class="cat-select">Category: </label>';
				echo '<select id="category-select" name= "category-select" >';
				foreach ($all_categories as $cat) {
					if($cat->category_parent == 0) {
						$category_slug = $cat->slug;
						echo '<option value="'. $cat->term_id .'">'. $cat->name .'</option>';
					}
				}
				echo '</select>';
				?>
				<?php submit_button('Publish Products', 'publish', 'publish' ) ?> <?php submit_button('Unpublish Products', 'unpublish', 'unpublish') ?>
			</form>

		</div>
	<?php
	
	}
	
	/**
	 *  SwiftPOS credentials settings page callback (swiftpost_integration_admin_page)
	 *
	 * @since    1.0.0
	 */	
	public function swiftpost_integration_creds_callback() {
		global $pagenow;
		if(!empty($_POST)){
			if(isset($_POST['wharehouse']) && $_POST['wharehouse'] == 'jva') {
				$locationId = isset($_POST['locationId']) ? $_POST['locationId'] : "";
				$userId = isset($_POST['userId']) ? $_POST['userId'] : "";
				$password = isset($_POST['password']) ? $_POST['password'] : "";

				$swiftpos_creds = array(
									'locationId'=> $locationId,
									'userId'=> $userId,
									'password'=> $password,
									);
									
				update_option( 'swiftpos_creds', $swiftpos_creds );
			}
			if(isset($_POST['wharehouse']) && $_POST['wharehouse'] == 'melbourne') {
				$locationId = isset($_POST['melbourne_locationId']) ? $_POST['melbourne_locationId'] : "";
				$userId = isset($_POST['melbourne_userId']) ? $_POST['melbourne_userId'] : "";
				$password = isset($_POST['melbourne_password']) ? $_POST['melbourne_password'] : "";

				$swiftpos_creds = array(
									'melbourne_locationId'=> $locationId,
									'melbourne_userId'=> $userId,
									'melbourne_password'=> $password,
									);
									
				update_option( 'swiftpos_creds_melbourne', $swiftpos_creds );
			}
			
			if(isset($_POST['wharehouse']) && $_POST['wharehouse'] == 'jaa') {
				$locationId = isset($_POST['jaa_locationId']) ? $_POST['jaa_locationId'] : "";
				$userId = isset($_POST['jaa_userId']) ? $_POST['jaa_userId'] : "";
				$password = isset($_POST['jaa_password']) ? $_POST['jaa_password'] : "";

				$swiftpos_creds = array(
									'jaa_locationId'=> $locationId,
									'jaa_userId'=> $userId,
									'jaa_password'=> $password,
									);
									
				update_option( 'swiftpos_creds_jaa', $swiftpos_creds );
			}
		}
		
		$creds = get_option( 'swiftpos_creds' );
		$melbourne_creds = get_option( 'swiftpos_creds_melbourne' );
		$jaa_creds = get_option( 'swiftpos_creds_jaa' );
?>
		<style>
		div#swiftpost_integration {
			background: #fff;
			padding: 30px;
			margin-top: 20px;
			box-shadow: 0 0px 19px rgba(130, 130, 130, 0.12), 0 1px 4px rgba(132, 132, 132, 0.16);
		}
		ul {
			list-style: inside;
		}
		.divider {
			border-top: 3px solid #f1f1f1;
		}
		</style>
		<div id="swiftpost_integration">
			<h1>SwiftPOS Settings</h1>
			<h3>Authenticatation details:</h3>
			<h2 class="nav-tab-wrapper">
				<?php if ( isset ( $_GET['tab'] ) ) $tab = $_GET['tab']; else $tab = 'jva'; ?>
				<a class='nav-tab <?php echo ( $tab == "jva" ) ? " nav-tab-active" : "";?>' href='?page=swiftpost-creds&tab=jva'>Just Vapours Australia (Main Wharehouse)</a>
				<a class='nav-tab <?php echo ( $tab == "melbourne" ) ? " nav-tab-active" : "";?>' href='?page=swiftpost-creds&tab=melbourne'>Melbourne Wharehouse</a>
				<a class='nav-tab <?php echo ( $tab == "jaa" ) ? " nav-tab-active" : "";?>' href='?page=swiftpost-creds&tab=jaa'>Just Atomisers Australia Wharehouse</a>
			</h2>
			<?php 
				if ( $pagenow == 'admin.php' && $_GET['page'] == 'swiftpost-creds' ){
					if ( isset ( $_GET['tab'] ) ) $tab = $_GET['tab']; 
					else $tab = 'jva';
					?>
					<table class="form-table">
						<?php
						switch ( $tab ){
							case 'jva' :
						?>
								<tr>
									<th>Just Vapours Australia (Main Wharehouse)</th>
								</tr>
								<tr>
									<td>
										<form method="post" enctype="multipart/form-data">
											<input type="hidden" name="wharehouse" value="jva"/>
											<p>
												<label for="locationId"><b><span style="position:relative;top: -2px;display:block;">Location to request an api key for :</span></b></label>
												<input type='text' id='locationId' name='locationId' value="<?php if(isset($creds['locationId'])){ echo $creds['locationId']; } ?>" placeholder="locationId"></input>
											</p>
											<p>
												<label for="userId"><b><span style="position:relative;top: -2px;display:block;">Clerk Id:</span></b></label>
												<input type='text' id='userId' name='userId' value="<?php if(isset($creds['userId'])){ echo $creds['userId']; } ?>" placeholder="userId"></input>
											</p>
											<p>
												<label for="locationId"><b><span style="position:relative;top: -2px;display:block;">Clerk Password:</span></b></label>
												<input type='text' id='password' name='password' value="<?php if(isset($creds['password'])){ echo $creds['password']; } ?>" placeholder="password"></input>
											</p>
												<?php submit_button('Save') ?>
										</form>
									</td>
								</tr>
							<?php break; 
							case 'melbourne':
							?>
								<tr>
									<th>Melbourne Wharehouse</th>
								</tr>
								<tr>
									<td>
										<form method="post" enctype="multipart/form-data">
											<input type="hidden" name="wharehouse" value="melbourne"/>
											<p>
												<label for="melbourne_locationId"><b><span style="position:relative;top: -2px;display:block;">Location to request an api key for :</span></b></label>
												<input type='text' id='melbourne_locationId' name='melbourne_locationId' value="<?php if(isset($melbourne_creds['melbourne_locationId'])){ echo $melbourne_creds['melbourne_locationId']; } ?>" placeholder="locationId"></input>
											</p>
											<p>
												<label for="melbourne_userId"><b><span style="position:relative;top: -2px;display:block;">Clerk Id:</span></b></label>
												<input type='text' id='melbourne_userId' name='melbourne_userId' value="<?php if(isset($melbourne_creds['melbourne_userId'])){ echo $melbourne_creds['melbourne_userId']; } ?>" placeholder="userId"></input>
											</p>
											<p>
												<label for="melbourne_locationId"><b><span style="position:relative;top: -2px;display:block;">Clerk Password:</span></b></label>
												<input type='text' id='melbourne_password' name='melbourne_password' value="<?php if(isset($melbourne_creds['melbourne_password'])){ echo $melbourne_creds['melbourne_password']; } ?>" placeholder="password"></input>
											</p>
												<?php submit_button('Save') ?>
										</form>
									</td>
								</tr>
							<?php
								break; 
							case 'jaa':
							?>
								<tr>
									<th>Just Atomisers Australia Wharehouse</th>
								</tr>
								<tr>
									<td>
										<form method="post" enctype="multipart/form-data">
											<input type="hidden" name="wharehouse" value="jaa"/>
											<p>
												<label for="jaa_locationId"><b><span style="position:relative;top: -2px;display:block;">Location to request an api key for :</span></b></label>
												<input type='text' id='jaa_locationId' name='jaa_locationId' value="<?php if(isset($jaa_creds['jaa_locationId'])){ echo $jaa_creds['jaa_locationId']; } ?>" placeholder="locationId"></input>
											</p>
											<p>
												<label for="jaa_userId"><b><span style="position:relative;top: -2px;display:block;">Clerk Id:</span></b></label>
												<input type='text' id='jaa_userId' name='jaa_userId' value="<?php if(isset($jaa_creds['jaa_userId'])){ echo $jaa_creds['jaa_userId']; } ?>" placeholder="userId"></input>
											</p>
											<p>
												<label for="jaa_locationId"><b><span style="position:relative;top: -2px;display:block;">Clerk Password:</span></b></label>
												<input type='text' id='jaa_password' name='jaa_password' value="<?php if(isset($jaa_creds['jaa_password'])){ echo $jaa_creds['jaa_password']; } ?>" placeholder="password"></input>
											</p>
												<?php submit_button('Save') ?>
										</form>
									</td>
								</tr>
							<?php
						}
						?>		
					</table>
			<?php } ?>
		</div>
	<?php
	
	}
	
	/**
	 *  SwiftPOS integration page callback (swiftpost_integration_admin_page)
	 *
	 * @since    1.0.0
	 */	
	public function swiftpost_integration_callback() {
	?>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>	
		<style>
		div#swiftpost_integration, div#swiftpost_integration_sync  {
			background: #fff;
			padding: 30px;
			margin-top: 20px;
			box-shadow: 0 0px 19px rgba(130, 130, 130, 0.12), 0 1px 4px rgba(132, 132, 132, 0.16);
		}
		ul {
			list-style: inside;
		}
		.divider {
			border-top: 3px solid #f1f1f1;
		}
		#swiftpost_integration h1 {
			font-size: 2em !important; 
			margin: .67em 0 !important; 
		}
		#swiftpost_integration h3 {
			font-size: 1.3em !important; 
			margin: 1em 0 !important; 
		}
		#swiftpost_integration label {
			margin-bottom: 0px !important;
			vertical-align: -webkit-baseline-middle !important;
		}
		.progress {
			margin-bottom: 5px !important;
		}
		</style>
		<div id="swiftpost_integration">
			<h1>SwiftPOS Synchronization</h1>
			<h3>The button below will sync the following:</h3>
			<ul>
				<li>Product information</li>
				<li>Stock of items</li>
				<li>Client information</li>
			</ul>
			<form method="post" enctype="multipart/form-data">
					<input type='hidden' id='sync_swiftpost' name='sync_swiftpost' value="sync" />
					<label for="warehouse">
						<b><span style="position:relative;top: -2px;">Select Warehouse:</span></b>
					</label>
					<input type='checkbox' id='sync_warehouse_melbourne' name='sync_warehouse[]' value="Melbourne" checked="checked" disabled /> 
					<span style="position:relative;top: 3px;">Melbourne</span>
					<input type='checkbox' id='sync_warehouse_jva' name='sync_warehouse[]' value="JVA" checked="checked" disabled /> 
					<span style="position:relative;top: 3px;">Just Vapours Australia</span>
					<input type='checkbox' id='sync_warehouse_jaa' name='sync_warehouse[]' value="JAA" checked="checked" disabled />
					<span style="position:relative;top: 3px;">Just Atomisers Australia </span>
					<br/>
					<label for="reupload_images">
						<b><span style="position:relative;top: -2px;">Re-upload images for existing products:</span></b>
					</label>
					<input type='checkbox' id='reupload_images' name='reupload_images' value="image_refresh" />
					<br/>
					<label for="sync_swiftpost">
						<b><span style="position:relative;top: -2px;">Force Sync SwiftApi: </span></b>
					</label>
					<input type='checkbox' id='reupload_images' name='force_sync' value="image_refresh" />
					<?php //submit_button('Start Synchronization', 'primary', 'submit', true ); ?>
			</form>
			<div>&nbsp;</div>
			<p class="asyncButton">
				<?php 
				update_option("variationSync", "");
				$nonce = wp_create_nonce("jva_ajax_sync_product");
				$link = admin_url('admin-ajax.php?action=jva_sync_product&nonce='.$nonce);
				echo '<a class="button button-primary" href="javascript:void(0)">Start Synchronization</a>';
				?>
			</p>
			<div class="sync progress hidden">
				<div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width:0%">
				  0% Completed
				</div>
			</div>
			<p class="Synched"></p>
			<p class="loading hidden">Syncing <b><span class="warehouse"></span> Warehouse</b> Products, Please wait <img style="vertical-align:bottom;" src="<?php echo plugins_url(); ?>/jva-swiftpos-integration/includes/images/loader.gif" /></p>
			
			
		<?php
		if(!empty($_POST['sync_swiftpost']) && $_POST['sync_swiftpost'] == 'sync'){
			$reupload_images = !empty($_POST['reupload_images']) ? true : false;
			$force_sync = !empty($_POST['force_sync']) ? true : false;
			$sync = $this->swiftpost_synchronization_callback($reupload_images,$force_sync);
			if($sync->status == true){
				?>
					<div class="divider"></div>
					<p style="font-weight:bold; color:green;">Synchronization was successfully completed</p>
					<?php echo $sync->msg; ?>
				<?php
			}else{
				?>
					<div class="divider"></div>
					<p style="font-weight:bold; color:red;">Synchronization was not successfully completed</p>
					<?php echo $sync->msg; ?>
				<?php
			}
		}
		?>
		</div>
		<div id="swiftpost_integration_sync" class="hidden">
			<p class="sync logs hidden">Sync Logs :</p>
			<p class="statusSync"></p>
		</div>
		<script>
			jQuery(document).ready(function(){
				jQuery(".asyncButton").click(function(){
					var updateTotal = '<?php update_option("totalVariation",""); ?>';
					var warehouseTitle = { 'JVA' : 'Just Vapours Australia', 'Melbourne': 'Melbourne', 'JAA' : 'Just Atomisers Australia'};
					var offset = 0;
					var limit = 5;
					jQuery("p.statusSync").html("");
					jQuery(".sync.progress .progress-bar").css("width","0%");
					jQuery(".sync.progress .progress-bar").html("0% Completed");
					var force_sync =  jQuery('input[name="force_sync"]'). prop("checked");
					var syncWarehouseJva = jQuery('input#sync_warehouse_jva'). prop("checked");
					var syncWarehouseMelbourne = jQuery('input#sync_warehouse_melbourne'). prop("checked");
					var syncWarehouseJaa = jQuery('input#sync_warehouse_jaa'). prop("checked");
					var syncWarehouse = [];
					if(syncWarehouseMelbourne) { 
						syncWarehouse.push('Melbourne');
					}
					if(syncWarehouseJva) { 
						syncWarehouse.push('JVA');
					}
					if(syncWarehouseJaa) { 
						syncWarehouse.push('JAA');
					}
					updateAllProductMeta(syncWarehouse);
					var warehouse = syncWarehouse[0];
					if(warehouse != '' && warehouse != undefined) {
						jQuery("p.statusSync").append('Syncing Warehouse :<b>' + warehouseTitle[warehouse] + '</b><br/>');
						do_ajax(offset, limit, force_sync, warehouse, syncWarehouse);
					} else {
						jQuery("p.statusSync").append('Please select a warehouse.<br/>');
					}
				});
				function do_ajax(offset, limit, force_sync, warehouse, syncWarehouse) {
					var warehouseTitle = { 'JVA' : 'Just Vapours Australia', 'Melbourne': 'Melbourne', 'JAA' : 'Just Atomisers Australia'};
					jQuery("p.asyncButton").addClass("hidden");
					jQuery("p.loading").removeClass("hidden");
					jQuery("p.loading span.warehouse").html(warehouseTitle[warehouse]);
					jQuery(".sync.progress").removeClass("hidden");
					jQuery("#swiftpost_integration_sync").removeClass("hidden");
					jQuery(".sync.logs").removeClass("hidden");
					var reupload_images =  jQuery('input[name="reupload_images"]'). prop("checked");
					jQuery.ajax({
						url: '<?php echo $link; ?>&force_sync='+force_sync+'&reupload_images='+reupload_images+'&sync_warehouse='+warehouse+'&offset='+offset+'&limit='+limit,
						success: function(result){
							var result = JSON.parse(result);
							if(result != undefined) {
								var msg = result['msg'];
								var variation = result['variation'];
								var totalVariation =  result['totalVariation'];
								var status = result['status'];
								if(status == false) {
									jQuery("p.loading").addClass("hidden");
								}
								
								console.log(result);
								console.log(warehouse+' - '+totalVariation);
								
								jQuery("p.statusSync").append(msg);
								if(parseFloat(variation) >= parseFloat(totalVariation)) {
									jQuery(".sync.progress .progress-bar").css("width","100%");
									jQuery(".sync.progress .progress-bar").html("100% Completed");
									if(warehouse == 'Melbourne' && syncWarehouse[0] == 'Melbourne' && syncWarehouse[1] != '' && syncWarehouse[1] != undefined) {
										jQuery("p.Synched").append(warehouseTitle[warehouse]+ " 100% Completed. <br>");
										warehouse = syncWarehouse[1];
										offset = 0;
										limit = 5;
										jQuery(".sync.progress .progress-bar").css("width","0%");
										jQuery(".sync.progress .progress-bar").html("0% Completed");
										force_sync =  jQuery('input[name="force_sync"]'). prop("checked");
										jQuery("p.statusSync").append('Syncing Warehouse :<b>' + warehouseTitle[warehouse] + '</b><br/>');
										do_ajax(offset, limit, force_sync, warehouse, syncWarehouse);
									} else if(warehouse == 'JVA' && syncWarehouse[0] == 'JVA' && syncWarehouse[1] != '' && syncWarehouse[1] != undefined) {
										jQuery("p.Synched").append(warehouseTitle[warehouse]+ " 100% Completed. <br>");
										warehouse = syncWarehouse[1];
										offset = 0;
										limit = 5;
										jQuery(".sync.progress .progress-bar").css("width","0%");
										jQuery(".sync.progress .progress-bar").html("0% Completed");
										force_sync =  jQuery('input[name="force_sync"]'). prop("checked");
										jQuery("p.statusSync").append('Syncing Warehouse :<b>' + warehouseTitle[warehouse] + '</b><br/>');
										do_ajax(offset, limit, force_sync, warehouse, syncWarehouse);
									} else if(warehouse == 'JVA' && syncWarehouse[1] == 'JVA' && syncWarehouse[2] != '' && syncWarehouse[2] != undefined) {
										jQuery("p.Synched").append(warehouseTitle[warehouse]+ " 100% Completed. <br>");
										warehouse = syncWarehouse[2];
										offset = 0;
										limit = 5;
										jQuery(".sync.progress .progress-bar").css("width","0%");
										jQuery(".sync.progress .progress-bar").html("0% Completed");
										force_sync =  jQuery('input[name="force_sync"]'). prop("checked");
										jQuery("p.statusSync").append('Syncing Warehouse :<b>' + warehouseTitle[warehouse] + '</b><br/>');
										do_ajax(offset, limit, force_sync, warehouse, syncWarehouse);
									}else {
										jQuery("p.Synched").append(warehouseTitle[warehouse]+ " 100% Completed. <br>");
										jQuery("p.asyncButton").removeClass("hidden");
										jQuery("p.loading").addClass("hidden");
									}
								} else if(variation <= limit && parseFloat(variation) < parseFloat(totalVariation)) {
									var percentageCompleted = (parseFloat(variation) / parseFloat(totalVariation))*100;
									jQuery(".sync.progress .progress-bar").css("width",percentageCompleted+"%");
									jQuery(".sync.progress .progress-bar").html(parseFloat(percentageCompleted).toFixed(0)+" % Completed");
									offset = offset + 5;
									limit = limit + 5;
									force_sync = false
									do_ajax(offset, limit, force_sync, warehouse, syncWarehouse);
								}
							} else {
								jQuery("p.loading").addClass("hidden");
								jQuery(".sync.progress .progress-bar").addClass("hidden");
								jQuery("p.asyncButton").removeClass("hidden");
							}
							
						},
						complete: function(result){
							trashProduct(syncWarehouse);
						}
					});
				}
				
				function updateAllProductMeta(syncWarehouse){
					jQuery.ajax({
						url: '<?php echo admin_url("admin-ajax.php?action=jva_before_sync_product&nonce=".$nonce); ?>&warehouse='+syncWarehouse,
						success: function(result){
							console.log(result);
						}
					});
				}
				
				function trashProduct(syncWarehouse){
					jQuery.ajax({
						url: '<?php echo admin_url("admin-ajax.php?action=jva_after_sync_product&nonce=".$nonce); ?>&warehouse='+syncWarehouse,
						success: function(result){
							console.log(result);
						}
					});
				}

			});
		</script>
	<?php
	

	}
	/**
	 *  SwiftPOS Process Sale callback (not used)
	 *
	 * @since    1.0.0
	 */	
	public function process_swiftpost_sale($order_id) {
		$location = self::get_swiftpos_creds('locationId');
		$user = self::get_swiftpos_creds('userId');
		$pass = self::get_swiftpos_creds('password');
		
		$sync = new SwiftPOS_Sync();
		$ApiKey = $sync->assign_api_key($location, $user, $pass);
		if($ApiKey == true){
			$response = $sync->process_sale($order_id);
			return $response;
		}
		die;
		return false;
	}

	/**
	 *  SwiftPOS Sale callback (not used)
	 *
	 * @since    1.0.0
	 */	
	public function make_swiftpost_sale($order_id) {
		$response = false;
		$sync = new SwiftPOS_Sync();
		$response = $sync->make_sale($order_id);
		return $response;
	}

	/**
	 *  SwiftPOS Order callback (not used)
	 *
	 * @since    1.0.0
	 */	
	public function make_swiftpost_order($order_id) {

		$location = self::get_swiftpos_creds('locationId');
		$user = self::get_swiftpos_creds('userId');
		$pass = self::get_swiftpos_creds('password');
		
		$sync = new SwiftPOS_Sync();
		$ApiKey = $sync->assign_api_key($location, $user, $pass);
		if($ApiKey == true){
			$response = $sync->make_order($order_id);
			return $response;
		}
		
		return false;
	}
	/**
	 *  SwiftPOS synchronization callback
	 *
	 * @since    1.0.0
	 */	
	public function swiftpost_synchronization_callback($reupload_images = false, $force_sync) {

		$location = self::get_swiftpos_creds('locationId');
		$user = self::get_swiftpos_creds('userId');
		$pass = self::get_swiftpos_creds('password');
		
		$sync = new SwiftPOS_Sync();
		$ApiKey = $sync->assign_api_key($location, $user, $pass);
		if($ApiKey == true){
			$response = $sync->sync_products($reupload_images, $force_sync);
			return $response;
		}
		
		return false;
	}
	
	/**
	 *  WooCommerce ThankYou callback
	 *
	 * @since    1.0.0
	 */	
	public function jva_order_thankyou($order_id) {
		
		// Trigger a new sale on SwiftPOS and async order items stock.
		$url = plugin_dir_url( dirname( __FILE__ ) ) . 'includes/actions/sale-finalize.php';
		$params = array('order_id' => $order_id);
		$this->post_async($url, $params);
		
	}
	
	public static function get_productid_by_swiftpostid ( $swiftPOS_id ) {
		global $wpdb;
		$product_id = '';
		$product_table_name = $wpdb->prefix . 'swiftpost_products';
		$product = $wpdb->get_results("SELECT woocommerce_id FROM $product_table_name WHERE swiftpost_id = $swiftPOS_id");

		if(!empty($product)) {
			$product_id = $product[0]->woocommerce_id;
		}
		
		return $product_id; 
	}
	
	public static function get_swiftpostid_by_productid ( $productID ) { 
		global $wpdb;
		$product_table_name = $wpdb->prefix . 'swiftpost_products';
		$product = $wpdb->get_results("SELECT swiftpost_id FROM $product_table_name WHERE woocommerce_id = $productID");

		$product_id = $product[0]->swiftpost_id;
		
		return $product_id; 
	}
	
	public static function get_product_meta ( $productID ) { 
		global $wpdb;
		$product_table_name = $wpdb->prefix . 'swiftpost_products';
		$product = $wpdb->get_results("SELECT meta FROM $product_table_name WHERE woocommerce_id = $productID");

		$product_meta = $product[0]->meta;
		
		return $product_meta; 
	}
	
	public static function insert_new_product ( $woocommerce_id, $swiftpost_id, $inventory, $meta = "" ) { 
		global $wpdb;
		$product_table_name = $wpdb->prefix . 'swiftpost_products';
		$respnse = $wpdb->insert($product_table_name, array('swiftpost_id' => $swiftpost_id, 'woocommerce_id' => $woocommerce_id, 'inventory' => $inventory, 'meta' => $meta), array('%d', '%d', '%s') ); 

		return $respnse; 
	}
	
	public static function update_product_inventory ( $swiftpost_id, $product_id, $stock ) { 
		global $wpdb;
		$product_table_name = $wpdb->prefix . 'swiftpost_products';
		update_post_meta( $product_id, '_stock', $stock );
		$respnse = $wpdb->update(
						$product_table_name, 
						array( 
							'inventory' => $stock
						), 
						array( 
							'swiftpost_id' => $swiftpost_id
						), 
						array( 
							'%d'
						), 
						array( '%d' ) 
					);

		return $respnse; 
	}

	public static function update_product_inventory_but_not_in_post ( $swiftpost_id, $product_id, $stock ) { 
		global $wpdb;
		$product_table_name = $wpdb->prefix . 'swiftpost_products';
		// update_post_meta( $product_id, '_stock', $stock );
		$respnse = $wpdb->update(
						$product_table_name, 
						array( 
							'inventory' => $stock
						), 
						array( 
							'swiftpost_id' => $swiftpost_id
						), 
						array( 
							'%d'
						), 
						array( '%d' ) 
					);

		return $respnse; 
	}
	
	public function post_async($url, array $params){
		foreach ($params as $key => &$val) {
		  if (is_array($val)) $val = implode(',', $val);
			$post_params[] = $key.'='.urlencode($val);  
		}
		$post_string = implode('&', $post_params);

		$parts=parse_url($url);

		$fp = fsockopen($parts['host'],
			isset($parts['port'])?$parts['port']:80,
			$errno, $errstr, 30);

		$out = "POST ".$parts['path']." HTTP/1.1\r\n";
		$out.= "Host: ".$parts['host']."\r\n";
		$out.= "Content-Type: application/x-www-form-urlencoded\r\n";
		$out.= "Content-Length: ".strlen($post_string)."\r\n";
		$out.= "Connection: Close\r\n\r\n";
		if (isset($post_string)) $out.= $post_string;

		fwrite($fp, $out);
		fclose($fp);
	}
	
	public static function  clean_name($string) {
	   $string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.
	   $string = preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
	   $string = strtolower($string); // Turn all into lowercase

	   return preg_replace('/-+/', '-', $string); // Replaces multiple hyphens with single one.
	}		
	
	/**************Create Product Variation********************/
	
	/**  * Save a new product attribute from his name (slug)  */
	public function save_product_attribute_from_name( $name, $label='', $set=true ) {
		global $wpdb;

		$label = $label == '' ? ucfirst($name) : $label;
		$attribute_id = self::get_attribute_id_from_name( $name );

		if( empty($attribute_id) ){
			$attribute_id = NULL;
		} else {
			$set = false;
		}
		$args = array(
			'attribute_id'      => $attribute_id,
			'attribute_name'    => $name,
			'attribute_label'   => $label,
			'attribute_type'    => 'select',
			'attribute_orderby' => 'menu_order',
			'attribute_public'  => 0,
		);

		if( empty($attribute_id) )
			$wpdb->insert(  "{$wpdb->prefix}woocommerce_attribute_taxonomies", $args );

		if( $set ){
			$attributes = wc_get_attribute_taxonomies();
			$args['attribute_id'] = self::get_attribute_id_from_name( $name );
			$attributes[] = (object) $args;
			set_transient( 'wc_attribute_taxonomies', $attributes );
		} else {
			return;
		}
	}
	
	
	/**  * Get the product attribute ID from the name. 	*/
	public function get_attribute_id_from_name( $name ) {
		global $wpdb;
		$attribute_id = $wpdb->get_col("SELECT attribute_id
		FROM {$wpdb->prefix}woocommerce_attribute_taxonomies
		WHERE attribute_name LIKE '$name'");
		return reset($attribute_id);
	}
	
	public function get_productid_by_productparentsku($productParentSKU, $SKU, $TITLE) {
		$productid = '';		
		$params = array(			
			'post_type' => 'product',			
			'meta_key' => '_parent_sku',			
			'meta_value' => $productParentSKU,			
			'posts_per_page' => 1,
			'post_status' => array('publish', 'pending', 'draft', 'auto-draft', 'future', 'private', 'inherit', 'trash'),			
		);				
		$wc_query = new WP_Query($params);		
		if ($wc_query->have_posts()) {			
			if(!empty($wc_query->post)) {
				$productid = $wc_query->post->ID;
			}		
		}
		return $productid;	
	}
	
	public function updateProductTitle($productid, $TITLE){
		global $wpdb;
		$postTable = $wpdb->prefix.'posts';
		$wpdb->update( 
						$postTable, 
						array( 'post_title' => $TITLE),
						array( 'ID' => $productid ), 
						array( '%s'), 
						array( '%d' )
					);
	}
	
	/**  * Create a new variable product (with new attributes if they are). */
	public function create_product_variation( $data, $parentProductId, $syncWarehouse ){
		
		if(empty($parentProductId)) { 
			$postname = sanitize_title( $data['title'] );
			$author = empty( $data['author'] ) ? '1' : $data['author'];
			$post_data = array(
				'post_author'   => $author,
				'post_name'     => $postname,
				'post_title'    => $data['title'],
				'post_content'  => $data['content'],
				'post_excerpt'  => $data['excerpt'],
				'post_status'   => 'publish',
				'ping_status'   => 'closed',
				'post_type'     => 'product',
				'guid'          => home_url( '/product/'.$postname.'/' ),
			);
			$allReadyAdded = "false";
			$parentSKU = $data['_parent_sku'];
			$product_id = wp_insert_post( $post_data );
			update_post_meta($product_id, '_parent_sku', $parentSKU);
			update_post_meta($product_id, '_sku', $parentSKU);
			update_post_meta($product_id, 'swiftpost_product', 'true');
		} else {
			$allReadyAdded = "true";
			$product_id = $parentProductId;
			update_post_meta($product_id, 'swiftpost_product', 'true');
			wp_untrash_post($product_id);
		}
		
		// Inventory Sync in Autum
		switch ( $syncWarehouse ){
			case 'JVA' :
				$location = self::get_swiftpos_creds('locationId');
			break;
			case 'Melbourne':
				$location = self::get_swiftpos_creds_melbourne('locationId');
			break;
			case 'JAA':
				$location = self::get_swiftpos_creds_just_automiser('locationId');
			break;
		}
		$supplierId = 0;
		$supplierName = '';
		$supplierData = self::getSupplier($location);
		if(!empty($supplierData)) {
			$supplierId = $supplierData->ID;
			$supplierName = $supplierData->post_title;
		} 
		
		self::autumInventorySync($product_id, $supplierId, $supplierName, $data['stock'], $data['stock_status'], true);
		
		$product = new WC_Product( $product_id );
		
		## ---------------------- VARIATION ATTRIBUTES ---------------------- ##
		
		$product_attributes = array();
		if(!empty($data['attributes'])) {
			global $wpdb;
			$termsTable = $wpdb->prefix.'terms';
			$termRelationshipTable = $wpdb->prefix.'term_relationships';
			$termTaxonomyTable = $wpdb->prefix.'term_taxonomy';
			$termVariableData = $wpdb->get_results( 'SELECT * FROM '.$termsTable.' WHERE slug = "variable"');
			$termSimpleData = $wpdb->get_results( 'SELECT * FROM '.$termsTable.' WHERE slug = "simple"');
			if(!empty($termVariableData)) {
				$termVariableID = $termVariableData[0]->term_id;
				$termRelationData = $wpdb->get_results( 'SELECT * FROM '.$termRelationshipTable.' WHERE object_id = '.$product_id.' and  term_taxonomy_id = '.$termVariableID);
				if(!empty($termSimpleData)) {
					$termSimpleID = $termSimpleData[0]->term_id;
					$wpdb->delete( $termRelationshipTable, array('object_id' => $product_id, 'term_taxonomy_id' => $termSimpleID ), array('%d', '%d'));
				}
				if(empty($termRelationData)) {
					$wpdb->insert( $termRelationshipTable, array( 'object_id' => $product_id, 'term_taxonomy_id' => $termVariableID, 'term_order' => 0) , array('%d', '%d', '%d' ) );
					$taxonomyResult = $wpdb->get_results( 'SELECT * FROM '.$termTaxonomyTable.' WHERE term_id = '.$termVariableID.' and  taxonomy = "product_type"');
					if(!empty($taxonomyResult)) {
						$productCount = $taxonomyResult[0]->count;
						$term_taxonomy_id = $taxonomyResult[0]->term_taxonomy_id;
						$productNewCount = $productCount++;
						$wpdb->update( $termTaxonomyTable, array( 'count' => $productNewCount) , array( 'term_taxonomy_id' => $term_taxonomy_id )  );
						
					}
					$taxonomySimpleResult = $wpdb->get_results( 'SELECT * FROM '.$termTaxonomyTable.' WHERE term_id = '.$termSimpleID.' and  taxonomy = "product_type"');
					if(!empty($taxonomySimpleResult)) {
						$productCount = $taxonomySimpleResult[0]->count;
						$term_simple_taxonomy_id = $taxonomySimpleResult[0]->term_taxonomy_id;
						$productNewCount = $productCount--;
						$wpdb->update( $termTaxonomyTable, array( 'count' => $productNewCount) , array( 'term_taxonomy_id' => $term_simple_taxonomy_id )  );
						
					}
				}
			}
			
			foreach($data['attributes'] as $key => $terms){
				$taxonomy = wc_attribute_taxonomy_name(wc_sanitize_taxonomy_name($key));
				$attr_label = ucfirst($key);
				$attr_name = (wc_sanitize_taxonomy_name($key));
			
				if(!taxonomy_exists($taxonomy))
					self::save_product_attribute_from_name( $attr_name, $attr_label );
				
				$product_attributes[$taxonomy] = array (
					'name'         => $taxonomy,
					'value'        => '',
					'position'     => '',
					'is_visible'   => 0,
					'is_variation' => 1,
					'is_taxonomy'  => 1
				);
				
				foreach( $terms as $value ){
					$term_name = ucfirst($value);
					$term_slug = sanitize_title($value);
					
					// Check if the Term name exist and if not we create it.
					if( ! term_exists( $term_slug, $taxonomy ) ) {
						$wpdb->insert( $termsTable, array( 'name' => $term_name, 'slug' => $term_slug, 'term_group' => '0' ) , array( '%s', '%s', '%d' ) );
						$termId = $wpdb->insert_id;
						if($termId) {
							$wpdb->insert( $termTaxonomyTable, array( 'term_id' => $termId, 'taxonomy' => $taxonomy, 'description' => '' , 'parent' => 0, 'count' => 0) , array('%d', '%s', '%s', '%d', '%d' ) );
							$termTaxonomyRelationId = $wpdb->insert_id;
							if($termTaxonomyRelationId) {
								$wpdb->insert( $termRelationshipTable, array( 'object_id' => $product_id, 'term_taxonomy_id' => $termTaxonomyRelationId, 'term_order' => 0) , array('%d', '%d', '%d' ) );
							}
						}
					}
					wp_set_post_terms( $product_id, $term_name, $taxonomy, true );			
				}
			}
			
			$variation_data =  array(
				'swiftpost_id'  => $data['swiftpost_id'],
				'attributes'    => $data['attributes'],
				'sku'           => $data['sku'],
				'regular_price' => $data['regular_price'],
				'sale_price'    => $data['sale_price'],
				'stock_qty'     => $data['stock'],
				'imgagedata'    => $data['imgagedata'],
				'stock_status'  => $data['stock_status'],
				'title'         => $data['standard_title'],
				'reupload_images'=> $data['reupload_images']
			);

			// The function to be run
			self::create_variation( $product_id, $variation_data , $allReadyAdded, $location);
			update_post_meta( $product_id, '_product_attributes', $product_attributes );
		}
	}

	public function create_product_variation_on_update( $data, $parentProductId, $syncWarehouse ){
		
		if(empty($parentProductId)) { 
			$postname = sanitize_title( $data['title'] );
			$author = empty( $data['author'] ) ? '1' : $data['author'];
			$post_data = array(
				'post_author'   => $author,
				'post_name'     => $postname,
				'post_title'    => $data['title'],
				'post_content'  => $data['content'],
				'post_excerpt'  => $data['excerpt'],
				'post_status'   => 'publish',
				'ping_status'   => 'closed',
				'post_type'     => 'product',
				'guid'          => home_url( '/product/'.$postname.'/' ),
			);
			$allReadyAdded = "false";
			$parentSKU = $data['_parent_sku'];
			$product_id = wp_insert_post( $post_data );
			update_post_meta($product_id, '_parent_sku', $parentSKU);
			update_post_meta($product_id, '_sku', $parentSKU);
			update_post_meta($product_id, 'swiftpost_product', 'true');
		} else {
			$allReadyAdded = "true";
			$product_id = $parentProductId;
			update_post_meta($product_id, 'swiftpost_product', 'true');
			wp_untrash_post($product_id);
		}
		
		// Inventory Sync in Autum
		switch ( $syncWarehouse ){
			case 'JVA' :
				$location = self::get_swiftpos_creds('locationId');
			break;
			case 'Melbourne':
				$location = self::get_swiftpos_creds_melbourne('locationId');
			break;
			case 'JAA':
				$location = self::get_swiftpos_creds_just_automiser('locationId');
			break;
		}
		$supplierId = 0;
		$supplierName = '';
		$supplierData = self::getSupplier($location);
		if(!empty($supplierData)) {
			$supplierId = $supplierData->ID;
			$supplierName = $supplierData->post_title;
		} 
		
		// self::autumInventorySync($product_id, $supplierId, $supplierName, $data['stock'], $data['stock_status'], true);
		
		$product = new WC_Product( $product_id );
		
		## ---------------------- VARIATION ATTRIBUTES ---------------------- ##
		
		$product_attributes = array();
		if(!empty($data['attributes'])) {
			global $wpdb;
			$termsTable = $wpdb->prefix.'terms';
			$termRelationshipTable = $wpdb->prefix.'term_relationships';
			$termTaxonomyTable = $wpdb->prefix.'term_taxonomy';
			$termVariableData = $wpdb->get_results( 'SELECT * FROM '.$termsTable.' WHERE slug = "variable"');
			$termSimpleData = $wpdb->get_results( 'SELECT * FROM '.$termsTable.' WHERE slug = "simple"');
			if(!empty($termVariableData)) {
				$termVariableID = $termVariableData[0]->term_id;
				$termRelationData = $wpdb->get_results( 'SELECT * FROM '.$termRelationshipTable.' WHERE object_id = '.$product_id.' and  term_taxonomy_id = '.$termVariableID);
				if(!empty($termSimpleData)) {
					$termSimpleID = $termSimpleData[0]->term_id;
					$wpdb->delete( $termRelationshipTable, array('object_id' => $product_id, 'term_taxonomy_id' => $termSimpleID ), array('%d', '%d'));
				}
				if(empty($termRelationData)) {
					$wpdb->insert( $termRelationshipTable, array( 'object_id' => $product_id, 'term_taxonomy_id' => $termVariableID, 'term_order' => 0) , array('%d', '%d', '%d' ) );
					$taxonomyResult = $wpdb->get_results( 'SELECT * FROM '.$termTaxonomyTable.' WHERE term_id = '.$termVariableID.' and  taxonomy = "product_type"');
					if(!empty($taxonomyResult)) {
						$productCount = $taxonomyResult[0]->count;
						$term_taxonomy_id = $taxonomyResult[0]->term_taxonomy_id;
						$productNewCount = $productCount++;
						$wpdb->update( $termTaxonomyTable, array( 'count' => $productNewCount) , array( 'term_taxonomy_id' => $term_taxonomy_id )  );
						
					}
					$taxonomySimpleResult = $wpdb->get_results( 'SELECT * FROM '.$termTaxonomyTable.' WHERE term_id = '.$termSimpleID.' and  taxonomy = "product_type"');
					if(!empty($taxonomySimpleResult)) {
						$productCount = $taxonomySimpleResult[0]->count;
						$term_simple_taxonomy_id = $taxonomySimpleResult[0]->term_taxonomy_id;
						$productNewCount = $productCount--;
						$wpdb->update( $termTaxonomyTable, array( 'count' => $productNewCount) , array( 'term_taxonomy_id' => $term_simple_taxonomy_id )  );
						
					}
				}
			}
			
			foreach($data['attributes'] as $key => $terms){
				$taxonomy = wc_attribute_taxonomy_name(wc_sanitize_taxonomy_name($key));
				$attr_label = ucfirst($key);
				$attr_name = (wc_sanitize_taxonomy_name($key));
			
				if(!taxonomy_exists($taxonomy))
					self::save_product_attribute_from_name( $attr_name, $attr_label );
				
				$product_attributes[$taxonomy] = array (
					'name'         => $taxonomy,
					'value'        => '',
					'position'     => '',
					'is_visible'   => 0,
					'is_variation' => 1,
					'is_taxonomy'  => 1
				);
				
				foreach( $terms as $value ){
					$term_name = ucfirst($value);
					$term_slug = sanitize_title($value);
					
					// Check if the Term name exist and if not we create it.
					if( ! term_exists( $term_slug, $taxonomy ) ) {
						$wpdb->insert( $termsTable, array( 'name' => $term_name, 'slug' => $term_slug, 'term_group' => '0' ) , array( '%s', '%s', '%d' ) );
						$termId = $wpdb->insert_id;
						if($termId) {
							$wpdb->insert( $termTaxonomyTable, array( 'term_id' => $termId, 'taxonomy' => $taxonomy, 'description' => '' , 'parent' => 0, 'count' => 0) , array('%d', '%s', '%s', '%d', '%d' ) );
							$termTaxonomyRelationId = $wpdb->insert_id;
							if($termTaxonomyRelationId) {
								$wpdb->insert( $termRelationshipTable, array( 'object_id' => $product_id, 'term_taxonomy_id' => $termTaxonomyRelationId, 'term_order' => 0) , array('%d', '%d', '%d' ) );
							}
						}
					}
					wp_set_post_terms( $product_id, $term_name, $taxonomy, true );			
				}
			}
			
			$variation_data =  array(
				'swiftpost_id'  => $data['swiftpost_id'],
				'attributes'    => $data['attributes'],
				'sku'           => $data['sku'],
				'regular_price' => $data['regular_price'],
				'sale_price'    => $data['sale_price'],
				'stock_qty'     => $data['stock'],
				'imgagedata'    => $data['imgagedata'],
				'stock_status'  => $data['stock_status'],
				'title'         => $data['standard_title'],
				'reupload_images'=> $data['reupload_images']
			);

			// The function to be run
			self::create_variation( $product_id, $variation_data , $allReadyAdded, $location);
			update_post_meta( $product_id, '_product_attributes', $product_attributes );
		}
	}
	
	/**  * Create a new attributes if does not exists and assign it to product. */
	public function assign_attributes_on_simple_products( $data, $product_id, $syncWarehouse ){
		if(empty($product_id)) { 
			return;
		}

		update_post_meta($product_id, 'swiftpost_product', 'true');
		wp_untrash_post($product_id);
		
		// Inventory Sync in Autum
		switch ( $syncWarehouse ){
			case 'JVA' :
				$location = self::get_swiftpos_creds('locationId');
			break;
			case 'Melbourne':
				$location = self::get_swiftpos_creds_melbourne('locationId');
			break;
			case 'JAA':
				$location = self::get_swiftpos_creds_just_automiser('locationId');
			break;
		}

		$supplierData = self::getSupplier($location);

		$supplierId = 0;
		$supplierName = '';
		if(!empty($supplierData)) {
			$supplierId = $supplierData->ID;
			$supplierName = $supplierData->post_title;
		} 

		self::autumInventorySync($product_id, $supplierId, $supplierName, $data['stock'], $data['stock_status'], true);
		
		$product = new WC_Product( $product_id );
		
		## ---------------------- PRODUCT ATTRIBUTES ---------------------- ##
		
		$product_attributes = array();
		if(!empty($data['attributes'])) {
			global $wpdb;
			$termsTable = $wpdb->prefix.'terms';
			$termRelationshipTable = $wpdb->prefix.'term_relationships';
			$termTaxonomyTable = $wpdb->prefix.'term_taxonomy';
			$termVariableData = $wpdb->get_results( 'SELECT * FROM '.$termsTable.' WHERE slug = "variable"');
			$termSimpleData = $wpdb->get_results( 'SELECT * FROM '.$termsTable.' WHERE slug = "simple"');
			if(!empty($termVariableData)) {
				$termVariableID = $termVariableData[0]->term_id;
				$termRelationData = $wpdb->get_results( 'SELECT * FROM '.$termRelationshipTable.' WHERE object_id = '.$product_id.' and  term_taxonomy_id = '.$termVariableID);
				if(!empty($termSimpleData)) {
					$termSimpleID = $termSimpleData[0]->term_id;
					$wpdb->delete( $termRelationshipTable, array('object_id' => $product_id, 'term_taxonomy_id' => $termSimpleID ), array('%d', '%d'));
				}
				
				/*
				if(empty($termRelationData)) {
					$wpdb->insert( $termRelationshipTable, array( 'object_id' => $product_id, 'term_taxonomy_id' => $termVariableID, 'term_order' => 0) , array('%d', '%d', '%d' ) );
					$taxonomyResult = $wpdb->get_results( 'SELECT * FROM '.$termTaxonomyTable.' WHERE term_id = '.$termVariableID.' and  taxonomy = "product_type"');
					if(!empty($taxonomyResult)) {
						$productCount = $taxonomyResult[0]->count;
						$term_taxonomy_id = $taxonomyResult[0]->term_taxonomy_id;
						$productNewCount = $productCount++;
						$wpdb->update( $termTaxonomyTable, array( 'count' => $productNewCount) , array( 'term_taxonomy_id' => $term_taxonomy_id )  );
						
					}
					$taxonomySimpleResult = $wpdb->get_results( 'SELECT * FROM '.$termTaxonomyTable.' WHERE term_id = '.$termSimpleID.' and  taxonomy = "product_type"');
					if(!empty($taxonomySimpleResult)) {
						$productCount = $taxonomySimpleResult[0]->count;
						$term_simple_taxonomy_id = $taxonomySimpleResult[0]->term_taxonomy_id;
						$productNewCount = $productCount--;
						$wpdb->update( $termTaxonomyTable, array( 'count' => $productNewCount) , array( 'term_taxonomy_id' => $term_simple_taxonomy_id )  );
						
					}
				}
				*/

			}
			
			foreach($data['attributes'] as $key => $terms){
				$taxonomy = wc_attribute_taxonomy_name(wc_sanitize_taxonomy_name($key));
				$attr_label = ucfirst($key);
				$attr_name = (wc_sanitize_taxonomy_name($key));
			
				if(!taxonomy_exists($taxonomy))
					self::save_product_attribute_from_name( $attr_name, $attr_label );
				
				$product_attributes[$taxonomy] = array (
					'name'         => $taxonomy,
					'value'        => '',
					'position'     => '',
					'is_visible'   => 0,
					'is_variation' => 1,
					'is_taxonomy'  => 1
				);
				
				foreach( $terms as $value ){
					$term_name = ucfirst($value);
					$term_slug = sanitize_title($value);
					
					// Check if the Term name exist and if not we create it.
					if( ! term_exists( $term_slug, $taxonomy ) ) {
						$wpdb->insert( $termsTable, array( 'name' => $term_name, 'slug' => $term_slug, 'term_group' => '0' ) , array( '%s', '%s', '%d' ) );
						$termId = $wpdb->insert_id;
						if($termId) {
							$wpdb->insert( $termTaxonomyTable, array( 'term_id' => $termId, 'taxonomy' => $taxonomy, 'description' => '' , 'parent' => 0, 'count' => 0) , array('%d', '%s', '%s', '%d', '%d' ) );
							$termTaxonomyRelationId = $wpdb->insert_id;
							if($termTaxonomyRelationId) {
								$wpdb->insert( $termRelationshipTable, array( 'object_id' => $product_id, 'term_taxonomy_id' => $termTaxonomyRelationId, 'term_order' => 0) , array('%d', '%d', '%d' ) );
							}
						}
					}
					wp_set_post_terms( $product_id, $term_name, $taxonomy, true );			
				}
			}
		}
	}

	public function assign_attributes_on_simple_products_on_update( $data, $product_id, $syncWarehouse ){
		if(empty($product_id)) { 
			return;
		}

		update_post_meta($product_id, 'swiftpost_product', 'true');
		wp_untrash_post($product_id);
		
		// Inventory Sync in Autum
		switch ( $syncWarehouse ){
			case 'JVA' :
				$location = self::get_swiftpos_creds('locationId');
			break;
			case 'Melbourne':
				$location = self::get_swiftpos_creds_melbourne('locationId');
			break;
			case 'JAA':
				$location = self::get_swiftpos_creds_just_automiser('locationId');
			break;
		}

		$supplierData = self::getSupplier($location);

		$supplierId = 0;
		$supplierName = '';
		if(!empty($supplierData)) {
			$supplierId = $supplierData->ID;
			$supplierName = $supplierData->post_title;
		} 

		// self::autumInventorySync($product_id, $supplierId, $supplierName, $data['stock'], $data['stock_status'], true);
		
		$product = new WC_Product( $product_id );
		
		## ---------------------- PRODUCT ATTRIBUTES ---------------------- ##
		
		$product_attributes = array();
		if(!empty($data['attributes'])) {
			global $wpdb;
			$termsTable = $wpdb->prefix.'terms';
			$termRelationshipTable = $wpdb->prefix.'term_relationships';
			$termTaxonomyTable = $wpdb->prefix.'term_taxonomy';
			$termVariableData = $wpdb->get_results( 'SELECT * FROM '.$termsTable.' WHERE slug = "variable"');
			$termSimpleData = $wpdb->get_results( 'SELECT * FROM '.$termsTable.' WHERE slug = "simple"');
			if(!empty($termVariableData)) {
				$termVariableID = $termVariableData[0]->term_id;
				$termRelationData = $wpdb->get_results( 'SELECT * FROM '.$termRelationshipTable.' WHERE object_id = '.$product_id.' and  term_taxonomy_id = '.$termVariableID);
				if(!empty($termSimpleData)) {
					$termSimpleID = $termSimpleData[0]->term_id;
					$wpdb->delete( $termRelationshipTable, array('object_id' => $product_id, 'term_taxonomy_id' => $termSimpleID ), array('%d', '%d'));
				}
				
				/*
				if(empty($termRelationData)) {
					$wpdb->insert( $termRelationshipTable, array( 'object_id' => $product_id, 'term_taxonomy_id' => $termVariableID, 'term_order' => 0) , array('%d', '%d', '%d' ) );
					$taxonomyResult = $wpdb->get_results( 'SELECT * FROM '.$termTaxonomyTable.' WHERE term_id = '.$termVariableID.' and  taxonomy = "product_type"');
					if(!empty($taxonomyResult)) {
						$productCount = $taxonomyResult[0]->count;
						$term_taxonomy_id = $taxonomyResult[0]->term_taxonomy_id;
						$productNewCount = $productCount++;
						$wpdb->update( $termTaxonomyTable, array( 'count' => $productNewCount) , array( 'term_taxonomy_id' => $term_taxonomy_id )  );
						
					}
					$taxonomySimpleResult = $wpdb->get_results( 'SELECT * FROM '.$termTaxonomyTable.' WHERE term_id = '.$termSimpleID.' and  taxonomy = "product_type"');
					if(!empty($taxonomySimpleResult)) {
						$productCount = $taxonomySimpleResult[0]->count;
						$term_simple_taxonomy_id = $taxonomySimpleResult[0]->term_taxonomy_id;
						$productNewCount = $productCount--;
						$wpdb->update( $termTaxonomyTable, array( 'count' => $productNewCount) , array( 'term_taxonomy_id' => $term_simple_taxonomy_id )  );
						
					}
				}
				*/

			}
			
			foreach($data['attributes'] as $key => $terms){
				$taxonomy = wc_attribute_taxonomy_name(wc_sanitize_taxonomy_name($key));
				$attr_label = ucfirst($key);
				$attr_name = (wc_sanitize_taxonomy_name($key));
			
				if(!taxonomy_exists($taxonomy))
					self::save_product_attribute_from_name( $attr_name, $attr_label );
				
				$product_attributes[$taxonomy] = array (
					'name'         => $taxonomy,
					'value'        => '',
					'position'     => '',
					'is_visible'   => 0,
					'is_variation' => 1,
					'is_taxonomy'  => 1
				);
				
				foreach( $terms as $value ){
					$term_name = ucfirst($value);
					$term_slug = sanitize_title($value);
					
					// Check if the Term name exist and if not we create it.
					if( ! term_exists( $term_slug, $taxonomy ) ) {
						$wpdb->insert( $termsTable, array( 'name' => $term_name, 'slug' => $term_slug, 'term_group' => '0' ) , array( '%s', '%s', '%d' ) );
						$termId = $wpdb->insert_id;
						if($termId) {
							$wpdb->insert( $termTaxonomyTable, array( 'term_id' => $termId, 'taxonomy' => $taxonomy, 'description' => '' , 'parent' => 0, 'count' => 0) , array('%d', '%s', '%s', '%d', '%d' ) );
							$termTaxonomyRelationId = $wpdb->insert_id;
							if($termTaxonomyRelationId) {
								$wpdb->insert( $termRelationshipTable, array( 'object_id' => $product_id, 'term_taxonomy_id' => $termTaxonomyRelationId, 'term_order' => 0) , array('%d', '%d', '%d' ) );
							}
						}
					}
					wp_set_post_terms( $product_id, $term_name, $taxonomy, true );			
				}
			}
		}
	}

	public function create_variation( $product_id, $variation_data, $allReadyAdded, $location ){
		$product = wc_get_product($product_id); 
		if(!empty($variation_data['attributes'])) {
			$args = array(
				'post_type' => 'product_variation',
				'post_parent' => $product_id,
				'post_status' => array('publish', 'pending', 'draft', 'auto-draft', 'future', 'private', 'inherit', 'trash'),
				'meta_query' => array(
					'relation' => 'AND',
				)
			);
			foreach($variation_data['attributes'] as $key => $value) {
				$metaSubQuery = array(
					'key' => 'attribute_pa_'.$key,
					'value' => wc_sanitize_taxonomy_name(strtolower($value[0])),
					'type' => 'string',
					'compare' => '='
				);
				$args['meta_query'][] = $metaSubQuery;
			}
			$executeQuery = new WP_Query( $args );
			if ( $executeQuery->have_posts() ) {
				while ( $executeQuery->have_posts() ) : $executeQuery->the_post();
					$variation_id = get_the_ID();
				endwhile;
				wp_reset_postdata();
			}
		}
			
		if($variation_id == '') {
			$nneeww = true;
			$variation_post = array(
				'post_title'  => $variation_data['title'],
				'post_name'   => 'product-'.$product_id.'-variation',
				'post_status' => 'publish',
				'post_parent' => $product_id,
				'post_type'   => 'product_variation',
				'guid'        => $product->get_permalink()
			);
			$variation_id = wp_insert_post( $variation_post );
		}
		else{
			$nneeww = false;
		}
		
		// Inventory Sync in Autum
		$supplierData = self::getSupplier($location);
		if(!empty($supplierData)) {
			$supplierId = $supplierData->ID;
			$supplierName = $supplierData->post_title;
		} 
		
		if($nneeww){
			self::autumInventorySync($variation_id, $supplierId, $supplierName, $variation_data['stock_qty'], $variation_data['stock_status'], false);
		}
		
		// Get an instance of the WC_Product_Variation object
		$variation = new WC_Product_Variation( $variation_id );

		// Iterating through the variations attributes
		if(!empty($variation_data['attributes'])) {
			foreach($variation_data['attributes'] as $attribute => $term_name ) {
				$taxonomy = 'pa_'.$attribute; // The attribute taxonomy
				$term_slug = sanitize_title($term_name[0]);
				$meta_key = 'attribute_'.$taxonomy;
				update_post_meta( $variation_id, $meta_key, $term_slug );
			}
		}
		update_post_meta( $variation_id, 'swiftpost_id', $variation_data['swiftpost_id'] );
		
		if(!empty( $variation_data['sku'] ) && $allReadyAdded == "false")
			$variation->set_sku( $variation_data['sku']);
			update_post_meta($variation_id, '_sku', $variation_data['sku']);

		if(empty( $variation_data['sale_price'] ) ){
			$variation->set_price( $variation_data['regular_price'] );
		} else {
			$variation->set_price( $variation_data['sale_price'] );
			$variation->set_sale_price( $variation_data['sale_price'] );
		}
		$variation->set_regular_price($variation_data['regular_price']);
		
		$variation->set_stock_quantity($variation_data['stock_qty']);
		if($variation_data['stock_qty'] != '' && $variation_data['stock_qty'] > 0) {
			$variation->set_manage_stock(true);
		} else {
			$variation->set_manage_stock(true);
		}
		$variation->set_stock_status($variation_data['stock_status']);
		
		$variation->set_weight('');
		$variation->save(); // Save the data 

		update_post_meta($variation_id, '_stock_status', wc_clean( $variation_data['stock_status'] ));
		
		update_post_meta($variation_id, '_price_per_inventory', 'global');
		update_post_meta($variation_id, '_expirable_inventories', 'global');
		update_post_meta($variation_id, '_inventory_iteration', 'global');
		update_post_meta($variation_id, '_selling_priority', 'global');
		update_post_meta($variation_id, '_multi_inventory', 'global');
		update_post_meta($variation_id, '_backorders', 'no');
		update_post_meta($variation_id, 'swiftpost_product', 'true');
	
		wp_untrash_post($variation_id);
		wc_delete_product_transients( $variation_id );
		
		$img_data = $variation_data['imgagedata'];
		
		$reupload_images = $variation_data['reupload_images'];
		$rootBaseDirectory = ABSPATH;
		$sharePointImageUrl = $rootBaseDirectory.'product_images/'.$variation_data['sku'].'.jpg';

		if (!@file_exists($sharePointImageUrl) && !empty($img_data)) {
			$decoded =  base64_decode($img_data);
			file_put_contents( $sharePointImageUrl, $decoded );
		}


		if(empty($img_data)){
			delete_post_meta($variation_id, '_thumbnail_id');
		}elseif (@file_exists($sharePointImageUrl)) {
			$variationImageExist = get_post_meta($variation_id, '_thumbnail_id', true);
			$variationImageCreateDate = filemtime($sharePointImageUrl);
			if($variationImageExist != '') {
				$variationImageInsertDate = get_post_meta($variationImageExist, '_last_modified_date', true);
				if($variationImageCreateDate <= $variationImageInsertDate) {
					return true;
				}
			}
			$upload_dir = wp_upload_dir();
			$upload_path = str_replace( '/', DIRECTORY_SEPARATOR, $upload_dir['path'] ) . DIRECTORY_SEPARATOR;
			$decoded = file_get_contents($sharePointImageUrl);
			$filename = basename($sharePointImageUrl);
		
			$hashed_filename = md5( $filename ) . '_' . $filename;
			$image_upload = file_put_contents( $upload_path . $hashed_filename, $decoded );
			if( !function_exists( 'wp_handle_sideload' ) ) {
				require_once( ABSPATH . 'wp-admin/includes/file.php' );	
			}
			if( !function_exists( 'wp_get_current_user' ) ) {
				require_once( ABSPATH . 'wp-includes/pluggable.php' );
			}
			require_once(ABSPATH . 'wp-admin/includes/image.php');
			$file             = array();
			$file['error']    = '';
			$file['tmp_name'] = $upload_path . $hashed_filename;
			$file['name']     = $hashed_filename;
			$file['type']     = 'image/png';
			$file['size']     = filesize( $upload_path . $hashed_filename );

			// upload file to server
			$file_return = wp_handle_sideload( $file, array( 'test_form' => false ) );
			$filename = $file_return['file'];
			$attachment = array(
			 'post_mime_type' => $file_return['type'],
			 'post_title' => preg_replace('/\.[^.]+$/', '', basename($filename)),
			 'post_content' => '',
			 'post_status' => 'inherit',
			 'post_parent' => $variation_id,
			 'guid' => $upload_dir['url'] . '/' . basename($filename)
			); 
			$attach_id = wp_insert_attachment( $attachment, $filename);
			$attach_data = wp_generate_attachment_metadata( $attach_id, $file_return['file'] );
			wp_update_attachment_metadata( $attach_id, $attach_data );
			update_post_meta($attach_id, '_last_modified_date', $variationImageCreateDate);
			update_post_meta($variation_id, '_thumbnail_id', $attach_id);
		}
	}
	
	public function productTitleLookUp(){
		$titleLookup = array();
		$productTitleLookUp = get_field('parent_product_lookup_options', 'option');
		if(!empty($productTitleLookUp)) {
			foreach($productTitleLookUp as $lookup) {
				$sku_first_seven_letter = $lookup['sku_first_seven_letter'];
				$product_title = $lookup['product_title'];
				$titleLookup[$sku_first_seven_letter] = $product_title;
			}
		}
		return $titleLookup;
	}
	
	public function brandLookUp(){
		$brandLookUp = array();
		$brandTitleLookUp = get_field('brand_look_options', 'option');
		if(!empty($brandTitleLookUp)) {
			foreach($brandTitleLookUp as $lookup) {
				$brand_sku = $lookup['10th_sku_character'];
				$brand_title = $lookup['brand_name'];
				$brandLookUp[$brand_sku] = $brand_title;
			}
		}
		return $brandLookUp;
	}
	public function juiceFlavourLookUp(){
		$flavourLookUp = array();
		$standardflavourLookUp = array();
		$dragonflavourLookUp = array();
		$tjuiceflavourLookUp = array();
		$greengoldflavourLookUp = array();
		$falvourTitleLookUp = get_field('juice_flavour_options', 'option');
		if(!empty($falvourTitleLookUp)) {
			$standardFlavourOption = $falvourTitleLookUp['standard_range_option'];
			$DragonFlavourOption = $falvourTitleLookUp['dragon_range_option'];
			$TJuiceFlavourOption = $falvourTitleLookUp['t_juice_range_option'];
			$GreenGoldFlavourOption = $falvourTitleLookUp['green_&_gold_option'];
			if(!empty($standardFlavourOption)) {
				foreach($standardFlavourOption as $flavourOption) {
					$code = $flavourOption["code"];
					$flavour = $flavourOption["flavour"];
					$standardflavourLookUp[$code] = $flavour;
				}
				$flavourLookUp["standard"] = $standardflavourLookUp;
			}
			if(!empty($DragonFlavourOption)) {
				foreach($DragonFlavourOption as $flavourOption) {
					$code = $flavourOption["code"];
					$flavour = $flavourOption["flavour"];
					$dragonflavourLookUp[$code] = $flavour;
				}
				$flavourLookUp["dragon"] = $dragonflavourLookUp;
			}
			if(!empty($TJuiceFlavourOption)) {
				foreach($TJuiceFlavourOption as $flavourOption) {
					$code = $flavourOption["code"];
					$flavour = $flavourOption["flavour"];
					$tjuiceflavourLookUp[$code] = $flavour;
				}
				$flavourLookUp["tjuice"] = $tjuiceflavourLookUp;
			}
			if(!empty($GreenGoldFlavourOption)) {
				foreach($GreenGoldFlavourOption as $flavourOption) {
					$code = $flavourOption["code"];
					$flavour = $flavourOption["flavour"];
					$greengoldflavourLookUp[$code] = $flavour;
				}
				$flavourLookUp["greengold"] = $greengoldflavourLookUp;
			}
		}
		return $flavourLookUp;
	}
	
	public function getSupplier($locationId){
		$supplierDetail = '';		
		$params = array(			
			'post_type' => 'atum_supplier',			
			'meta_key' => '_supplier_details_code',			
			'meta_value' => $locationId,			
			'posts_per_page' => 1		
		);				
		$wc_query = new WP_Query($params);		
		if ($wc_query->have_posts()) {			
			if(!empty($wc_query->post)) {
				$supplierDetail = $wc_query->post;
			}		
		}
		return $supplierDetail;	
	}
	
	public function getSupplierFromInventoryId($inventoryId, $product_id, $isMain){
		global $wpdb;
		$supplierId = '';
		if($isMain) {
			$atum_product_table = $wpdb->prefix . 'atum_product_data';
			$response = $wpdb->get_results( 'SELECT supplier_id FROM '.$atum_product_table.' WHERE product_id = '.$product_id);
		} else {
			$atum_inventory_meta = $wpdb->prefix . 'atum_inventory_meta';
			$response = $wpdb->get_results( 'SELECT supplier_id FROM '.$atum_inventory_meta.' WHERE inventory_id = '.$inventoryId);
		}
		if(!empty($response)) {
			$supplierId = $response[0]->supplier_id;
		}
		return $supplierId;
	}
	
	public function getApiLoginCredentials($supplierCode, $key){
		if($supplierCode == 1) {
			$value = self::get_swiftpos_creds($key);
		} else if($supplierCode == 3) {
			$value = self::get_swiftpos_creds_melbourne($key);
		} else if($supplierCode == 4) {
			$value = self::get_swiftpos_creds_just_automiser($key);
		}
		return $value;
	}
		
	public function getAutumInventoryId($productId,  $supplierId, $supplierName){
		global $wpdb;
		$autumInventoryId = '';
		$atum_inventories_table_name = $wpdb->prefix . 'atum_inventories';
		$respnse = $wpdb->get_results( 'SELECT * FROM '.$atum_inventories_table_name.' WHERE product_id = '.$productId.' and  name = "'.$supplierName.'"');
		if(!empty($respnse)) {
			$autumInventoryId = $respnse[0]->id;
		}
		return $autumInventoryId;
	}
	
	public function getProductMainAutumInventoryId($productId,  $supplierId, $supplierName){
		global $wpdb;
		$autumInventoryId = '';
		$atum_inventories_table_name = $wpdb->prefix . 'atum_inventories';
		$respnse = $wpdb->get_results( 'SELECT * FROM '.$atum_inventories_table_name.' WHERE product_id = '.$productId.' and  name = "'.$supplierName.'" and is_main = 1');
		if(!empty($respnse)) {
			$autumInventoryId = $respnse[0]->id;
		}
		return $autumInventoryId;
	}
	
	public function getAllAutumInventory($productId){
		global $wpdb;
		$autumInventoryId = '';
		$atum_inventories_table_name = $wpdb->prefix . 'atum_inventories';
		$respnse = $wpdb->get_results( 'SELECT * FROM '.$atum_inventories_table_name.' WHERE product_id = '.$productId);
		return $respnse;
	}
	
	public function getAutumOrderfromOrderItemId($productId, $orderItemId){
		global $wpdb;
		$atum_inventory_order_table = $wpdb->prefix . 'atum_inventory_orders';
		$respnse = $wpdb->get_results( 'SELECT inventory_id as ID, qty, total FROM '.$atum_inventory_order_table.' WHERE product_id = '.$productId.' and order_item_id ='.$orderItemId);
		return $respnse;
	}
	
	public function checkInventoryIsMain($inventoryId){
		global $wpdb;
		$atum_inventory_table = $wpdb->prefix . 'atum_inventories';
		$respnse = $wpdb->get_results( 'SELECT is_main FROM '.$atum_inventory_table.' WHERE id = '.$inventoryId);
		return $respnse;
	}
	
	public function insertAutumInventory($productId, $supplierId, $supplierName, $is_main, $priority){
		global $wpdb;
		$inventoryInsertId = '';
		$atum_inventories_table_name = $wpdb->prefix . 'atum_inventories';
		$inventory_date = date('Y-m-d h:i:s');
		$update_date = date('Y-m-d h:i:s');
		$response = $wpdb->insert($atum_inventories_table_name, array('product_id' => $productId, 'name' => $supplierName, 'priority' => $priority, 'region' => null, 'inventory_date' => $inventory_date, 'bbe_date' => null, 'is_main' => $is_main,'lot' => '', 'write_off' => 0, 'update_date' => $update_date), array('%d', '%s', '%d', '%s', '%s', '%s', '%d', '%s', '%d', '%s') );
		if($response) {
			$inventoryInsertId = $wpdb->insert_id;
		}
		return $inventoryInsertId;
	}
	
	public function insertAutumInventoryMeta($supplierId,  $inventoryInsertId, $stockQuantity, $stockStatus){
		global $wpdb;
		$atum_inventory_meta_table_name = $wpdb->prefix . 'atum_inventory_meta';
		$manage_stock = 0;
		if($stockQuantity > 0) { $manage_stock = 1; }
		$respnse = $wpdb->insert($atum_inventory_meta_table_name, array('inventory_id' => $inventoryInsertId, 'manage_stock' => $manage_stock, 'stock_quantity' => $stockQuantity, 'stock_status' => $stockStatus, 'supplier_id' => $supplierId, 'sold_individually' => 0), array('%d', '%d', '%d', '%s', '%d', '%d') );
		return $respnse;
	}
	
	public function updateAutumInventoryMeta($supplierId,  $inventoryInsertId, $stockQuantity, $stockStatus) {
		global $wpdb;
		$atum_inventory_meta_table_name = $wpdb->prefix . 'atum_inventory_meta';
		$manage_stock = 0;
		if($stockQuantity > 0) { $manage_stock = 1; }
		$respnse = $wpdb->update(
						$atum_inventory_meta_table_name, 
						array(
							'manage_stock'      => $manage_stock,
							'stock_quantity'    => $stockQuantity,
							'stock_status'      => $stockStatus,
							'supplier_id'       => $supplierId,
							'sold_individually' => 0
						), 
						array( 
							'inventory_id' => $inventoryInsertId
						), 
						array( 
							'%d', '%d', '%s', '%d', '%d','%s'
						), 
						array( '%d' ) 
					);
		return $respnse;
	}
	
	public function updateSingleProductAutomInventory($productId, $supplierId, $check){
		global $wpdb;
		if($check) { $supplierId = 0; }
		$atum_product_table_name = $wpdb->prefix . 'atum_product_data';
		$respnseSupplier = $wpdb->get_results( 'SELECT supplier_id FROM '.$atum_product_table_name.' WHERE product_id = '.$productId);
		if(!empty($respnseSupplier) && $respnseSupplier[0]->supplier_id == '') {
			$respnse = $wpdb->update(
							$atum_product_table_name, 
							array(
								'supplier_id' => $supplierId
							), 
							array( 
								'product_id' => $productId
							), 
							array( 
								'%d'
							), 
							array( '%d' ) 
						);
			return $respnse;
		} else {
			$respnse = $wpdb->insert($atum_product_table_name, array('product_id' => $productId, 'supplier_id' => $supplierId, 'atum_controlled' =>1), array('%d', '%s', '%d') );
		}
	}
	
	public function autumInventorySync($productId, $supplierId, $supplierName, $stockQuantity, $stockStatus, $check){
		$allAutumInventory = self::getAllAutumInventory($productId);
		$autumInventoryId = self::getAutumInventoryId($productId,  $supplierId, $supplierName);
		if(empty($autumInventoryId)) {
			$priority = count($allAutumInventory);
			$is_main = (count($allAutumInventory) == 0) ? 1 : 0;
			$inventoryId = self::insertAutumInventory($productId, $supplierId, $supplierName, $is_main, $priority);
			self::updateSingleProductAutomInventory($productId, $supplierId, $check);
			$allAutumInventory = self::getAllAutumInventory($productId);
			if($inventoryId > 0 && count($allAutumInventory) > 1) {
				self::insertAutumInventoryMeta($supplierId,  $inventoryId, $stockQuantity, $stockStatus);
			}
		} else {
			if(count($allAutumInventory) > 1) {
				self::updateAutumInventoryMeta($supplierId,  $autumInventoryId, $stockQuantity, $stockStatus);
			}
		}
	}
	
	public function updateProductAutumInventory($productId,  $supplierId, $supplierName, $stockQuantity, $stockStatus){
		$mainProductInvetoryId = self::getProductMainAutumInventoryId($productId,  $supplierId, $supplierName);
		if($mainProductInvetoryId > 0) {
			update_post_meta( $productId, '_stock', $stockQuantity );
			update_post_meta( $productId, '_stock_status', $stockStatus );
		} else {
			$autumInventoryId = self::getAutumInventoryId($productId,  $supplierId, $supplierName);
			$allAutumInventory = self::getAllAutumInventory($productId);
			if(count($allAutumInventory) > 1) {
				self::updateAutumInventoryMeta($supplierId,  $autumInventoryId, $stockQuantity, $stockStatus);
			} else {
				update_post_meta( $productId, '_stock', $stockQuantity );
				update_post_meta( $productId, '_stock_status', $stockStatus );
			}
		}
	}
	
	public function sendWarehouseEmail($order_id, $date_display, $orderDetails, $paymentMethod, $billingData, $shippingData) {
		$billingAddress = $billingData['name'].'<br>'.$billingData['address'].'<br>'.$billingData['suburb'].','.$billingData['postcode'].'<br>'.$billingData['state'].', '.$billingData['country'].'<br>'.$billingData['phone'].'<br>'.$billingData['user_email'];
		
		$shippingAddress = $shippingData['name'].'<br>'.$shippingData['address'].'<br>'.$shippingData['suburb'].','.$shippingData['postcode'].'<br>'.$shippingData['state'].', '.$shippingData['country'];
		$content = '<div id="wrapper" dir="ltr" style="background-color: #f7f7f7;margin: 0;padding: 70px 0;width: 100%">
			<table border="0" cellpadding="0" cellspacing="0" width="100%">
				<tbody>
					<tr>
						<td align="center" valign="top">
							<div id="template_header_image"></div>
							<table border="0" cellpadding="0" cellspacing="0" width="600" id="template_container" style="background-color: #ffffff;border: 1px solid #dedede">
								<tbody>
									<tr>
										<td align="center" valign="top">
											<!-- Header -->
											<table border="0" cellpadding="0" cellspacing="0" width="600" id="template_header" style="background-color: #96588a;color: #ffffff;border-bottom: 0;font-weight: bold;line-height: 100%;vertical-align: middle;font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif">
												<tbody>
													<tr>
														<td id="header_wrapper" style="padding: 36px 48px">
															<h1 style="font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif;font-size: 30px;font-weight: 300;line-height: 150%;margin: 0;text-align: left;color: #ffffff">New Order: #'.$order_id.'</h1>
														</td>
													</tr>
												</tbody>
											</table>
											<!-- End Header -->
										</td>
									</tr>
									<tr>
										<td align="center" valign="top">
											<!-- Body -->
											<table border="0" cellpadding="0" cellspacing="0" width="600" id="template_body">
												<tbody>
													<tr>
														<td valign="top" id="body_content" style="background-color: #ffffff">
															<!-- Content -->
															<table border="0" cellpadding="20" cellspacing="0" width="100%">
																<tbody>
																	<tr>
																		<td valign="top" style="padding: 48px 48px 0">
																			<div id="body_content_inner" style="color: #636363;font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif;font-size: 14px;line-height: 150%;text-align: left">
																				<p style="margin: 0 0 16px">You’ve received the following order from Pankaj Developer:</p>
																				<h2 style="color: #96588a;font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif;font-size: 18px;font-weight: bold;line-height: 130%;margin: 0 0 18px;text-align: left">
																					<a class="link" href="http://stage.justvapoursaustralia.com.au/wp-admin/post.php?post='.$order_id.'&amp;action=edit" style="font-weight: normal;text-decoration: underline;color: #96588a">[Order #'.$order_id.']</a> ('.$date_display.')
																				</h2>
																				<div style="margin-bottom: 40px">
																					<table class="td" cellspacing="0" cellpadding="6" border="1" style="color: #636363;border: 1px solid #e5e5e5;vertical-align: middle;width: 100%;font-family: \'Helvetica Neue\', Helvetica, Roboto, Arial, sans-serif">
																						<thead>
																							<tr>
																								<th class="td" scope="col" style="color: #636363;border: 1px solid #e5e5e5;vertical-align: middle;padding: 12px;text-align: left">Product</th>
																								<th class="td" scope="col" style="color: #636363;border: 1px solid #e5e5e5;vertical-align: middle;padding: 12px;text-align: left">Quantity</th>
																								<th class="td" scope="col" style="color: #636363;border: 1px solid #e5e5e5;vertical-align: middle;padding: 12px;text-align: left">Price</th>
																							</tr>
																						</thead>
																						<tbody>
																						';
	if(!empty($orderDetails)) {
		$subTotal = 0;
		foreach($orderDetails as $orderItem) {
			$title = $orderItem['title'];
			$sku = $orderItem['sku'];
			$quantity = $orderItem['quantity'];
			$lineTotal = $orderItem['lineTotal'];
			$content .= '<tr class="order_item">
							<td class="td" style="color: #636363;border: 1px solid #e5e5e5;padding: 12px;text-align: left;vertical-align: middle;font-family: \'Helvetica Neue\', Helvetica, Roboto, Arial, sans-serif">'.$title.' (#'.$sku.')'.'</td>
							<td class="td" style="color: #636363;border: 1px solid #e5e5e5;padding: 12px;text-align: left;vertical-align: middle;font-family: \'Helvetica Neue\', Helvetica, Roboto, Arial, sans-serif"> '.$quantity.' </td>
							<td class="td" style="color: #636363;border: 1px solid #e5e5e5;padding: 12px;text-align: left;vertical-align: middle;font-family: \'Helvetica Neue\', Helvetica, Roboto, Arial, sans-serif">
								<span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">'.get_woocommerce_currency_symbol ().'</span>'.$lineTotal.'</span>		
							</td>
						</tr>';
			$subTotal = $subTotal + $lineTotal;
		}
	}													
	$content .= '</tbody>
				<tfoot>
					<tr>
						<th class="td" scope="row" colspan="2" style="color: #636363;border: 1px solid #e5e5e5;vertical-align: middle;padding: 12px;text-align: left;border-top-width: 4px">Subtotal:</th>
						<td class="td" style="color: #636363;border: 1px solid #e5e5e5;vertical-align: middle;padding: 12px;text-align: left;border-top-width: 4px"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">'.get_woocommerce_currency_symbol ().'</span>'.$subTotal.'</span></td>
					</tr>
					<!--<tr>
						<th class="td" scope="row" colspan="2" style="color: #636363;border: 1px solid #e5e5e5;vertical-align: middle;padding: 12px;text-align: left">Shipping:</th>
						<td class="td" style="color: #636363;border: 1px solid #e5e5e5;vertical-align: middle;padding: 12px;text-align: left">
							<span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>15.00</span>&nbsp;<small class="shipped_via">via Flat rate</small>
						</td>
					</tr>-->
					<tr>
						<th class="td" scope="row" colspan="2" style="color: #636363;border: 1px solid #e5e5e5;vertical-align: middle;padding: 12px;text-align: left">Payment method:</th>
						<td class="td" style="color: #636363;border: 1px solid #e5e5e5;vertical-align: middle;padding: 12px;text-align: left">'.$paymentMethod.'</td>
					</tr>
					<tr>
						<th class="td" scope="row" colspan="2" style="color: #636363;border: 1px solid #e5e5e5;vertical-align: middle;padding: 12px;text-align: left">Total:</th>
						<td class="td" style="color: #636363;border: 1px solid #e5e5e5;vertical-align: middle;padding: 12px;text-align: left"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">'.get_woocommerce_currency_symbol ().'</span>'.$subTotal.'</span></td>
					</tr>
				</tfoot>
				</table>
			</div>
			<table id="addresses" cellspacing="0" cellpadding="0" border="0" style="width: 100%;vertical-align: top;margin-bottom: 40px;padding: 0">
				<tbody>
					<tr>
						<td valign="top" width="50%" style="text-align: left;font-family: \'Helvetica Neue\', Helvetica, Roboto, Arial, sans-serif;border: 0;padding: 0">
							<h2 style="color: #96588a;font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif;font-size: 18px;font-weight: bold;line-height: 130%;margin: 0 0 18px;text-align: left">Billing address</h2>
							<address class="address" style="padding: 12px;color: #636363;border: 1px solid #e5e5e5">'.$billingAddress.'						
							</address>
						</td>
						<td valign="top" width="50%" style="text-align: left;font-family: \'Helvetica Neue\', Helvetica, Roboto, Arial, sans-serif;padding: 0">
							<h2 style="color: #96588a;font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif;font-size: 18px;font-weight: bold;line-height: 130%;margin: 0 0 18px;text-align: left">Shipping address</h2>
							<address class="address" style="padding: 12px;color: #636363;border: 1px solid #e5e5e5">'.$shippingAddress.'</address>
						</td>
					</tr>
				</tbody>
			</table>
																	</div>
																</td>
															</tr>
															</tbody>
															</table>
															<!-- End Content -->
														</td>
													</tr>
												</tbody>
											</table>
											<!-- End Body -->
										</td>
									</tr>
									<tr>
										<td align="center" valign="top">
											<!-- Footer -->
											<table border="0" cellpadding="10" cellspacing="0" width="600" id="template_footer">
												<tbody>
													<tr>
														<td valign="top" style="padding: 0">
															<table border="0" cellpadding="10" cellspacing="0" width="100%">
																<tbody>
																	<tr>
																		<td colspan="2" valign="middle" id="credit" style="border: 0;color: #c09bb9;font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif;font-size: 12px;line-height: 125%;text-align: center;padding: 0 48px 48px 48px">
																			<p>Just Vapours Australia</p>
																		</td>
																	</tr>
																</tbody>
															</table>
														</td>
													</tr>
												</tbody>
											</table>
											<!-- End Footer -->
										</td>
									</tr>
								</tbody>
							</table>
						</td>
					</tr>
				</tbody>
			</table>
		</div>';
		return $content;
	}
	
	public function removeAllProductVariations($parentProduct){
		global $wpdb;
		//$wpdb->query("UPDATE {$wpdb->prefix}posts SET post_status = 'trash' WHERE post_type = 'product_variation' AND post_status = 'publish' AND post_parent = '".$parentProduct."' ");
	}
	
	/**
	 * Get shipping notice
	 */
	public function jvaWPAJAXGetShippingNotice() {
		$freeShipping = get_option('woocommerce_free_shipping_settings');
		$freeShippingMin = $freeShipping['min_amount'];
		$freeShippingMin = !empty($freeShippingMin) ? $freeShippingMin : 100;
		
		$cartSubtotal = WC()->cart->subtotal;
		
		$response = [
			'status' 			=> 0,
			'text' 				=> '',
			'free_shipping_min' => $freeShippingMin,
			'cart_subtotal' 	=> $cartSubtotal
		];
		
		if( $cartSubtotal < $freeShippingMin || $cartSubtotal == 0 ) {
			$response['status'] = 1;
			$response['text'] = $cartSubtotal < $freeShippingMin ? 'Spend an additional '. wc_price($freeShippingMin - $cartSubtotal) .', and get free shipping.' : 'Free shipping of orders over '. wc_price($freeShippingMin);
		}elseif($cartSubtotal >= $freeShippingMin){
			$response['status'] = 1;
			$response['text'] =  'Congratulations, you will now receive free shipping for your order';
		}

		
		wp_send_json($response);
	}
	
	/**
	 * States callback
	 */
	public function swiftpost_integration_states_callback() {
		global $woocommerce;
		
		if( isset($_POST['swiftpos_exc_states']) && $_POST['swiftpos_exc_states'] ) :
			$excStatesArr = [];
			$excStates = $_POST['swiftpos_exc_states'];
		
			if( 0 < count($excStates) ) :
				foreach( $excStates as $state ) :
					if( strpos($state, '--') ) :
						$state = explode('--', $state);
		
						$excStatesArr[$state[0]][] = $state[1];
					else :
						$excStatesArr[$state] = '';
					endif;
				endforeach;
			endif;
		
			update_option('swiftpos_exc_states', $excStatesArr);
		endif;
	?>
		<style>
		div#swiftpost_integration {
			background: #fff;
			padding: 30px;
			margin-top: 20px;
			box-shadow: 0 0px 19px rgba(130, 130, 130, 0.12), 0 1px 4px rgba(132, 132, 132, 0.16);
		}
		ul {
			list-style: inside;
		}
		.divider {
			border-top: 3px solid #f1f1f1;
		}
		p.submit {
			display: inline-block;
			margin: 0px;
			margin-left: 5px;
		}
		</style>
		<div id="swiftpost_integration">
			<h1>Manage States/Regions</h1>
			<h3>Exclude states or regions</h3>
			<form method="post" enctype="multipart/form-data">
				<?php 
				$wcCountries = new WC_Countries();
				$countries = $wcCountries->__get('countries');
				$defaultCountry = $wcCountries->get_base_country();
				$excludedStates = get_option('swiftpos_exc_states');
				?>
				<select id="swiftpos--select2" name="swiftpos_exc_states[]" multiple>
					<?php 
					foreach( $countries as $countryCode => $country ) :
						$states = $wcCountries->get_states($countryCode); 
						
						if( $states ) :
					?>
						<optgroup label="<?php echo $country; ?>">
					<?php
							foreach( $states as $stateCode => $state ) :
						?>
							<option value="<?php echo $countryCode.'--'. $stateCode; ?>" <?php echo array_key_exists($countryCode, $excludedStates) && in_array($stateCode, $excludedStates[$countryCode]) ? 'selected=""' : ''; ?>><?php echo $state; ?></option>
						<?php 
							endforeach; 
					?>
						</optgroup>	
					<?php
						else :
						?>
						<option value="<?php echo $countryCode; ?>" <?php echo array_key_exists($countryCode, $excludedStates) ? 'selected=""' : ''; ?>><?php echo $country; ?></option>
						<?php
						endif; 
					endforeach; 
					?>
				</select>
				
				<div class="clear"></div>
				<?php submit_button('Save', 'save', 'save' ) ?>
			</form>

		</div>
	<?php
	}
	
	/**
	 * Filter countries
	 */
	public function jvaWooCountries($countries) {
		if( is_admin() )
			return $states;
			
		$excludedStates = get_option('swiftpos_exc_states');
		
		if( $excludedStates && (0 < count($excludedStates)) ) :
			foreach( $excludedStates as $state => $regions ) :
				if( is_array($regions) ) continue;
		
				unset($countries[$state]);
			endforeach;
		endif;

		return $countries;
	}
	
	/**
	 * Filter states
	 */
	public function jvaWooStates($states) {
		if( is_admin() )
			return $states;
			
		$excludedStates = get_option('swiftpos_exc_states');
		
		if( $excludedStates && (0 < count($excludedStates)) ) :
			foreach( $excludedStates as $state => $regions ) :
				if( !is_array($regions) ) continue;
		
				foreach( $regions as $region ) :
					unset($states[$state][$region]);
				endforeach;
			endforeach;
		endif;

		return $states;
	}

	
	public function wc_apply_filter_checkout_for_coupons( $subtotal, $compound, $cart_object ) {


        // Your logic to get store credit value for a user will go here
        $store_credit = 0;
        $total_price = 0;
        // This is necessary for WC 3.0+
	    if (is_admin() && ! defined( 'DOING_AJAX' ) )
	        return;

	    if(!$this->is_cart_price_rules_enabled())
	    	return;
	    // Avoiding hook repetition (when using price calculations for example)
	    if ( did_action( 'woocommerce_before_calculate_totals' ) >= 2 )
	        return;
	    
	    $cart_items = $cart_object->cart_contents;
	    $cart_price_rules = $this->get_cart_price_rules();

	  	if ( !empty( $cart_items ) && !empty($cart_price_rules) ) {
	  			$passed_rules = array();
				foreach ( $cart_object->get_cart() as $hash => $value ) {

					// Skip applying rules if Cart product is on sale
					 if(!empty($value['data']->get_sale_price()) && $value['data']->get_sale_price() < $value['data']->get_regular_price()){
					 	continue;
					 }
		 			foreach ($cart_price_rules as $key => $rule) {
		 				
		 				$product_cat_ids = wp_get_post_terms($value['product_id'],'product_cat',array('fields'=>'ids'));
		 				$common_cat = array_intersect($rule['product_category'], $product_cat_ids );
		 				if(empty($rule['product_category'])	|| (is_array($rule['product_category']) && 
		 					count($common_cat) >=1 )
		 				){
		 					$variations_on_rule = array();
		 					
		 					if(!empty($rule["size"])){
		 						$variations_on_rule[] = $rule["size"]->slug;
		 					}

		 					if(empty($variations_on_rule) || 
		 						(!empty($value["variation"]["attribute_pa_size"])  && in_array($value["variation"]["attribute_pa_size"], $variations_on_rule) )
		 					){
		 						$rule_cat = $common_cat[0];
		 						foreach ($common_cat as $r_cat) {
		 							$t_details = get_term($r_cat, 'product_cat');
									if(!empty($t_details->parent)){
										$rule_cat = $t_details->parent; // parent category id or $t_details->category_parent
									}
		 						}

		 						$rule_key = 'cat_'.$rule_cat.'_size_'.$value["variation"]["attribute_pa_size"];
		 						//$rule_key = $key;

		 						if(isset($passed_rules[$rule_key]["rule_passed_qty"])){
		 							
		 							if(!in_array($value['variation_id'], $passed_rules[$rule_key]['rule_passed_variation_ids'])){
		 								$passed_rules[$rule_key]['rule_passed_qty'] += $value['quantity'];
		 								$passed_rules[$rule_key]['rule_passed_variation_ids'][] = $value['variation_id'];
		 							}
		 						}else{
			 						
		 							$passed_rules[$rule_key]['rule_passed_qty'] = $value['quantity'];
		 							$passed_rules[$rule_key]['rule_passed_variation_ids'][] = $value['variation_id'];
		 						}
		 						$passed_rules[$rule_key]['rule_qty_arr'][] = $rule['product_quantity'];
		 						$passed_rules[$rule_key]['rules']['qty_'.$rule['product_quantity']] = $rule;
		 						
		 					}
		 				}

		 			}
				}

				if(!empty($passed_rules)){

					foreach ($passed_rules as $key => $passed_rule) {
						$rule_passed_qty_arr = array_unique($passed_rule['rule_qty_arr']);
						$rule_passed_qty_arr[] = 1;
						$qty_subset = $this->generate_combinational_sum($rule_passed_qty_arr, $passed_rule['rule_passed_qty']);
						$passed_rules[$key]['qty_subset'] = $qty_subset;
					}
					//var_dump($passed_rules);
					$arr_skip = array();
					foreach ( $cart_object->get_cart() as $hash => $value ) {
						// Skip applying rules if Cart product is on sale
						$product_cat_ids = wp_get_post_terms($value['product_id'],'product_cat',array('fields'=>'ids'));
						$total_price_added = 0;
			 			foreach ($product_cat_ids as $cat) {
			 				$t_details = get_term($r_cat, 'product_cat');

			 				if(empty($t_details))
			 					continue;

			 				$r_key = 'cat_'.$t_details->term_id.'_size_'.$value["variation"]["attribute_pa_size"];

			 				if(is_array($passed_rules[$r_key]['qty_subset']) && !empty($passed_rules[$r_key]['rules'])){
			 					foreach ($passed_rules[$r_key]['qty_subset'] as $s_key => $r_qty) {
			 						if(!empty($passed_rules[$r_key]['rules']['qty_'.$r_qty]) && !in_array($r_key.$s_key, $arr_skip)){
			 							$total_price += $passed_rules[$r_key]['rules']['qty_'.$r_qty]['product_price'];
			 							$arr_skip[] = $r_key.$s_key;
			 						}elseif($r_qty == 1 && !in_array($r_key.$s_key, $arr_skip)){
			 							$total_price += $value['data']->get_regular_price();
			 							$arr_skip[] = $r_key.$s_key;
			 						}
			 						$total_price_added = 1;
			 					}
			 				}elseif(is_array($passed_rules[$r_key]['rule_passed_variation_ids']) && in_array($value['variation_id'],  $passed_rules[$r_key]['rule_passed_variation_ids'])){
			 					$total_price_added = 1;
			 				}
			 			}

			 			if(!$total_price_added ){
			 				$total_price += $value['data']->get_regular_price() * intval($value['quantity']);
			 			}
			 			//$total_price = $value['data']->get_regular_price() * intval($value['quantity']);
					}

				$store_credit = $cart_object->subtotal - $total_price;
				//var_dump($store_credit, $cart_object->subtotal, $total_price);
				if($store_credit){
		            // Setup our virtual coupon
		            $coupon_name = 'bundle-discount';
		            $coupon = array($coupon_name => $store_credit);

		            // Apply the store credit coupon to the cart & update totals
		            $cart_object->applied_coupons = array($coupon_name);
		            $cart_object->set_discount_total($store_credit);
		            $cart_object->set_total( $cart_object->total - $store_credit);
		            $cart_object->coupon_discount_totals = $coupon;
		        }

				}



	     }

	        // We only need to add a store credit coupon if they have store credit
	    return $subtotal; 
	}

	public function wc_before_woocommerce_checkout_create_order_for_coupons( $order, $cart_object ) {
$cart_object = WC()->cart;
//var_dump($order, $cart_object); die;
        // Your logic to get store credit value for a user will go here
        $store_credit = 0;
        $total_price = 0;
        // This is necessary for WC 3.0+
	    if (is_admin() && ! defined( 'DOING_AJAX' ) )
	        return;

	    if(!$this->is_cart_price_rules_enabled())
	    	return;
	    // Avoiding hook repetition (when using price calculations for example)
	    if ( did_action( 'woocommerce_before_calculate_totals' ) >= 2 )
	        return;
	    
	    $cart_items = $cart_object->cart_contents;
	    $cart_price_rules = $this->get_cart_price_rules();

	  	if ( !empty( $cart_items ) && !empty($cart_price_rules) ) {
	  			$passed_rules = array();
				foreach ( $cart_object->get_cart() as $hash => $value ) {

					// Skip applying rules if Cart product is on sale
					 if(!empty($value['data']->get_sale_price()) && $value['data']->get_sale_price() < $value['data']->get_regular_price()){
					 	continue;
					 }
		 			foreach ($cart_price_rules as $key => $rule) {
		 				
		 				$product_cat_ids = wp_get_post_terms($value['product_id'],'product_cat',array('fields'=>'ids'));
		 				$common_cat = array_intersect($rule['product_category'], $product_cat_ids );
		 				if(empty($rule['product_category'])	|| (is_array($rule['product_category']) && 
		 					count($common_cat) >=1 )
		 				){
		 					$variations_on_rule = array();
		 					
		 					if(!empty($rule["size"])){
		 						$variations_on_rule[] = $rule["size"]->slug;
		 					}

		 					if(empty($variations_on_rule) || 
		 						(!empty($value["variation"]["attribute_pa_size"])  && in_array($value["variation"]["attribute_pa_size"], $variations_on_rule) )
		 					){
		 						$rule_cat = $common_cat[0];
		 						foreach ($common_cat as $r_cat) {
		 							$t_details = get_term($r_cat, 'product_cat');
									if(!empty($t_details->parent)){
										$rule_cat = $t_details->parent; // parent category id or $t_details->category_parent
									}
		 						}

		 						$rule_key = 'cat_'.$rule_cat.'_size_'.$value["variation"]["attribute_pa_size"];
		 						//$rule_key = $key;

		 						if(isset($passed_rules[$rule_key]["rule_passed_qty"])){
		 							
		 							if(!in_array($value['variation_id'], $passed_rules[$rule_key]['rule_passed_variation_ids'])){
		 								$passed_rules[$rule_key]['rule_passed_qty'] += $value['quantity'];
		 								$passed_rules[$rule_key]['rule_passed_variation_ids'][] = $value['variation_id'];
		 							}
		 						}else{
			 						
		 							$passed_rules[$rule_key]['rule_passed_qty'] = $value['quantity'];
		 							$passed_rules[$rule_key]['rule_passed_variation_ids'][] = $value['variation_id'];
		 						}
		 						$passed_rules[$rule_key]['rule_qty_arr'][] = $rule['product_quantity'];
		 						$passed_rules[$rule_key]['rules']['qty_'.$rule['product_quantity']] = $rule;
		 						
		 					}
		 				}

		 			}
				}

				if(!empty($passed_rules)){

					foreach ($passed_rules as $key => $passed_rule) {
						$rule_passed_qty_arr = array_unique($passed_rule['rule_qty_arr']);
						$rule_passed_qty_arr[] = 1;
						$qty_subset = $this->generate_combinational_sum($rule_passed_qty_arr, $passed_rule['rule_passed_qty']);
						$passed_rules[$key]['qty_subset'] = $qty_subset;
					}
					//var_dump($passed_rules);
					$arr_skip = array();
					foreach ( $cart_object->get_cart() as $hash => $value ) {
						// Skip applying rules if Cart product is on sale
						$product_cat_ids = wp_get_post_terms($value['product_id'],'product_cat',array('fields'=>'ids'));
						$total_price_added = 0;
			 			foreach ($product_cat_ids as $cat) {
			 				$t_details = get_term($r_cat, 'product_cat');

			 				if(empty($t_details))
			 					continue;

			 				$r_key = 'cat_'.$t_details->term_id.'_size_'.$value["variation"]["attribute_pa_size"];

			 				if(is_array($passed_rules[$r_key]['qty_subset']) && !empty($passed_rules[$r_key]['rules'])){
			 					foreach ($passed_rules[$r_key]['qty_subset'] as $s_key => $r_qty) {
			 						if(!empty($passed_rules[$r_key]['rules']['qty_'.$r_qty]) && !in_array($r_key.$s_key, $arr_skip)){
			 							$total_price += $passed_rules[$r_key]['rules']['qty_'.$r_qty]['product_price'];
			 							$arr_skip[] = $r_key.$s_key;
			 						}elseif($r_qty == 1 && !in_array($r_key.$s_key, $arr_skip)){
			 							$total_price += $value['data']->get_regular_price();
			 							$arr_skip[] = $r_key.$s_key;
			 						}
			 						$total_price_added = 1;
			 					}
			 				}elseif(is_array($passed_rules[$r_key]['rule_passed_variation_ids']) && in_array($value['variation_id'],  $passed_rules[$r_key]['rule_passed_variation_ids'])){
			 					$total_price_added = 1;
			 				}
			 			}

			 			if(!$total_price_added ){
			 				$total_price += $value['data']->get_regular_price() * intval($value['quantity']);
			 			}
			 			//$total_price = $value['data']->get_regular_price() * intval($value['quantity']);
					}

				$store_credit = $cart_object->subtotal - $total_price;


				//var_dump($store_credit, $cart_object->subtotal, $total_price);
				if($store_credit){
		            // Setup our virtual coupon
		            $coupon_name = 'bundle-discount';
		            $coupon = array($coupon_name => $store_credit);

		            // Apply the store credit coupon to the cart & update totals
		            $cart_object->applied_coupons = array($coupon_name);
		            $cart_object->set_discount_total($store_credit);
		            $cart_object->set_total( $cart_object->total - $store_credit);
		            $cart_object->coupon_discount_totals = $coupon;


		            $order->set_discount_total( $cart_object->get_discount_total() );
					$order->set_discount_tax($cart_object->get_discount_tax() );
					$order->set_total( $cart_object->get_total( 'edit' ) );
					$order->save();
		        }

				}



	     }

	        // We only need to add a store credit coupon if they have store credit
	    return $subtotal; 
	}

	
	
	public function sync_SwiftPOS_Order( $order_id ){
	    //$order = wc_get_order( $order_id );
	    update_post_meta(67602, '_order_custom_data', 'payment_done-'. date('Y-m-d H:i:s'));
	    //update_post_meta($order_id, '_order_custom_data', date('Y-m-d H:i:s').'-'.time());
	    /*$user = $order->get_user();
	    if( $user ){
	        // do something with the user
	    }*/
	}


}