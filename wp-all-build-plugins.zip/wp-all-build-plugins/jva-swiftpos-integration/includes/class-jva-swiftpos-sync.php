<?php class SwiftPOS_Sync{
	public $key;
	public $status;
	public $msg;
	public $errors;
	public $update_product_ids;

	public function __construct(){
		if(file_exists(PLUGIN_BASE_PATH . 'includes/class-jva-swiftpos-integration.php')){
			require_once PLUGIN_BASE_PATH . 'includes/class-jva-swiftpos-integration.php';
		}
	}
	
	public function run(){
		$sync_cateogry = $this->sync_categories();
	}
	
	public function get_family(){
		$data = array();
		$all_family = $this->request($this->key, $data, "Family");
		$family_IDs = array();
		if($all_family != false){
			$i = 0;
			$n = 0;
			foreach($all_family as $family){

				$family_IDs[] = $family->Id;
			}

			$this->status = true;
			return $family_IDs;
		}else{
			$this->status = false;
			$this->msg = 'Synchronization could not be completed, no product family found.';
			return false;
		}

	}
	public function ajax_sync_products_cron_start($reupload_images = false, $force_sync = true){
		if(($force_sync == true || $force_sync == 'true') && $force_sync != 'false' ) {
			$warehouse = array('JVA', 'Melbourne', 'JAA');
			$syncJva = new JVA__Functions();
			foreach($warehouse as $syncWarehouse) {
				switch ( $syncWarehouse ){
					case 'JVA' :
						$location = $syncJva->get_swiftpos_creds('locationId');
						$user = $syncJva->get_swiftpos_creds('userId');
						$pass = $syncJva->get_swiftpos_creds('password');
						$ApiKey = $this->assign_api_key($location, $user, $pass);
						if($ApiKey == true){
							$family = $this->get_family();
							if($family == false){
								return false;
							}
							$data = array('includeImage' => true, 'familyId'=> $family[0]);
							$all_products = $this->request($this->key, $data, "Product");
							if($all_products != false && !empty($all_products)){
								update_option("swiftPostApi_data","");
								update_option("swiftPostApi_data",$all_products);
							}
						}
					break;
					case 'Melbourne':
						$location = $syncJva->get_swiftpos_creds_melbourne('locationId');
						$user = $syncJva->get_swiftpos_creds_melbourne('userId');
						$pass = $syncJva->get_swiftpos_creds_melbourne('password');
						$ApiKey = $this->assign_api_key($location, $user, $pass);
						if($ApiKey == true){
							$family = $this->get_family();
							if($family == false){
								return false;
							}
							$data = array('includeImage' => true, 'familyId'=> $family[0]);
							$all_products = $this->request($this->key, $data, "Product");
							if($all_products != false && !empty($all_products)){
								update_option("swiftPostApi_melbourne_data","");
								update_option("swiftPostApi_melbourne_data",$all_products);
							}
						}
					break;
					case 'JAA':
						$location = $syncJva->get_swiftpos_creds_just_automiser('locationId');
						$user = $syncJva->get_swiftpos_creds_just_automiser('userId');
						$pass = $syncJva->get_swiftpos_creds_just_automiser('password');
						$ApiKey = $this->assign_api_key($location, $user, $pass);
						if($ApiKey == true){
							$family = $this->get_family();
							if($family == false){
								return false;
							}
							$data = array('includeImage' => true, 'familyId'=> $family[0]);
							$all_products = $this->request($this->key, $data, "Product");
							if($all_products != false && !empty($all_products)){
								update_option("swiftPostApi_jaa_data","");
								update_option("swiftPostApi_jaa_data",$all_products);
							}
						}
					break;
				}
			}
			update_option("sync_cron_offset", '');
			update_option("sync_cron_limit", '');
			update_option("cronSyncWarehouse", 'Melbourne');
			$this->ajax_before_sync_products();
		}
		exit();
	}

	public function ajax_sync_products_cron_start2($reupload_images = false, $force_sync = true){
		if(($force_sync == true || $force_sync == 'true') && $force_sync != 'false' ) {
			$warehouse = array('JVA', 'Melbourne', 'JAA');
			$syncJva = new JVA__Functions();
			foreach($warehouse as $syncWarehouse) {
				switch ( $syncWarehouse ){
					case 'JVA' :
						$location = $syncJva->get_swiftpos_creds('locationId');
						$user = $syncJva->get_swiftpos_creds('userId');
						$pass = $syncJva->get_swiftpos_creds('password');
						$ApiKey = $this->assign_api_key($location, $user, $pass);
						var_dump($ApiKey); die();
						if($ApiKey == true){
							// $family = $this->get_family();
							// if($family == false){
							// 	return false;
							// }
							$data = array('includeImage' => false, 'familyId'=> $family[0]);
							$all_products = $this->request($this->key, $data, "Product");

							var_dump($all_products); die();

							if($all_products != false && !empty($all_products)){
								update_option("swiftPostApi_data","");
								update_option("swiftPostApi_data",$all_products);
							}
						}
					break;
					case 'Melbourne':
						$location = $syncJva->get_swiftpos_creds_melbourne('locationId');
						$user = $syncJva->get_swiftpos_creds_melbourne('userId');
						$pass = $syncJva->get_swiftpos_creds_melbourne('password');
						$ApiKey = $this->assign_api_key($location, $user, $pass);
						var_dump($ApiKey); die();
						// if($ApiKey == true){
						// 	$family = $this->get_family();
						// 	if($family == false){
						// 		return false;
						// 	}
						// 	$data = array('includeImage' => true, 'familyId'=> $family[0]);
						// 	$all_products = $this->request($this->key, $data, "Product");
						// 	if($all_products != false && !empty($all_products)){
						// 		update_option("swiftPostApi_melbourne_data","");
						// 		update_option("swiftPostApi_melbourne_data",$all_products);
						// 	}
						// }
					break;
					case 'JAA':
						$location = $syncJva->get_swiftpos_creds_just_automiser('locationId');
						$user = $syncJva->get_swiftpos_creds_just_automiser('userId');
						$pass = $syncJva->get_swiftpos_creds_just_automiser('password');
						$ApiKey = $this->assign_api_key($location, $user, $pass);
						var_dump($ApiKey); die();
						// if($ApiKey == true){
						// 	$family = $this->get_family();
						// 	if($family == false){
						// 		return false;
						// 	}
						// 	$data = array('includeImage' => true, 'familyId'=> $family[0]);
						// 	$all_products = $this->request($this->key, $data, "Product");
						// 	if($all_products != false && !empty($all_products)){
						// 		update_option("swiftPostApi_jaa_data","");
						// 		update_option("swiftPostApi_jaa_data",$all_products);
						// 	}
						// }
					break;
				}
			}
			// update_option("sync_cron_offset", '');
			// update_option("sync_cron_limit", '');
			// update_option("cronSyncWarehouse", 'Melbourne');
			// $this->ajax_before_sync_products();
		}
		exit();
	}
	
	public function ajax_sync_products_cron2($reupload_images = false, $force_sync = false, $offset, $limit, $syncWarehouse){
		if(in_array($syncWarehouse, array('JVA'))) {
			$result = $this->sync_products2($reupload_images, $force_sync, $offset, $limit, $syncWarehouse);
			return $result;
			exit();
		} else {
			exit();
		}
	}

	public function ajax_sync_products_cron($reupload_images = false, $force_sync = false, $offset, $limit, $syncWarehouse){
		if(in_array($syncWarehouse, array('JVA', 'Melbourne','JAA'))) {
			if(($force_sync == true || $force_sync == 'true') && $force_sync != 'false' ) {
				$syncJva = new JVA__Functions();
				switch ( $syncWarehouse ){
					case 'JVA' :
						$location = $syncJva->get_swiftpos_creds('locationId');
						$user = $syncJva->get_swiftpos_creds('userId');
						$pass = $syncJva->get_swiftpos_creds('password');
						$ApiKey = $this->assign_api_key($location, $user, $pass);
						if($ApiKey == true){
							$family = $this->get_family();
							if($family == false){
								return false;
							}
							$data = array('includeImage' => true, 'familyId'=> $family[0]);
							$all_products = $this->request($this->key, $data, "Product");
							if($all_products != false && !empty($all_products)){
								update_option("swiftPostApi_data","");
								update_option("swiftPostApi_data",$all_products);
							}
						}
					break;
					case 'Melbourne':
						$location = $syncJva->get_swiftpos_creds_melbourne('locationId');
						$user = $syncJva->get_swiftpos_creds_melbourne('userId');
						$pass = $syncJva->get_swiftpos_creds_melbourne('password');
						$ApiKey = $this->assign_api_key($location, $user, $pass);
						if($ApiKey == true){
							$family = $this->get_family();
							if($family == false){
								return false;
							}
							$data = array('includeImage' => true, 'familyId'=> $family[0]);
							$all_products = $this->request($this->key, $data, "Product");
							if($all_products != false && !empty($all_products)){
								update_option("swiftPostApi_melbourne_data","");
								update_option("swiftPostApi_melbourne_data",$all_products);
							}
						}
					break;
					case 'JAA':
						$location = $syncJva->get_swiftpos_creds_just_automiser('locationId');
						$user = $syncJva->get_swiftpos_creds_just_automiser('userId');
						$pass = $syncJva->get_swiftpos_creds_just_automiser('password');
						$ApiKey = $this->assign_api_key($location, $user, $pass);
						if($ApiKey == true){
							$family = $this->get_family();
							if($family == false){
								return false;
							}
							$data = array('includeImage' => true, 'familyId'=> $family[0]);
							$all_products = $this->request($this->key, $data, "Product");
							if($all_products != false && !empty($all_products)){
								update_option("swiftPostApi_jaa_data","");
								update_option("swiftPostApi_jaa_data",$all_products);
							}
						}
					break;
				}
			}
			$result = $this->sync_products($reupload_images, $force_sync, $offset, $limit, $syncWarehouse);
			return $result;
			exit();
		} else {
			exit();
		}
	}
	
	public function ajax_before_sync_products(){
		$syncJva = new JVA__Functions();
		$allProducts = $syncJva->get_all_products();
		if (!empty($allProducts)) {
			foreach($allProducts as $product) {
				$productId = $product->ID;
				$args = array(
					'post_type' => 'product_variation',
					'post_parent' => $productId,
					'numberposts' => -1,
					'post_status' => array('publish', 'pending', 'draft', 'future', 'trash')
				);
				$executeQuery = new WP_Query( $args );
				if ( $executeQuery->have_posts() ) {
					while ( $executeQuery->have_posts() ) : $executeQuery->the_post();
						$variation_id = get_the_ID();;
						update_post_meta($variation_id, 'swiftpost_product', 'false');
					endwhile;
					wp_reset_postdata();
				}
				
				update_post_meta($productId, 'swiftpost_product', 'false');
			}
		}
		update_option("variationSync",'');
	}
	
	public function ajax_after_sync_products(){
		 $args = array(
			'post_type'      => 'product',
			'numberposts' => -1,
			'post_status' => array('publish', 'pending', 'draft', 'future', 'trash'),
			'meta_query' => array(
				array(
					'key'     => 'swiftpost_product',
					'value'   => 'false',
					'compare' => '=',
				),
			),
		);
		$allProducts = get_posts($args);
		if(!empty($allProducts)) {
			foreach($allProducts as $product){
				wp_trash_post($product->ID);
			}
		}
		$this->thrashAllVariationId();
	}
	
	public function thrashAllVariationId(){
		$args = array(
			'post_type'      => 'product_variation',
			'numberposts' => -1,
			'post_status' => array('publish', 'pending', 'draft', 'future', 'trash'),
			'meta_query' => array(
				array(
					'key'     => 'swiftpost_product',
					'value'   => 'false',
					'compare' => '=',
				),
			),
		);
		$allProducts = get_posts($args);
		if(!empty($allProducts)) {
			foreach($allProducts as $product){
				wp_trash_post($product->ID);
			}
		}
	}
	
	public function update_product_status($post_id){
		wp_untrash_post($post_id);
		wc_delete_product_transients($post_id);
	}
	
	public function ajax_sync_products($reupload_images = false, $force_sync = false, $offset, $limit, $syncWarehouse){
		if(!empty($syncWarehouse)) {
			if(($force_sync == true || $force_sync == 'true') && $force_sync != 'false' ) {
				$syncJva = new JVA__Functions();
				switch ( $syncWarehouse ){
					case 'JVA' :
						$location = $syncJva->get_swiftpos_creds('locationId');
						$user = $syncJva->get_swiftpos_creds('userId');
						$pass = $syncJva->get_swiftpos_creds('password');
						$ApiKey = $this->assign_api_key($location, $user, $pass);
						if($ApiKey == true){
							$family = $this->get_family();
							if($family == false){
								return false;
							}
							$data = array('includeImage' => true, 'familyId'=> $family[0]);
							$all_products = $this->request($this->key, $data, "Product");
							if($all_products != false && !empty($all_products)){
								update_option("swiftPostApi_data","");
								update_option("swiftPostApi_data",$all_products);
							}
						}
					break;
					case 'Melbourne':
						$location = $syncJva->get_swiftpos_creds_melbourne('locationId');
						$user = $syncJva->get_swiftpos_creds_melbourne('userId');
						$pass = $syncJva->get_swiftpos_creds_melbourne('password');
						$ApiKey = $this->assign_api_key($location, $user, $pass);
						if($ApiKey == true){
							$family = $this->get_family();
							if($family == false){
								return false;
							}
							$data = array('includeImage' => true, 'familyId'=> $family[0]);
							$all_products = $this->request($this->key, $data, "Product");
							if($all_products != false && !empty($all_products)){
								update_option("swiftPostApi_melbourne_data","");
								update_option("swiftPostApi_melbourne_data",$all_products);
							}
						}
					break;
					case 'JAA':
						$location = $syncJva->get_swiftpos_creds_just_automiser('locationId');
						$user = $syncJva->get_swiftpos_creds_just_automiser('userId');
						$pass = $syncJva->get_swiftpos_creds_just_automiser('password');
						$ApiKey = $this->assign_api_key($location, $user, $pass);
						if($ApiKey == true){
							$family = $this->get_family();
							if($family == false){
								return false;
							}
							$data = array('includeImage' => true, 'familyId'=> $family[0]);
							$all_products = $this->request($this->key, $data, "Product");
							if($all_products != false && !empty($all_products)){
								update_option("swiftPostApi_jaa_data","");
								update_option("swiftPostApi_jaa_data",$all_products);
							}
						}
					break;
				}
			}
			$result = $this->sync_products($reupload_images, $force_sync, $offset, $limit, $syncWarehouse);
			echo trim(json_encode($result));
			exit();
		}
	}
	
	public function sync_products($reupload_images = false, $force_sync, $offset, $limit, $syncWarehouse){
		$JVA__Functions = new JVA__Functions();
		switch ( $syncWarehouse ){
			case 'JVA' :
				$location = $JVA__Functions->get_swiftpos_creds('locationId');
				$all_products = get_option("swiftPostApi_data");
			break;
			case 'Melbourne':
				$location = $JVA__Functions->get_swiftpos_creds_melbourne('locationId');
				$all_products = get_option("swiftPostApi_melbourne_data");
			break;
			case 'JAA':
				$location = $JVA__Functions->get_swiftpos_creds_just_automiser('locationId');
				$all_products = get_option("swiftPostApi_jaa_data");
			break;
		}
		if($offset == 0 && $limit == 5) {
			update_option("variationSync",'');
		}
		
		$supplierData = $JVA__Functions->getSupplier($location);
		if(!empty($supplierData)) {
			$supplierId = $supplierData->ID;
			$supplierName = $supplierData->post_title;
		}
		
		if(empty($all_products)) {
			$this->errors = array('key'=> "", 'data'=> "", 'function'=> "Product", 'response'=> "");
		}
		
		if($all_products != false){
			$i = 0;
			$n = 0;
			$failed = "";
			$all_new_products = array();
			$all_coil_products = array();
			$titleLookup = JVA__Functions::productTitleLookUp();
			$brandLookUp = JVA__Functions::brandLookUp();
			$juiceFlavourLookUp = JVA__Functions::juiceFlavourLookUp();

			foreach($all_products as $product) {
				$productSKU = $product->InventoryCode;
				$productShort = $product->Description->Short;
				$groupId = $product->Group->Id;
				$categoryId = $product->Category->Id;
				$productParentSKU = substr($productSKU, 0, 7);

				$productTypeSKU = substr($productSKU, 7 ,1);
				if($productTypeSKU == 4){
					$all_new_products['STANDARD'][] = $product;
				}elseif(is_numeric(substr($productSKU, 0, 7))) {
					if($productTypeSKU != false && strlen($productTypeSKU) == 1 && is_numeric($productTypeSKU) && ($productTypeSKU == 7 || $productTypeSKU == 5)) { //JUICE
						$sizeSKU = substr($productSKU, 8 ,1);
						$flavourSKU = substr($productSKU, 10 ,3);
						if(($flavourSKU != "") && (strlen($flavourSKU) > 1) && in_array($sizeSKU, array(1,3,5,7) )) {
							$viscosityAttribute = '';
							$sizeAttribute = '';
							$flavourAttribute = '';
							if($productTypeSKU == 5) {
								$viscosityAttribute = '50-50';
							} else if($productTypeSKU == 7) { 
								$viscosityAttribute = '70-30';
							} 
							if($sizeSKU == 1){
								$sizeAttribute = '100 ml';
							} else if($sizeSKU == 7){
								$sizeAttribute = '75 ml';
							} else if($sizeSKU == 5){
								$sizeAttribute = '50 ml';
							} else if($sizeSKU == 3){
								$sizeAttribute = '30 ml';
							}
							if(($flavourSKU != "")) {
								if($categoryId == 94) {
									$flavour = $juiceFlavourLookUp["standard"][$flavourSKU];
									$flavourAttribute = !empty($flavour) ? $flavour : $productShort;
								} else if($categoryId == 93) {
									$flavour = $juiceFlavourLookUp["tjuice"][$flavourSKU];
									$flavourAttribute = !empty($flavour) ? $flavour : $productShort;
								} else if($categoryId == 92) {
									$flavour = $juiceFlavourLookUp["dragon"][$flavourSKU];
									$flavourAttribute = !empty($flavour) ? $flavour : $productShort;
								} else if($categoryId == 340) {
									$flavour = $juiceFlavourLookUp["greengold"][$flavourSKU];
									$flavourAttribute = !empty($flavour) ? $flavour : $productShort;
								} else {
									$flavourAttribute = $productShort;
								}
							}
							if($viscosityAttribute) {
								$product->attributes['viscosity'] = $viscosityAttribute;
							}
							if($flavourAttribute) {
								$product->attributes['flavour'] = $flavourAttribute;
							}
							if($sizeAttribute) {
								$product->attributes['size'] = $sizeAttribute;
							}
							$product->displayTitle = isset($titleLookup[$productParentSKU]) ? $titleLookup[$productParentSKU] : '' ;
							$all_new_products[$productParentSKU][] = $product;
						}
					} else if($productTypeSKU != false && strlen($productTypeSKU) == 1 && is_numeric($productTypeSKU) && ($productTypeSKU == 3 )) { //COILS
						
						$pieceSKU = substr($productSKU, 8 ,1);
						$resistanceSKU = substr($productSKU, 10 ,3);
						$resistanceAttribute = '';
						$piecesAttribute = '';

						if($pieceSKU == 1){
							$piecesAttribute = '1pcs';
						} else if($pieceSKU == 3){
							$piecesAttribute = '3pcs';
						} else if($pieceSKU == 4){
							$piecesAttribute = '4pcs';
						} else if($pieceSKU == 5){
							$piecesAttribute = '5pcs';
						} else if( in_array($pieceSKU, ['A', 'B', 'C', 'D']) ) {
							// $productParentSKU
							// $resistanceSKU
							// $piecesAttribute = $pieceSKU . ' BOX';
							$piecesAttribute = false;
						} 

						$product->attributes['piece'] = $piecesAttribute;
						
						$product->attributes['resistance'] = $productShort;						

						$all_coil_products[$productParentSKU][] = $product;

					} else if($productTypeSKU != false && strlen($productTypeSKU) == 1 && is_numeric($productTypeSKU) && ($productTypeSKU == 1 )) { //COLOURS
						$product->attributes['colour'] = $productShort;
						$all_new_products[$productParentSKU][] = $product;	
					} else if($productTypeSKU != false && strlen($productTypeSKU) == 1 && is_numeric($productTypeSKU) && ($productTypeSKU == 2 )) { //CONCENTRATES
						$productParentSKU = substr($productSKU, 0, 8);
						$product->attributes['concentrates'] = $productShort;
						$all_new_products[$productParentSKU][] = $product;
					} else if($productTypeSKU != false && strlen($productTypeSKU) == 1 && is_numeric($productTypeSKU) && ($productTypeSKU == 8 )) { //TYPE
						$product->attributes['type'] = $productShort;
						$all_new_products[$productParentSKU][] = $product;
					} else if($productTypeSKU != false && strlen($productTypeSKU) == 1 && is_numeric($productTypeSKU) && ($productTypeSKU == 6 )) { //SIZE
						$product->attributes['size'] = $productShort;
						$all_new_products[$productParentSKU][] = $product;
					} else {
						/*$product->attributes['type'] = $productShort;
						$all_new_products[$productParentSKU][] = $product;*/
					}
					
				} else {
					/*$product->attributes['type'] = $productShort;
					$all_new_products[$productParentSKU][] = $product;*/
				}
			}
			
			if(!empty($all_coil_products)) {

				$all_coil_product_recalculated = $this->recalculate_coil_stock($all_coil_products, $location);

				// $all_new_products = array_merge($all_new_products, $all_coil_product_recalculated);

				foreach($all_coil_product_recalculated as $kkeeyy => $vvvalue){
					$all_new_products[$kkeeyy] = $vvvalue;
				}

			}
			
			
			/* if($location == 1) {
				echo "<pre>";
				print_r($all_coil_products);
				echo "</pre>";
				die;   
			} */
			
			$this->update_product_ids = array();
			$countProduct = 0;
			$countSyncProduct = 0;
			$totalProduct = count($all_new_products);
			$totalVariation = 0;
			foreach ($all_new_products as $type) {
				$totalVariation+= count($type);
			}
			update_option("totalVariation",$totalVariation);
			if(!empty($all_new_products)) {
				$rootBaseDirectory = ABSPATH;
				foreach($all_new_products as $productSlug => $allProducts){
					if($productSlug == 'STANDARD'){
						foreach($allProducts as $product){
							if($countProduct >= $offset && $countProduct < $limit) {
							} else {
								$countProduct++;
								continue;
							}
							$ID = $product->Id;
							$GUID = $product->ProductGuid;
							$SKU = $product->InventoryCode;
							$TITLE = $product->Category->Name;
							$SHORTTITLE = isset($product->displayTitle) ? $product->displayTitle : $product->Description->Short;
							$STANDARDTITLE = $product->Description->Standard;
							$DESC = $product->Description->Notes;
							$CATEGORY = $product->Category->Name;
							$CATEGORY_ID = $product->Category->Id;
							$GROUP = $product->Group->Name;
							$ATTRIBUTES = isset($product->attributes) ? $product->attributes : '';
							$BrandCode = substr($SKU, 9 ,1);
							$sharePointImageUrl = $rootBaseDirectory.'product_images/'.$SKU.'.jpg';
							
							if (!@file_exists($sharePointImageUrl) && !empty($product->Image)) {
								$decoded =  base64_decode($product->Image);
								file_put_contents( $sharePointImageUrl, $decoded );
							}
							
							if(isset($BrandCode) && trim($BrandCode) != "") {
								$BrandName = isset($brandLookUp[$BrandCode]) ? $brandLookUp[$BrandCode] : '';
							}
							if($BrandName != '' && !empty($BrandName)){
								$brandTaxonomy = get_term_by('name', $BrandName, 'brand');
								if(empty($brandTaxonomy)){
									$clean_brand_name = preg_replace('/\s+/', '-', $BrandName);
									$clean_brand_name = strtolower($clean_brand_name);
									$category_args = array('cat_name' => $BrandName, 'category_description' => '', 'category_nicename' => $clean_brand_name, 'category_parent' => '', 'taxonomy'=> 'brand');
									$brand_id = wp_insert_category($category_args);
								}else{
									$brand_id = $brandTaxonomy->term_id;
								}
							}else{
								$brand_id = '';
							}
							
							if($GROUP != 'Not Used' && !empty($GROUP)){
								$category = get_term_by('name', $GROUP, 'product_cat');
								if(empty($category)){
									$clean_grp_name = preg_replace('/\s+/', '-', $GROUP);
									$clean_grp_name = strtolower($clean_grp_name);
									$category_args = array('cat_name' => $GROUP, 'category_description' => '', 'category_nicename' => $clean_grp_name, 'category_parent' => '', 'taxonomy'=> 'product_cat');
									$category_id = wp_insert_category($category_args);
								} else {
									$category_id = $category->term_id;
								}
							}else{
								$category_id = '';
							}
							//update_option('test_data_'.time(), array($GROUP, $CATEGORY));
							/*Adding child category of Eliquid: start */
							if($GROUP == 'Eliquid' && $CATEGORY == 'Dilutents' && !empty($category_id)){
								update_option('test_data_checked_cat'.time(), array($GROUP, $CATEGORY));
								$child_category = get_term_by('name', $CATEGORY, 'product_cat');
								if(empty($child_category)){
									$clean_cat_name = preg_replace('/\s+/', '-', $CATEGORY);
									$clean_cat_name = strtolower($clean_cat_name);
									$ch_category_args = array('cat_name' => $CATEGORY, 'category_description' => '', 'category_nicename' => $clean_cat_name, 'category_parent' => $category_id, 'taxonomy'=> 'product_cat');
									$child_cat_id = wp_insert_category($ch_category_args);
								} else {
									$child_cat_id = $child_category->term_id;
								}

							}else{
								$child_cat_id = '';
							}
							/*Adding child category of Eliquid: end */
							
							$product_details = $product;
							if($product_details != false){
								$inventory = $product_details->StockLevel;
								if($inventory == null){ $inventory = 0; }
								elseif(empty($inventory)){ $inventory = 0; }
								elseif( $inventory < 0 ){ $inventory = 0; }

								$variation_data = array();
								$variationType = array();
								if($SKU != '') {
									if(!empty($ATTRIBUTES)) {
										if(isset($ATTRIBUTES['size'])) {
											$variationType[] = 'size';
											$variation_data['size'] =  array($ATTRIBUTES['size']);
										}
										if(isset($ATTRIBUTES['viscosity'])) {
											$variationType[] = 'viscosity';
											$variation_data['viscosity'] =  array($ATTRIBUTES['viscosity']);
										}
										if(isset($ATTRIBUTES['flavour'])) {
											$TITLE = isset($titleLookup[substr($SKU, 0, 7)]) ? $titleLookup[substr($SKU, 0, 7)].' Range' : $product->Category->Name;
											$variationType[] = 'flavour';
											$variation_data['flavour'] =  array($ATTRIBUTES['flavour']);
										}
										if(isset($ATTRIBUTES['piece'])) {
											$variationType[] = 'piece';
											$variation_data['piece'] =  array($ATTRIBUTES['piece']);
										}
										if(isset($ATTRIBUTES['resistance'])) {
											$variationType[] = 'resistance';
											$variation_data['resistance'] =  array($ATTRIBUTES['resistance']);
										}
										if(isset($ATTRIBUTES['colour'])) {
											$variationType[] = 'colour';
											$variation_data['colour'] =  array($ATTRIBUTES['colour']);
										}
										if(isset($ATTRIBUTES['concentrates'])) {
											$TITLE = isset($titleLookup[substr($SKU, 0, 8)]) ? $titleLookup[substr($SKU, 0, 8)].' Concentrate' : $product->Category->Name;
											$variationType[] = 'concentrates';
											$variation_data['concentrates'] =  array($ATTRIBUTES['concentrates']);
										}
										if(isset($ATTRIBUTES['type'])) {
											$variationType[] = 'type';
											$variation_data['type'] =  array($ATTRIBUTES['type']);
										}
									} else {
										$variationType[] = 'type';
										$variation_data['type'] = $SHORTTITLE;	
									}
								}						
								
								$woo_id = JVA__Functions::get_productid_by_swiftpostid( $ID );
								$img_data = "";					
								if( empty($woo_id) || get_post_status($woo_id) === false ){
									$post = array(
										'post_author' => get_current_user_id(),
										'post_content' => '',
										'post_status' => "publish",
										'post_title' => $TITLE,
										'post_parent' => '',
										'post_excerpt' => $DESC,
										'post_type' => "product",
									);
									$post_id = wp_insert_post( $post, false );
									
									if($post_id){

										$img_data = $product_details->Image;
										update_post_meta($post_id, 'swiftpost_id', $ID);
										update_post_meta($post_id, 'swiftpost_guid', $GUID);
										
										$add_product = JVA__Functions::insert_new_product( $post_id, $ID, $inventory );

										wp_delete_object_term_relationships( $post_id, 'product_cat' );
										if(!empty($category_id) && !empty($group_id)){
											if(!empty($child_cat_id)){
												$cat_ids = array_map( 'intval', array($category_id, $group_id, $child_cat_id) );
												wp_set_object_terms( $post_id, $cat_ids, 'product_cat', true );
											}else{
												$cat_ids = array_map( 'intval', array($category_id, $group_id) );
												wp_set_object_terms( $post_id, $cat_ids, 'product_cat', true );
											}
										}elseif(!empty($category_id) && empty($group_id)){
											if(!empty($child_cat_id)){
												wp_set_object_terms( $post_id, array((int)$category_id, $child_cat_id), 'product_cat', true );
											}else{
												wp_set_object_terms( $post_id, (int)$category_id, 'product_cat', true );
											}
										}elseif(empty($category_id) && !empty($group_id)){
											if(!empty($child_cat_id)){
												wp_set_object_terms( $post_id, array((int)$group_id, $child_cat_id), 'product_cat', true );
											}else{
												wp_set_object_terms( $post_id, (int)$group_id, 'product_cat', true );
											}
										}

										wp_delete_object_term_relationships( $post_id, 'brand' );
										if(!empty($brand_id))  {
											wp_set_object_terms( $post_id, $brand_id, 'brand', true );
										}

										update_post_meta($post_id, 'swiftpost_product', 'true');
										$this->update_product_status($post_id);
										
										$this->updateProductMeta($post_id, $SKU, $inventory, $product_details, $CATEGORY_ID);
										
										$sharePointImageUrl = $rootBaseDirectory.'product_images/'.$SKU.'.jpg';
										$this->setFeaturedImage($sharePointImageUrl, $post_id, $product_details->Image);
										$this->productImageGallery($post_id, $SKU);
										
										$variationData =  array(
											'swiftpost_id'  => $ID,
											'author'        =>  get_current_user_id(),
											'title'         => $TITLE,
											'content'       => $DESC,
											'excerpt'       => '',
											'regular_price' => $product_details->Price,
											'sale_price'    => $product_details->Price,
											'stock'         => $inventory,
											'stock_status'  => $stock_status,
											'sku'           => $SKU,
											'tax_class'     => '',
											'weight'        => '',
											'variation_type'=> $variationType,
											'attributes'    => $variation_data,
											'imgagedata'    => $product_details->Image,
											'standard_title'=> $STANDARDTITLE,
											'reupload_images'=> false
										);
										JVA__Functions::assign_attributes_on_simple_products($variationData, $post_id, $syncWarehouse, false);

										$this->update_product_ids[] = $post_id;
									}
								} else {
									$post_id = $woo_id;
									if($reupload_images == true){
										$img_data = $product_details->Image;
									}
									update_post_meta($post_id, 'swiftpost_product', 'true');
									$this->update_product_status($post_id);
									// $update_product = JVA__Functions::update_product_inventory( $ID, $woo_id, $inventory );
									// $update_product = JVA__Functions::update_product_inventory_but_not_in_post( $ID, $woo_id, $inventory );
									if($post_id){
										if(!empty($post_id)){
											wp_delete_object_term_relationships( $post_id, 'product_cat' );

											if(!empty($category_id) && !empty($group_id)){
												if(!empty($child_cat_id)){
													$cat_ids = array_map( 'intval', array($category_id, $group_id, $child_cat_id) );
													wp_set_object_terms($post_id, $cat_ids, 'product_cat', true );
												}else{
													$cat_ids = array_map( 'intval', array($category_id, $group_id) );
													wp_set_object_terms($post_id, $cat_ids, 'product_cat', true );
												}
												
											}elseif(!empty($category_id) && empty($group_id)){
												if(!empty($child_cat_id)){
													wp_set_object_terms( $post_id, array((int)$category_id, $child_cat_id), 'product_cat', true );
												}else{
													wp_set_object_terms( $post_id, (int)$category_id, 'product_cat', true );
												}
												
											}elseif(empty($category_id) && !empty($group_id)){
												if(!empty($child_cat_id)){
													wp_set_object_terms($post_id, array((int)$group_id, $child_cat_id), 'product_cat', true );
												}else{
													wp_set_object_terms( $post_id, (int)$group_id, 'product_cat', true );
												}

											}
										}
										// $this->updateProductMeta($post_id, $SKU, $inventory, $product_details, $CATEGORY_ID);
										$this->updateProductMetaWithoutInventory($post_id, $SKU, $inventory, $product_details, $CATEGORY_ID);
										
										$sharePointImageUrl = $rootBaseDirectory.'product_images/'.$SKU.'.jpg';
										$this->setFeaturedImage($sharePointImageUrl, $post_id, $product_details->Image);
										
										$this->productImageGallery($post_id, $SKU);
										
										$variationData =  array(
											'swiftpost_id'  => $ID,
											'author'        =>  get_current_user_id(),
											'title'         => $TITLE,
											'content'       => $DESC,
											'excerpt'       => '',
											'regular_price' => $product_details->Price,
											'sale_price'    => $product_details->Price,
											'stock'         => $inventory,
											'stock_status'  => $stock_status,
											'sku'           => $SKU,
											'tax_class'     => '',
											'weight'        => '',
											'variation_type'=> $variationType,
											'attributes'    => $variation_data,
											'imgagedata'    => $product_details->Image,
											'standard_title'=> $STANDARDTITLE,
											'reupload_images'=> $reupload_images
										);
										// JVA__Functions::assign_attributes_on_simple_products($variationData, $post_id, $syncWarehouse);
										JVA__Functions::assign_attributes_on_simple_products_on_update($variationData, $post_id, $syncWarehouse);
										$this->update_product_ids[] = $post_id;
									}
								}
								$countProduct++;
								$i++;
							}else{
								$failed .= '<span reason="' . $this->errors['response']->Messages[0] . '">'.$ID."</span>, ";
								$n++;
							}
						}
					}else{
						if(count($allProducts) > 1) {
							foreach($allProducts as $product){
								if($countProduct >= $offset && $countProduct < $limit) {
								} else {
									$countProduct++;
									continue;
								}
								$ID = $product->Id;
								$GUID = $product->ProductGuid;
								$SKU = $product->InventoryCode;
								$TITLE = $product->Category->Name;
								$SHORTTITLE = isset($product->displayTitle) ? $product->displayTitle : $product->Description->Short;
								$STANDARDTITLE = $product->Description->Standard;
								$DESC = $product->Description->Notes;
								$CATEGORY = $product->Category->Name;
								$CATEGORY_ID = $product->Category->Id;
								$GROUP = $product->Group->Name;
								$ATTRIBUTES = isset($product->attributes) ? $product->attributes : '';
								$BrandCode = substr($SKU, 9 ,1);
								$sharePointImageUrl = $rootBaseDirectory.'product_images/'.$SKU.'.jpg';
								
								if (!@file_exists($sharePointImageUrl) && !empty($product->Image)) {
									$decoded =  base64_decode($product->Image);
									file_put_contents( $sharePointImageUrl, $decoded );
								}
								
								if(isset($BrandCode) && trim($BrandCode) != "") {
									$BrandName = isset($brandLookUp[$BrandCode]) ? $brandLookUp[$BrandCode] : '';
								}
								if($BrandName != '' && !empty($BrandName)){
									$brandTaxonomy = get_term_by('name', $BrandName, 'brand');
									if(empty($brandTaxonomy)){
										$clean_brand_name = preg_replace('/\s+/', '-', $BrandName);
										$clean_brand_name = strtolower($clean_brand_name);
										$category_args = array('cat_name' => $BrandName, 'category_description' => '', 'category_nicename' => $clean_brand_name, 'category_parent' => '', 'taxonomy'=> 'brand');
										$brand_id = wp_insert_category($category_args);
									}else{
										$brand_id = $brandTaxonomy->term_id;
									}
								}else{
									$brand_id = '';
								}
								
								if($GROUP != 'Not Used' && !empty($GROUP)){
									$category = get_term_by('name', $GROUP, 'product_cat');
									if(empty($category)){
										$clean_grp_name = preg_replace('/\s+/', '-', $GROUP);
										$clean_grp_name = strtolower($clean_grp_name);
										$category_args = array('cat_name' => $GROUP, 'category_description' => '', 'category_nicename' => $clean_grp_name, 'category_parent' => '', 'taxonomy'=> 'product_cat');
										$category_id = wp_insert_category($category_args);
									} else {
										$category_id = $category->term_id;
									}
								}else{
									$category_id = '';
								}
								//update_option('test_data_'.time(), array($GROUP, $CATEGORY));
								/*Adding child category of Eliquid: start */
								if($GROUP == 'Eliquid' && $CATEGORY == 'Dilutents' && !empty($category_id)){
									update_option('test_data_checked_cat'.time(), array($GROUP, $CATEGORY));
									$child_category = get_term_by('name', $CATEGORY, 'product_cat');
									if(empty($child_category)){
										$clean_cat_name = preg_replace('/\s+/', '-', $CATEGORY);
										$clean_cat_name = strtolower($clean_cat_name);
										$ch_category_args = array('cat_name' => $CATEGORY, 'category_description' => '', 'category_nicename' => $clean_cat_name, 'category_parent' => $category_id, 'taxonomy'=> 'product_cat');
										$child_cat_id = wp_insert_category($ch_category_args);
									} else {
										$child_cat_id = $child_category->term_id;
									}

								}else{
									$child_cat_id = '';
								}
								/*Adding child category of Eliquid: end */
								
								$product_details = $product;
								if($product_details != false){
									$inventory = $product_details->StockLevel;
									if($inventory == null) { $inventory = 0; }
									elseif(empty($inventory)){ $inventory = 0; }
									elseif( $inventory < 0 ){ $inventory = 0; }

									$variation_data = array();
									$variationType = array();
									if($SKU != '') {
										if(!empty($ATTRIBUTES)) {
											$productParentSKU = substr($SKU, 0, 7);
											
											if(isset($ATTRIBUTES['size'])) {
												$variationType[] = 'size';
												$variation_data['size'] =  array($ATTRIBUTES['size']);
											}
											if(isset($ATTRIBUTES['viscosity'])) {
												$variationType[] = 'viscosity';
												$variation_data['viscosity'] =  array($ATTRIBUTES['viscosity']);
											}
											if(isset($ATTRIBUTES['flavour'])) {
												$TITLE = isset($titleLookup[substr($SKU, 0, 7)]) ? $titleLookup[substr($SKU, 0, 7)].' Range' : $product->Category->Name;
												$variationType[] = 'flavour';
												$variation_data['flavour'] =  array($ATTRIBUTES['flavour']);
											}
											if(isset($ATTRIBUTES['piece'])) {
												$variationType[] = 'piece';
												$variation_data['piece'] =  array($ATTRIBUTES['piece']);
											}
											if(isset($ATTRIBUTES['resistance'])) {
												$variationType[] = 'resistance';
												$variation_data['resistance'] =  array($ATTRIBUTES['resistance']);
											}
											if(isset($ATTRIBUTES['colour'])) {
												$variationType[] = 'colour';
												$variation_data['colour'] =  array($ATTRIBUTES['colour']);
											}
											if(isset($ATTRIBUTES['concentrates'])) {
												$productParentSKU = substr($SKU, 0, 8);
												$TITLE = isset($titleLookup[substr($SKU, 0, 8)]) ? $titleLookup[substr($SKU, 0, 8)].' Concentrate' : $product->Category->Name;
												$variationType[] = 'concentrates';
												$variation_data['concentrates'] =  array($ATTRIBUTES['concentrates']);
											}
											if(isset($ATTRIBUTES['type'])) {
												$variationType[] = 'type';
												$variation_data['type'] =  array($ATTRIBUTES['type']);
											}
										} else {
											$productParentSKU = substr($SKU, 0, 7);
											$variationType[] = 'type';
											$variation_data['type'] = $SHORTTITLE;	
										}
									}						
									
									$woo_id = JVA__Functions::get_productid_by_swiftpostid( $ID );
									$img_data = "";					
									if( empty($woo_id) || get_post_status($woo_id) === false ){
									//if(empty($woo_id)){
										$variableProductWooId = JVA__Functions::get_productid_by_productparentsku( $productParentSKU, $SKU, $TITLE );
										
										if($variableProductWooId != false) {
											update_post_meta($variableProductWooId, 'swiftpost_product', 'true');
											$this->update_product_status($variableProductWooId);

											wp_delete_object_term_relationships( $variableProductWooId, 'product_cat' );
											if(!empty($category_id) && !empty($group_id)){
												if(!empty($child_cat_id)){
													$cat_ids = array_map( 'intval', array($category_id, $group_id, $child_cat_id) );
													wp_set_object_terms( $variableProductWooId, $cat_ids, 'product_cat', true );
												}else{
													$cat_ids = array_map( 'intval', array($category_id, $group_id) );
													wp_set_object_terms( $variableProductWooId, $cat_ids, 'product_cat', true );
												}
												
											}elseif(!empty($category_id) && empty($group_id)){
												if(!empty($child_cat_id)){
													wp_set_object_terms( $variableProductWooId, array((int)$category_id, $child_cat_id), 'product_cat', true );
												}else{
													wp_set_object_terms( $variableProductWooId, (int)$category_id, 'product_cat', true );
												}
												
											}elseif(empty($category_id) && !empty($group_id)){
												if(!empty($child_cat_id)){
													wp_set_object_terms( $variableProductWooId, array((int)$group_id, $child_cat_id), 'product_cat', true );
												}else{
													wp_set_object_terms( $variableProductWooId, (int)$group_id, 'product_cat', true );
												}

											}
											
											$stock_status = $inventory > 0 ? 'instock' : 'outofstock';
											$variationData =  array(
												'swiftpost_id'  => $ID,
												'author'        =>  get_current_user_id(),
												'title'         => $TITLE,
												'content'       => $DESC,
												'excerpt'       => '',
												'regular_price' => $product_details->Price,
												'sale_price'    => $product_details->Price,
												'stock'         => $inventory,
												'stock_status'  => $stock_status,
												'sku'           => $SKU,
												'tax_class'     => '',
												'weight'        => '',
												'variation_type'=> $variationType,
												'attributes'    => $variation_data,
												'imgagedata'    => $product_details->Image,
												'standard_title'=> $STANDARDTITLE,
												'_parent_sku' => $productParentSKU,
												'reupload_images'=> $reupload_images
											);										
											// JVA__Functions::create_product_variation($variationData, $variableProductWooId, $syncWarehouse);
											JVA__Functions::create_product_variation_on_update($variationData, $variableProductWooId, $syncWarehouse);
											$this->update_product_ids[] = $variableProductWooId;
											
											wp_delete_object_term_relationships( $variableProductWooId, 'brand' );
											if(!empty($brand_id))  {
												wp_set_object_terms( $variableProductWooId, $brand_id, 'brand', true );
											}
										} else {
											$post = array(
												'post_author' => get_current_user_id(),
												'post_content' => '',
												'post_status' => "publish",
												'post_title' => $TITLE,
												'post_parent' => '',
												'post_excerpt' => $DESC,
												'post_type' => "product",
											);
											$post_id = wp_insert_post( $post, false );
											
											$img_data = $product_details->Image;
											update_post_meta($post_id, 'swiftpost_id', $ID);
											update_post_meta($post_id, 'swiftpost_guid', $GUID);
											
											$add_product = JVA__Functions::insert_new_product( $post_id, $ID, $inventory );

											wp_delete_object_term_relationships( $post_id, 'product_cat' );
											if(!empty($category_id) && !empty($group_id)){
												if(!empty($child_cat_id)){
													$cat_ids = array_map( 'intval', array($category_id, $group_id, $child_cat_id) );
													wp_set_object_terms( $post_id, $cat_ids, 'product_cat', true );
												}else{
													$cat_ids = array_map( 'intval', array($category_id, $group_id) );
													wp_set_object_terms( $post_id, $cat_ids, 'product_cat', true );
												}
												
											}elseif(!empty($category_id) && empty($group_id)){
												if(!empty($child_cat_id)){
													wp_set_object_terms( $post_id, array((int)$category_id, $child_cat_id), 'product_cat', true );
												}else{
													wp_set_object_terms( $post_id, (int)$category_id, 'product_cat', true );
												}
												
											}elseif(empty($category_id) && !empty($group_id)){
												if(!empty($child_cat_id)){
													wp_set_object_terms( $post_id, array((int)$group_id, $child_cat_id), 'product_cat', true );
												}else{
													wp_set_object_terms( $post_id, (int)$group_id, 'product_cat', true );
												}

											}

											wp_delete_object_term_relationships( $post_id, 'brand' );
											if(!empty($brand_id))  {
												wp_set_object_terms( $post_id, $brand_id, 'brand', true );
											}

											if($post_id){
												update_post_meta($post_id, 'swiftpost_product', 'true');
												$this->update_product_status($post_id);
												
												$this->updateProductMeta($post_id, $productParentSKU, $inventory, $product_details, $CATEGORY_ID);
												update_post_meta( $post_id, '_parent_sku', $productParentSKU);
												
												$sharePointImageUrl = $rootBaseDirectory.'product_images/'.$productParentSKU.'.jpg';
												$this->setFeaturedImage($sharePointImageUrl, $post_id, $product_details->Image);
												$this->productImageGallery($post_id, $productParentSKU);
												
												$variationData =  array(
													'swiftpost_id'  => $ID,
													'author'        =>  get_current_user_id(),
													'title'         => $TITLE,
													'content'       => $DESC,
													'excerpt'       => '',
													'regular_price' => $product_details->Price,
													'sale_price'    => $product_details->Price,
													'stock'         => $inventory,
													'stock_status'  => $stock_status,
													'sku'           => $SKU,
													'tax_class'     => '',
													'weight'        => '',
													'variation_type'=> $variationType,
													'attributes'    => $variation_data,
													'imgagedata'    => $product_details->Image,
													'standard_title'=> $STANDARDTITLE,
													'_parent_sku' => $productParentSKU,
													'reupload_images'=> false
												);
												JVA__Functions::create_product_variation($variationData, $post_id, $syncWarehouse);
												$this->update_product_ids[] = $post_id;
											}
										}
									} else {
										$post_id = $woo_id;
										if($reupload_images == true){
											$img_data = $product_details->Image;
										}
										update_post_meta($post_id, 'swiftpost_product', 'true');
										$this->update_product_status($post_id);
										// $update_product = JVA__Functions::update_product_inventory( $ID, $woo_id, $inventory );
										// $update_product = JVA__Functions::update_product_inventory_but_not_in_post( $ID, $woo_id, $inventory );
										if($post_id){
											$variableProductWooId = JVA__Functions::get_productid_by_productparentsku( $productParentSKU, $SKU, $TITLE);
											if(!empty($variableProductWooId)){
												wp_delete_object_term_relationships( $variableProductWooId, 'product_cat' );

												if(!empty($category_id) && !empty($group_id)){
													if(!empty($child_cat_id)){
														$cat_ids = array_map( 'intval', array($category_id, $group_id, $child_cat_id) );
														wp_set_object_terms( $variableProductWooId, $cat_ids, 'product_cat', true );
													}else{
														$cat_ids = array_map( 'intval', array($category_id, $group_id) );
														wp_set_object_terms( $variableProductWooId, $cat_ids, 'product_cat', true );
													}
													
												}elseif(!empty($category_id) && empty($group_id)){
													if(!empty($child_cat_id)){
														wp_set_object_terms( $variableProductWooId, array((int)$category_id, $child_cat_id), 'product_cat', true );
													}else{
														wp_set_object_terms( $variableProductWooId, (int)$category_id, 'product_cat', true );
													}
													
												}elseif(empty($category_id) && !empty($group_id)){
													if(!empty($child_cat_id)){
														wp_set_object_terms( $variableProductWooId, array((int)$group_id, $child_cat_id), 'product_cat', true );
													}else{
														wp_set_object_terms( $variableProductWooId, (int)$group_id, 'product_cat', true );
													}

												}
											}
											// $this->updateProductMeta($post_id, $productParentSKU, $inventory, $product_details, $CATEGORY_ID);
											$this->updateProductMetaWithoutInventory($post_id, $productParentSKU, $inventory, $product_details, $CATEGORY_ID);
											update_post_meta( $post_id, '_parent_sku', $productParentSKU);
											
											$sharePointImageUrl = $rootBaseDirectory.'product_images/'.$productParentSKU.'.jpg';
											$this->setFeaturedImage($sharePointImageUrl, $post_id, $product_details->Image);
											
											$this->productImageGallery($post_id, $productParentSKU);
											
											$variationData =  array(
												'swiftpost_id'  => $ID,
												'author'        =>  get_current_user_id(),
												'title'         => $TITLE,
												'content'       => $DESC,
												'excerpt'       => '',
												'regular_price' => $product_details->Price,
												'sale_price'    => $product_details->Price,
												'stock'         => $inventory,
												'stock_status'  => $stock_status,
												'sku'           => $SKU,
												'tax_class'     => '',
												'weight'        => '',
												'variation_type'=> $variationType,
												'attributes'    => $variation_data,
												'imgagedata'    => $product_details->Image,
												'standard_title'=> $STANDARDTITLE,
												'_parent_sku'   => $productParentSKU,
												'reupload_images'=> $reupload_images
											);

											// JVA__Functions::create_product_variation($variationData, $post_id, $syncWarehouse);
											JVA__Functions::create_product_variation_on_update($variationData, $post_id, $syncWarehouse);
											$this->update_product_ids[] = $post_id;
										}
									}
									$countProduct++;
									$i++;
								}else{
									$failed .= '<span reason="' . $this->errors['response']->Messages[0] . '">'.$ID."</span>, ";
									$n++;
								}
								/* if($i > 10){
									break;
								}  */
							}
							
						} else {
							foreach($allProducts as $product){
								if($countProduct >= $offset && $countProduct < $limit) {
								} else {
									$countProduct++;
									continue;
								}
								$ID = $product->Id;
								$GUID = $product->ProductGuid;
								$SKU = $product->InventoryCode;
								$productParentSKU = substr($SKU, 0, 7);
								$TITLE = $product->Description->Standard;
								$ParentTITLE = $product->Category->Name;
								$DESC = $product->Description->Notes;
								$CATEGORY = $product->Category->Name;
								$CATEGORY_ID = $product->Category->Id;
								$GROUP = $product->Group->Name;
								$ATTRIBUTES = isset($product->attributes) ? $product->attributes : '';
								$BrandCode = substr($SKU, 9 ,1);
								$sharePointImageUrl = $rootBaseDirectory.'product_images/'.$SKU.'.jpg';

								if (!@file_exists($sharePointImageUrl) && !empty($product->Image)) {
									$decoded =  base64_decode($product->Image);
									file_put_contents( $sharePointImageUrl, $decoded );
								}
								if(isset($BrandCode) && trim($BrandCode) != "") {
									$BrandName = isset($brandLookUp[$BrandCode]) ? $brandLookUp[$BrandCode] : '';
								}
								if($BrandName != '' && !empty($BrandName)){
									$brandTaxonomy = get_term_by('name', $BrandName, 'brand');
									if(empty($brandTaxonomy)){
										$clean_brand_name = preg_replace('/\s+/', '-', $BrandName);
										$clean_brand_name = strtolower($clean_brand_name);
										$category_args = array('cat_name' => $BrandName, 'category_description' => '', 'category_nicename' => $clean_brand_name, 'category_parent' => '', 'taxonomy'=> 'brand');
										$brand_id = wp_insert_category($category_args);
									}else{
										$brand_id = $brandTaxonomy->term_id;
									}
								}else{
									$brand_id = '';
								}
								
								if($GROUP != 'Not Used' && !empty($GROUP)){
									$category = get_term_by('name', $GROUP, 'product_cat');
									if(empty($category)){
										$clean_grp_name = preg_replace('/\s+/', '-', $GROUP);
										$clean_grp_name = strtolower($clean_grp_name);
										$category_args = array('cat_name' => $GROUP, 'category_description' => '', 'category_nicename' => $clean_grp_name, 'category_parent' => '', 'taxonomy'=> 'product_cat');
										$category_id = wp_insert_category($category_args);
									}else{
										$category_id = $category->term_id;
									}
								}else{
									$category_id = '';
								}
								//update_option('test_data_'.time(), array($GROUP, $CATEGORY));
								/*Adding child category of Eliquid: start */
								if($GROUP == 'Eliquid' && $CATEGORY == 'Dilutents' && !empty($category_id)){
									update_option('test_data_checked_cat'.time(), array($GROUP, $CATEGORY));
									$child_category = get_term_by('name', $CATEGORY, 'product_cat');
									if(empty($child_category)){
										$clean_cat_name = preg_replace('/\s+/', '-', $CATEGORY);
										$clean_cat_name = strtolower($clean_cat_name);
										$ch_category_args = array('cat_name' => $CATEGORY, 'category_description' => '', 'category_nicename' => $clean_cat_name, 'category_parent' => $category_id, 'taxonomy'=> 'product_cat');
										$child_cat_id = wp_insert_category($ch_category_args);
									} else {
										$child_cat_id = $child_category->term_id;
									}

								}else{
									$child_cat_id = '';
								}
								/*Adding child category of Eliquid: end */

								$product_details = $product;

								if($product_details != false){
									$variation_data = array();
									$variationType = array();
									if($SKU != '') {
										if(!empty($ATTRIBUTES)) {
											if(isset($ATTRIBUTES['size'])) {
												$variationType[] = 'size';
												$variation_data['size'] =  array($ATTRIBUTES['size']);
											}
											if(isset($ATTRIBUTES['viscosity'])) {
												$variationType[] = 'viscosity';
												$variation_data['viscosity'] =  array($ATTRIBUTES['viscosity']);
											}
											if(isset($ATTRIBUTES['flavour'])) {
												$TITLE = isset($titleLookup[substr($SKU, 0, 7)]) ? $titleLookup[substr($SKU, 0, 7)].' Range' : $product->Category->Name;
												$variationType[] = 'flavour';
												$variation_data['flavour'] =  array($ATTRIBUTES['flavour']);
											}
											if(isset($ATTRIBUTES['piece'])) {
												$variationType[] = 'piece';
												$variation_data['piece'] =  array($ATTRIBUTES['piece']);
											}
											if(isset($ATTRIBUTES['resistance'])) {
												$variationType[] = 'resistance';
												$variation_data['resistance'] =  array($ATTRIBUTES['resistance']);
											}
											if(isset($ATTRIBUTES['colour'])) {
												$variationType[] = 'colour';
												$variation_data['colour'] =  array($ATTRIBUTES['colour']);
											}
											if(isset($ATTRIBUTES['concentrates'])) {
												$productParentSKU = substr($SKU, 0, 8);
												$TITLE = isset($titleLookup[substr($SKU, 0, 8)]) ? $titleLookup[substr($SKU, 0, 8)].' Concentrate' : $product->Category->Name;
												$variationType[] = 'concentrates';
												$variation_data['concentrates'] =  array($ATTRIBUTES['concentrates']);
											}
											if(isset($ATTRIBUTES['type'])) {
												$variationType[] = 'type';
												$variation_data['type'] =  array($ATTRIBUTES['type']);
											}
										}
									}

									$inventory = $product_details->StockLevel;
									if($inventory == null) { $inventory = 0; }
									elseif(empty($inventory)){ $inventory = 0; }
									elseif( $inventory < 0 ){ $inventory = 0; }
									
									$woo_id = JVA__Functions::get_productid_by_swiftpostid( $ID );
									$img_data = "";
									if( empty($woo_id) || get_post_status($woo_id) === false ){
										$variableProductWooId = JVA__Functions::get_productid_by_productparentsku( $productParentSKU, $SKU, $ParentTITLE );
										if($variableProductWooId != false ) {
											wp_delete_object_term_relationships( $variableProductWooId, 'product_cat' );

											if(!empty($category_id) && !empty($group_id)){
												if(!empty($child_cat_id)){
													$cat_ids = array_map( 'intval', array($category_id, $group_id, $child_cat_id) );
													wp_set_object_terms( $variableProductWooId, $cat_ids, 'product_cat', true );
												}else{
													$cat_ids = array_map( 'intval', array($category_id, $group_id) );
													wp_set_object_terms( $variableProductWooId, $cat_ids, 'product_cat', true );
												}
												
											}elseif(!empty($category_id) && empty($group_id)){
												if(!empty($child_cat_id)){
													wp_set_object_terms( $variableProductWooId, array((int)$category_id, $child_cat_id), 'product_cat', true );
												}else{
													wp_set_object_terms( $variableProductWooId, (int)$category_id, 'product_cat', true );
												}
												
											}elseif(empty($category_id) && !empty($group_id)){
												if(!empty($child_cat_id)){
													wp_set_object_terms( $variableProductWooId, array((int)$group_id, $child_cat_id), 'product_cat', true );
												}else{
													wp_set_object_terms( $variableProductWooId, (int)$group_id, 'product_cat', true );
												}

											}
											

											update_post_meta($variableProductWooId, 'swiftpost_product', 'true');
											$this->update_product_status($variableProductWooId);
											
											$stock_status = $inventory > 0 ? 'instock' : 'outofstock';
											$variationData =  array(
												'swiftpost_id'  => $ID,
												'author'        =>  get_current_user_id(),
												'title'         => $TITLE,
												'content'       => $DESC,
												'excerpt'       => '',
												'regular_price' => $product_details->Price,
												'sale_price'    => $product_details->Price,
												'stock'         => $inventory,
												'stock_status'  => $stock_status,
												'sku'           => $SKU,
												'tax_class'     => '',
												'weight'        => '',
												'variation_type'=> $variationType,
												'attributes'    => $variation_data,
												'imgagedata'    => $product_details->Image,
												'standard_title'=> $STANDARDTITLE,
												'_parent_sku' => $productParentSKU,
												'reupload_images'=> $reupload_images
											);										
											// JVA__Functions::create_product_variation($variationData, $variableProductWooId, $syncWarehouse);
											JVA__Functions::create_product_variation_on_update($variationData, $variableProductWooId, $syncWarehouse);
											$this->update_product_ids[] = $variableProductWooId;
											wp_delete_object_term_relationships( $variableProductWooId, 'brand' );
											if(!empty($brand_id))  {
												wp_set_object_terms( $variableProductWooId, $brand_id, 'brand', true );
											}
										} else if(!empty($variation_data)){
											$post = array(
												'post_author' => get_current_user_id(),
												'post_content' => '',
												'post_status' => "publish",
												'post_title' => $TITLE,
												'post_parent' => '',
												'post_excerpt' => $DESC,
												'post_type' => "product",
											);
											$post_id = wp_insert_post( $post, false );
											
											$img_data = $product_details->Image;
											update_post_meta($post_id, 'swiftpost_id', $ID);
											update_post_meta($post_id, 'swiftpost_guid', $GUID);
											
											$add_product = JVA__Functions::insert_new_product( $post_id, $ID, $inventory );
											wp_delete_object_term_relationships( $post_id, 'product_cat' );

											if(!empty($category_id) && !empty($group_id)){
												if(!empty($child_cat_id)){
													$cat_ids = array_map( 'intval', array($category_id, $group_id, $child_cat_id) );
													wp_set_object_terms( $post_id, $cat_ids, 'product_cat', true );
												}else{
													$cat_ids = array_map( 'intval', array($category_id, $group_id) );
													wp_set_object_terms( $post_id, $cat_ids, 'product_cat', true );
												}
												
											}elseif(!empty($category_id) && empty($group_id)){
												if(!empty($child_cat_id)){
													wp_set_object_terms( $post_id, array((int)$category_id, $child_cat_id), 'product_cat', true );
												}else{
													wp_set_object_terms( $post_id, (int)$category_id, 'product_cat', true );
												}
												
											}elseif(empty($category_id) && !empty($group_id)){
												if(!empty($child_cat_id)){
													wp_set_object_terms( $post_id, array((int)$group_id, $child_cat_id), 'product_cat', true );
												}else{
													wp_set_object_terms( $post_id, (int)$group_id, 'product_cat', true );
												}
												
											}
											wp_delete_object_term_relationships( $post_id, 'brand' );

											if(!empty($brand_id))  {
												wp_set_object_terms( $post_id, $brand_id, 'brand', true );
											}
											if($post_id){
												update_post_meta($post_id, 'swiftpost_product', 'true');
												$this->update_product_status($post_id);
												
												$this->updateProductMeta($post_id, $productParentSKU, $inventory, $product_details, $CATEGORY_ID);
												update_post_meta( $post_id, '_parent_sku', $productParentSKU);
												
												$sharePointImageUrl = $rootBaseDirectory.'product_images/'.$productParentSKU.'.jpg';
												$this->setFeaturedImage($sharePointImageUrl, $post_id, $product_details->Image);
												$this->productImageGallery($post_id, $productParentSKU);
												
												$variationData =  array(
													'swiftpost_id'  => $ID,
													'author'        =>  get_current_user_id(),
													'title'         => $TITLE,
													'content'       => $DESC,
													'excerpt'       => '',
													'regular_price' => $product_details->Price,
													'sale_price'    => $product_details->Price,
													'stock'         => $inventory,
													'stock_status'  => $stock_status,
													'sku'           => $SKU,
													'tax_class'     => '',
													'weight'        => '',
													'variation_type'=> $variationType,
													'attributes'    => $variation_data,
													'imgagedata'    => $product_details->Image,
													'standard_title'=> $STANDARDTITLE,
													'_parent_sku' => $productParentSKU,
													'reupload_images'=> $reupload_images
												);
												JVA__Functions::create_product_variation($variationData, $post_id, $syncWarehouse);
												$this->update_product_ids[] = $post_id;
											}
										} else  {
											$post = array(
												'post_author' => get_current_user_id(),
												'post_content' => '',
												'post_status' => "publish",
												'post_title' => $TITLE,
												'post_parent' => '',
												'post_excerpt' => $DESC,
												'post_type' => "product",
											);
											$post_id = wp_insert_post( $post, false );

											$this->update_product_ids[] = $post_id;

											update_post_meta($post_id, 'swiftpost_product', 'true');
											update_post_meta($post_id, 'swiftpost_id', $ID);
											update_post_meta($post_id, 'swiftpost_guid', $GUID);
											
											$img_data = $product_details->Image;
											$add_product = JVA__Functions::insert_new_product( $post_id, $ID, $inventory );

											wp_delete_object_term_relationships( $post_id, 'product_cat' );

											if(!empty($category_id) && !empty($group_id)){
												if(!empty($child_cat_id)){
													$cat_ids = array_map( 'intval', array($category_id, $group_id, $child_cat_id) );
													wp_set_object_terms( $post_id, $cat_ids, 'product_cat', true );
												}else{
													$cat_ids = array_map( 'intval', array($category_id, $group_id) );
													wp_set_object_terms( $post_id, $cat_ids, 'product_cat', true );
												}
												
											}elseif(!empty($category_id) && empty($group_id)){
												if(!empty($child_cat_id)){
													wp_set_object_terms( $post_id, array((int)$category_id, $child_cat_id), 'product_cat', true );
												}else{
													wp_set_object_terms( $post_id, (int)$category_id, 'product_cat', true );
												}
												
											}elseif(empty($category_id) && !empty($group_id)){
												if(!empty($child_cat_id)){
													wp_set_object_terms( $post_id, arra((int)$group_id, $child_cat_id), 'product_cat', true );
												}else{
													wp_set_object_terms( $post_id, (int)$group_id, 'product_cat', true );
												}
												
											}
										}
									}else{
										$post_id = $woo_id;

										$variableProductWooId = JVA__Functions::get_productid_by_productparentsku( $productParentSKU, $SKU, $TITLE);
										if(!empty($variableProductWooId)){

											$this->update_product_ids[] = $variableProductWooId;

											wp_delete_object_term_relationships( $variableProductWooId, 'product_cat' );

											if(!empty($category_id) && !empty($group_id)){
												if(!empty($child_cat_id)){
													$cat_ids = array_map( 'intval', array($category_id, $group_id, $child_cat_id) );
													wp_set_object_terms( $variableProductWooId, $cat_ids, 'product_cat', true );
												}else{
													$cat_ids = array_map( 'intval', array($category_id, $group_id) );
													wp_set_object_terms( $variableProductWooId, $cat_ids, 'product_cat', true );
												}
												
											}elseif(!empty($category_id) && empty($group_id)){
												if(!empty($child_cat_id)){
													wp_set_object_terms( $variableProductWooId, array((int)$category_id, $child_cat_id), 'product_cat', true );
												}else{
													wp_set_object_terms( $variableProductWooId, (int)$category_id, 'product_cat', true );
												}
												
											}elseif(empty($category_id) && !empty($group_id)){
												if(!empty($child_cat_id)){
													wp_set_object_terms( $variableProductWooId, array((int)$group_id, $child_cat_id), 'product_cat', true );
												}else{
													wp_set_object_terms( $variableProductWooId, (int)$group_id, 'product_cat', true );
												}

											}
										}
											
										if($reupload_images == true){
											$img_data = $product_details->Image;
										}

										// COMMENT BY ADIL BECAUSE INVENTORY ISSUE ON UPDATE
										// $update_product = JVA__Functions::update_product_inventory( $ID, $woo_id, $inventory );
									}
									
									if($post_id && empty($variationData)){
										update_post_meta($post_id, 'swiftpost_product', 'true');
										$this->update_product_status($post_id);
										wp_delete_object_term_relationships( $post_id, 'brand' );
										if(!empty($brand_id))  {
											wp_set_object_terms( $post_id, $brand_id, 'brand', true );
										}
										
										// COMMENT BY ADIL BECAUSE INVENTORY ISSUE ON UPDATE
										// $this->updateProductMeta($post_id, $SKU, $inventory, $product_details, $CATEGORY_ID);
										$this->updateProductMetaWithoutInventory($post_id, $SKU, $inventory, $product_details, $CATEGORY_ID);
										
										update_post_meta($post_id, '_price_per_inventory', 'global');
										update_post_meta($post_id, '_expirable_inventories', 'global');
										update_post_meta($post_id, '_inventory_iteration', 'global');
										update_post_meta($post_id, '_selling_priority', 'global');
										update_post_meta($post_id, '_multi_inventory', 'global');
										update_post_meta($post_id, '_backorders', 'no');
										
										$this->setFeaturedImage($sharePointImageUrl, $post_id, $product_details->Image);	
										$this->productImageGallery($post_id, $SKU);

										$this->update_product_ids[] = $post_id;
										
										// Inventory Sync in Autum
										// COMMENT BY ADIL BECAUSE INVENTORY ISSUE ON UPDATE
										// $JVA__Functions->autumInventorySync($post_id, $supplierId, $supplierName, $inventory, $stock_status, false);
									}
									$i++;
									$countProduct++;
								}else{
									$failed .= '<span reason="' . $this->errors['response']->Messages[0] . '">'.$ID."</span>, ";
									$n++;
								}
							}
							/* if($i > 10){
								break;
							} */
						}
					}
					
					$countSyncProduct++;
				}
				$variationSync = get_option("variationSync", true);
				$newVariationSync = $variationSync + $i;
				update_option("variationSync",$newVariationSync);

				$this->total = ''.$totalProduct;
				$this->variation = ''.$newVariationSync;
				$this->totalVariation = ''.$totalVariation;
				$this->msg .= ''.$newVariationSync.' product (s) synced successfully, and '.$n.' failed.<br>';
				if($n > 0 ){
					$this->msg .= '<br>Product(s) with the following SwiftPOS IDs were not synced: <b>'.trim($failed, ', ').'</b>.';
				}
				$this->status = true;
				$totalVariation = get_option("totalVariation", true);
				if($newVariationSync >= $totalVariation ){
					update_option("variationSync",'');
					update_option($syncWarehouse."_variationSync",$syncWarehouse);
				}
			} else {
				$this->status = false;
				$this->msg = 'Inventory synchronization could not be completed.';
			}		
		} else {
			$this->status = false;
			$this->msg = 'Inventory synchronization could not be completed.';
		}
		if($offset == 0){
			$this->write_SwiftPost_log("Inventory synchronization Logs : ".date("Y-m-d H:is"));
		}
		$this->write_SwiftPost_log($this);
		//added by websupreme
        $this->heal_product_sku($all_products);
		return $this;
	}

	public function sync_products2($reupload_images = false, $force_sync, $offset, $limit, $syncWarehouse){
		$syncWarehouse = 'JAA';
		$JVA__Functions = new JVA__Functions();
		switch ( $syncWarehouse ){
			case 'JVA' :
				$location = $JVA__Functions->get_swiftpos_creds('locationId');
				$all_products = get_option("swiftPostApi_data");
			break;
			case 'Melbourne':
				$location = $JVA__Functions->get_swiftpos_creds_melbourne('locationId');
				$all_products = get_option("swiftPostApi_melbourne_data");
			break;
			case 'JAA':
				$location = $JVA__Functions->get_swiftpos_creds_just_automiser('locationId');
				$all_products = get_option("swiftPostApi_jaa_data");
			break;
		}
		
		$supplierData = $JVA__Functions->getSupplier($location);
		if(!empty($supplierData)) {
			$supplierId = $supplierData->ID;
			$supplierName = $supplierData->post_title;
		}
		
		if(empty($all_products)) {
			$this->errors = array('key'=> "", 'data'=> "", 'function'=> "Product", 'response'=> "");
		}
		
		if($all_products != false){
			$i = 0;
			$n = 0;
			$failed = "";
			$all_new_products = array();
			$all_coil_products = array();
			$titleLookup = JVA__Functions::productTitleLookUp();
			$brandLookUp = JVA__Functions::brandLookUp();
			$juiceFlavourLookUp = JVA__Functions::juiceFlavourLookUp();

			foreach($all_products as $product) {

				$product->Image = '';

				$productSKU = $product->InventoryCode;
				
				// if( ! in_array($productSKU, array( '966466744V8', '888851444T1', '266253444M3', '266253444M2', '266253444M1' )) ){
				// if( ! in_array($productSKU, array( '778875765A1' )) ){
				if( ! in_array($productSKU, array( '966466744V8' )) ){
					continue;
				}

				$productShort = $product->Description->Short;
				$groupId = $product->Group->Id;
				$categoryId = $product->Category->Id;
				$productParentSKU = substr($productSKU, 0, 7);

				// if($productParentSKU != '1010840'){
				// 	continue;
				// }

				$productTypeSKU = substr($productSKU, 7 ,1);
				if($productTypeSKU == 4){
					$all_new_products['STANDARD'][] = $product;
				}elseif(is_numeric(substr($productSKU, 0, 7))) {
					if($productTypeSKU != false && strlen($productTypeSKU) == 1 && is_numeric($productTypeSKU) && ($productTypeSKU == 7 || $productTypeSKU == 5)) { //JUICE
						$sizeSKU = substr($productSKU, 8 ,1);
						$flavourSKU = substr($productSKU, 10 ,3);
						if(($flavourSKU != "") && (strlen($flavourSKU) > 1) && in_array($sizeSKU, array(1,3,5,7) )) {
							$viscosityAttribute = '';
							$sizeAttribute = '';
							$flavourAttribute = '';
							if($productTypeSKU == 5) {
								$viscosityAttribute = '50-50';
							} else if($productTypeSKU == 7) { 
								$viscosityAttribute = '70-30';
							} 
							if($sizeSKU == 1){
								$sizeAttribute = '100 ml';
							} else if($sizeSKU == 7){
								$sizeAttribute = '75 ml';
							} else if($sizeSKU == 5){
								$sizeAttribute = '50 ml';
							} else if($sizeSKU == 3){
								$sizeAttribute = '30 ml';
							}
							if(($flavourSKU != "")) {
								if($categoryId == 94) {
									$flavour = $juiceFlavourLookUp["standard"][$flavourSKU];
									$flavourAttribute = !empty($flavour) ? $flavour : $productShort;
								} else if($categoryId == 93) {
									$flavour = $juiceFlavourLookUp["tjuice"][$flavourSKU];
									$flavourAttribute = !empty($flavour) ? $flavour : $productShort;
								} else if($categoryId == 92) {
									$flavour = $juiceFlavourLookUp["dragon"][$flavourSKU];
									$flavourAttribute = !empty($flavour) ? $flavour : $productShort;
								} else if($categoryId == 340) {
									$flavour = $juiceFlavourLookUp["greengold"][$flavourSKU];
									$flavourAttribute = !empty($flavour) ? $flavour : $productShort;
								} else {
									$flavourAttribute = $productShort;
								}
							}
							if($viscosityAttribute) {
								$product->attributes['viscosity'] = $viscosityAttribute;
							}
							if($flavourAttribute) {
								$product->attributes['flavour'] = $flavourAttribute;
							}
							if($sizeAttribute) {
								$product->attributes['size'] = $sizeAttribute;
							}
							$product->displayTitle = isset($titleLookup[$productParentSKU]) ? $titleLookup[$productParentSKU] : '' ;
							$all_new_products[$productParentSKU][] = $product;
						}
					} else if($productTypeSKU != false && strlen($productTypeSKU) == 1 && is_numeric($productTypeSKU) && ($productTypeSKU == 3 )) { //COILS
						
						$pieceSKU = substr($productSKU, 8 ,1);
						$resistanceSKU = substr($productSKU, 10 ,3);
						$resistanceAttribute = '';
						$piecesAttribute = '';

						if($pieceSKU == 1){
							$piecesAttribute = '1pcs';
						} else if($pieceSKU == 3){
							$piecesAttribute = '3pcs';
						} else if($pieceSKU == 4){
							$piecesAttribute = '4pcs';
						} else if($pieceSKU == 5){
							$piecesAttribute = '5pcs';
						} else if( in_array($pieceSKU, ['A', 'B', 'C', 'D']) ) {
							// $productParentSKU
							// $resistanceSKU
							// $piecesAttribute = $pieceSKU . ' BOX';
							$piecesAttribute = false;
						} 

						$product->attributes['piece'] = $piecesAttribute;
						
						$product->attributes['resistance'] = $productShort;						

						$all_coil_products[$productParentSKU][] = $product;

					} else if($productTypeSKU != false && strlen($productTypeSKU) == 1 && is_numeric($productTypeSKU) && ($productTypeSKU == 1 )) { //COLOURS
						$product->attributes['colour'] = $productShort;
						$all_new_products[$productParentSKU][] = $product;	
					} else if($productTypeSKU != false && strlen($productTypeSKU) == 1 && is_numeric($productTypeSKU) && ($productTypeSKU == 2 )) { //CONCENTRATES
						$productParentSKU = substr($productSKU, 0, 8);
						$product->attributes['concentrates'] = $productShort;
						$all_new_products[$productParentSKU][] = $product;
					} else if($productTypeSKU != false && strlen($productTypeSKU) == 1 && is_numeric($productTypeSKU) && ($productTypeSKU == 8 )) { //TYPE
						$product->attributes['type'] = $productShort;
						$all_new_products[$productParentSKU][] = $product;
					} else if($productTypeSKU != false && strlen($productTypeSKU) == 1 && is_numeric($productTypeSKU) && ($productTypeSKU == 6 )) { //SIZE
						$product->attributes['size'] = $productShort;
						$all_new_products[$productParentSKU][] = $product;
					} else {
						/*$product->attributes['type'] = $productShort;
						$all_new_products[$productParentSKU][] = $product;*/
					}
					
				} else {
					/*$product->attributes['type'] = $productShort;
					$all_new_products[$productParentSKU][] = $product;*/
				}
			}
			
			if(!empty($all_coil_products)) {

				$all_coil_product_recalculated = $this->recalculate_coil_stock($all_coil_products, $location);

				// $all_new_products = array_merge($all_new_products, $all_coil_product_recalculated);

				foreach($all_coil_product_recalculated as $kkeeyy => $vvvalue){
					$all_new_products[$kkeeyy] = $vvvalue;
				}

			}
			
			// echo "<pre>";
			// print_r($all_new_products);
			// die();
			
			/* if($location == 1) {
				echo "<pre>";
				print_r($all_coil_products);
				echo "</pre>";
				die;   
			} */
			
			$this->update_product_ids = array();
			$countProduct = 0;
			$countSyncProduct = 0;
			$totalProduct = count($all_new_products);
			$totalVariation = 0;
			foreach ($all_new_products as $type) {
				$totalVariation+= count($type);
			}
			update_option("totalVariation",$totalVariation);
			if(!empty($all_new_products)) {

				echo '<br>!empty($all_new_products)<br>'; 


				$rootBaseDirectory = ABSPATH;
				foreach($all_new_products as $productSlug => $allProducts){
					if($productSlug == 'STANDARD'){
						echo 'if($productSlug == \'STANDARD\'){'; 

						foreach($allProducts as $product){
							// if($countProduct >= $offset && $countProduct < $limit) {
							// } else {
							// 	$countProduct++;
							// 	continue;
							// }
							$ID = $product->Id;
							$GUID = $product->ProductGuid;
							$SKU = $product->InventoryCode;
							$TITLE = $product->Category->Name;
							$SHORTTITLE = isset($product->displayTitle) ? $product->displayTitle : $product->Description->Short;
							$STANDARDTITLE = $product->Description->Standard;
							$DESC = $product->Description->Notes;
							$CATEGORY = $product->Category->Name;
							$CATEGORY_ID = $product->Category->Id;
							$GROUP = $product->Group->Name;
							$ATTRIBUTES = isset($product->attributes) ? $product->attributes : '';
							$BrandCode = substr($SKU, 9 ,1);
							$sharePointImageUrl = $rootBaseDirectory.'product_images/'.$SKU.'.jpg';
							
							if (!@file_exists($sharePointImageUrl) && !empty($product->Image)) {
								$decoded =  base64_decode($product->Image);
								file_put_contents( $sharePointImageUrl, $decoded );
							}
							
							if(isset($BrandCode) && trim($BrandCode) != "") {
								$BrandName = isset($brandLookUp[$BrandCode]) ? $brandLookUp[$BrandCode] : '';
							}
							if($BrandName != '' && !empty($BrandName)){
								$brandTaxonomy = get_term_by('name', $BrandName, 'brand');
								if(empty($brandTaxonomy)){
									$clean_brand_name = preg_replace('/\s+/', '-', $BrandName);
									$clean_brand_name = strtolower($clean_brand_name);
									$category_args = array('cat_name' => $BrandName, 'category_description' => '', 'category_nicename' => $clean_brand_name, 'category_parent' => '', 'taxonomy'=> 'brand');
									$brand_id = wp_insert_category($category_args);
								}else{
									$brand_id = $brandTaxonomy->term_id;
								}
							}else{
								$brand_id = '';
							}
							
							if($GROUP != 'Not Used' && !empty($GROUP)){
								$category = get_term_by('name', $GROUP, 'product_cat');
								if(empty($category)){
									$clean_grp_name = preg_replace('/\s+/', '-', $GROUP);
									$clean_grp_name = strtolower($clean_grp_name);
									$category_args = array('cat_name' => $GROUP, 'category_description' => '', 'category_nicename' => $clean_grp_name, 'category_parent' => '', 'taxonomy'=> 'product_cat');
									$category_id = wp_insert_category($category_args);
								} else {
									$category_id = $category->term_id;
								}
							}else{
								$category_id = '';
							}
							//update_option('test_data_'.time(), array($GROUP, $CATEGORY));
							/*Adding child category of Eliquid: start */
							if($GROUP == 'Eliquid' && $CATEGORY == 'Dilutents' && !empty($category_id)){
								update_option('test_data_checked_cat'.time(), array($GROUP, $CATEGORY));
								$child_category = get_term_by('name', $CATEGORY, 'product_cat');
								if(empty($child_category)){
									$clean_cat_name = preg_replace('/\s+/', '-', $CATEGORY);
									$clean_cat_name = strtolower($clean_cat_name);
									$ch_category_args = array('cat_name' => $CATEGORY, 'category_description' => '', 'category_nicename' => $clean_cat_name, 'category_parent' => $category_id, 'taxonomy'=> 'product_cat');
									$child_cat_id = wp_insert_category($ch_category_args);
								} else {
									$child_cat_id = $child_category->term_id;
								}

							}else{
								$child_cat_id = '';
							}
							/*Adding child category of Eliquid: end */
							
							$product_details = $product;
							if($product_details != false){
								$inventory = $product_details->StockLevel;
								if($inventory == null) { $inventory = 0; }
								elseif(empty($inventory)){ $inventory = 0; }
								elseif( $inventory < 0 ){ $inventory = 0; }
								
								echo "<pre>";
								print_r($product_details);
								echo $inventory; 

								$variation_data = array();
								$variationType = array();
								if($SKU != '') {
									if(!empty($ATTRIBUTES)) {
										if(isset($ATTRIBUTES['size'])) {
											$variationType[] = 'size';
											$variation_data['size'] =  array($ATTRIBUTES['size']);
										}
										if(isset($ATTRIBUTES['viscosity'])) {
											$variationType[] = 'viscosity';
											$variation_data['viscosity'] =  array($ATTRIBUTES['viscosity']);
										}
										if(isset($ATTRIBUTES['flavour'])) {
											$TITLE = isset($titleLookup[substr($SKU, 0, 7)]) ? $titleLookup[substr($SKU, 0, 7)].' Range' : $product->Category->Name;
											$variationType[] = 'flavour';
											$variation_data['flavour'] =  array($ATTRIBUTES['flavour']);
										}
										if(isset($ATTRIBUTES['piece'])) {
											$variationType[] = 'piece';
											$variation_data['piece'] =  array($ATTRIBUTES['piece']);
										}
										if(isset($ATTRIBUTES['resistance'])) {
											$variationType[] = 'resistance';
											$variation_data['resistance'] =  array($ATTRIBUTES['resistance']);
										}
										if(isset($ATTRIBUTES['colour'])) {
											$variationType[] = 'colour';
											$variation_data['colour'] =  array($ATTRIBUTES['colour']);
										}
										if(isset($ATTRIBUTES['concentrates'])) {
											$TITLE = isset($titleLookup[substr($SKU, 0, 8)]) ? $titleLookup[substr($SKU, 0, 8)].' Concentrate' : $product->Category->Name;
											$variationType[] = 'concentrates';
											$variation_data['concentrates'] =  array($ATTRIBUTES['concentrates']);
										}
										if(isset($ATTRIBUTES['type'])) {
											$variationType[] = 'type';
											$variation_data['type'] =  array($ATTRIBUTES['type']);
										}
									} else {
										$variationType[] = 'type';
										$variation_data['type'] = $SHORTTITLE;	
									}
								}




								// echo "<pre>";						
								// print_r($variation_data);
								// die();
								
								$woo_id = JVA__Functions::get_productid_by_swiftpostid( $ID );
								$img_data = "";					
								if( empty($woo_id) || get_post_status($woo_id) === false ){

									// echo 'WOO -> '.$woo_id; die();


									$post = array(
										'post_author' => get_current_user_id(),
										'post_content' => '',
										'post_status' => "publish",
										'post_title' => $TITLE,
										'post_parent' => '',
										'post_excerpt' => $DESC,
										'post_type' => "product",
									);
									$post_id = wp_insert_post( $post, false );
									
									if($post_id){

										$img_data = $product_details->Image;
										update_post_meta($post_id, 'swiftpost_id', $ID);
										update_post_meta($post_id, 'swiftpost_guid', $GUID);
										
										$add_product = JVA__Functions::insert_new_product( $post_id, $ID, $inventory );

										wp_delete_object_term_relationships( $post_id, 'product_cat' );
										if(!empty($category_id) && !empty($group_id)){
											if(!empty($child_cat_id)){
												$cat_ids = array_map( 'intval', array($category_id, $group_id, $child_cat_id) );
												wp_set_object_terms( $post_id, $cat_ids, 'product_cat', true );
											}else{
												$cat_ids = array_map( 'intval', array($category_id, $group_id) );
												wp_set_object_terms( $post_id, $cat_ids, 'product_cat', true );
											}
										}elseif(!empty($category_id) && empty($group_id)){
											if(!empty($child_cat_id)){
												wp_set_object_terms( $post_id, array((int)$category_id, $child_cat_id), 'product_cat', true );
											}else{
												wp_set_object_terms( $post_id, (int)$category_id, 'product_cat', true );
											}
										}elseif(empty($category_id) && !empty($group_id)){
											if(!empty($child_cat_id)){
												wp_set_object_terms( $post_id, array((int)$group_id, $child_cat_id), 'product_cat', true );
											}else{
												wp_set_object_terms( $post_id, (int)$group_id, 'product_cat', true );
											}
										}

										wp_delete_object_term_relationships( $post_id, 'brand' );
										if(!empty($brand_id))  {
											wp_set_object_terms( $post_id, $brand_id, 'brand', true );
										}

										update_post_meta($post_id, 'swiftpost_product', 'true');
										$this->update_product_status($post_id);
										
										$this->updateProductMeta($post_id, $SKU, $inventory, $product_details, $CATEGORY_ID);
										
										$sharePointImageUrl = $rootBaseDirectory.'product_images/'.$SKU.'.jpg';
										$this->setFeaturedImage($sharePointImageUrl, $post_id, $product_details->Image);
										$this->productImageGallery($post_id, $SKU);
										


										

										$variationData =  array(
											'swiftpost_id'  => $ID,
											'author'        =>  get_current_user_id(),
											'title'         => $TITLE,
											'content'       => $DESC,
											'excerpt'       => '',
											'regular_price' => $product_details->Price,
											'sale_price'    => $product_details->Price,
											'stock'         => $inventory,
											'stock_status'  => $stock_status,
											'sku'           => $SKU,
											'tax_class'     => '',
											'weight'        => '',
											'variation_type'=> $variationType,
											'attributes'    => $variation_data,
											'imgagedata'    => $product_details->Image,
											'standard_title'=> $STANDARDTITLE,
											'reupload_images'=> false
										);
										JVA__Functions::assign_attributes_on_simple_products($variationData, $post_id, $syncWarehouse, false);


										// echo "DONE";
										// die();

									}
								} else {

									echo '<br>-----> '.var_dump($variationType).'<br>';

									echo 'NOO -> '.$woo_id; 

									$post_id = $woo_id;
									if($reupload_images == true){
										$img_data = $product_details->Image;
									}
									update_post_meta($post_id, 'swiftpost_product', 'true');
									$this->update_product_status($post_id);
									// $update_product = JVA__Functions::update_product_inventory( $ID, $woo_id, $inventory );
									// $update_product = JVA__Functions::update_product_inventory_but_not_in_post( $ID, $woo_id, $inventory );
									if($post_id){
										if(!empty($post_id)){

											$this->update_product_ids[] = $post_id;

											wp_delete_object_term_relationships( $post_id, 'product_cat' );

											if(!empty($category_id) && !empty($group_id)){
												if(!empty($child_cat_id)){
													$cat_ids = array_map( 'intval', array($category_id, $group_id, $child_cat_id) );
													wp_set_object_terms($post_id, $cat_ids, 'product_cat', true );
												}else{
													$cat_ids = array_map( 'intval', array($category_id, $group_id) );
													wp_set_object_terms($post_id, $cat_ids, 'product_cat', true );
												}
												
											}elseif(!empty($category_id) && empty($group_id)){
												if(!empty($child_cat_id)){
													wp_set_object_terms( $post_id, array((int)$category_id, $child_cat_id), 'product_cat', true );
												}else{
													wp_set_object_terms( $post_id, (int)$category_id, 'product_cat', true );
												}
												
											}elseif(empty($category_id) && !empty($group_id)){
												if(!empty($child_cat_id)){
													wp_set_object_terms($post_id, array((int)$group_id, $child_cat_id), 'product_cat', true );
												}else{
													wp_set_object_terms( $post_id, (int)$group_id, 'product_cat', true );
												}

											}
										}
										// $this->updateProductMeta($post_id, $SKU, $inventory, $product_details, $CATEGORY_ID);
										$this->updateProductMetaWithoutInventory($post_id, $SKU, $inventory, $product_details, $CATEGORY_ID);
										
										$sharePointImageUrl = $rootBaseDirectory.'product_images/'.$SKU.'.jpg';
										$this->setFeaturedImage($sharePointImageUrl, $post_id, $product_details->Image);
										
										$this->productImageGallery($post_id, $SKU);
										
										$variationData =  array(
											'swiftpost_id'  => $ID,
											'author'        =>  get_current_user_id(),
											'title'         => $TITLE,
											'content'       => $DESC,
											'excerpt'       => '',
											'regular_price' => $product_details->Price,
											'sale_price'    => $product_details->Price,
											'stock'         => $inventory,
											'stock_status'  => $stock_status,
											'sku'           => $SKU,
											'tax_class'     => '',
											'weight'        => '',
											'variation_type'=> $variationType,
											'attributes'    => $variation_data,
											'imgagedata'    => $product_details->Image,
											'standard_title'=> $STANDARDTITLE,
											'reupload_images'=> $reupload_images
										);
										// JVA__Functions::assign_attributes_on_simple_products($variationData, $post_id, $syncWarehouse);
										JVA__Functions::assign_attributes_on_simple_products_on_update($variationData, $post_id, $syncWarehouse);
									}

									// echo "DONE111111111111111111111111";
									// die();

								}
								$countProduct++;
								$i++;
							}else{
								$failed .= '<span reason="' . $this->errors['response']->Messages[0] . '">'.$ID."</span>, ";
								$n++;
							}
						}
					}else{
						echo '<br>else -> if($productSlug == \'STANDARD\'){<br>'; die();

						if(count($allProducts) > 1) {
							echo '<br>if(count($allProducts) > 1) {<br>';

							foreach($allProducts as $product){
								$ID = $product->Id;
								$GUID = $product->ProductGuid;
								$SKU = $product->InventoryCode;
								$TITLE = $product->Category->Name;
								$SHORTTITLE = isset($product->displayTitle) ? $product->displayTitle : $product->Description->Short;
								$STANDARDTITLE = $product->Description->Standard;
								$DESC = $product->Description->Notes;
								$CATEGORY = $product->Category->Name;
								$CATEGORY_ID = $product->Category->Id;
								$GROUP = $product->Group->Name;
								$ATTRIBUTES = isset($product->attributes) ? $product->attributes : '';
								$BrandCode = substr($SKU, 9 ,1);
								$sharePointImageUrl = $rootBaseDirectory.'product_images/'.$SKU.'.jpg';
								
								if (!@file_exists($sharePointImageUrl) && !empty($product->Image)) {
									$decoded =  base64_decode($product->Image);
									file_put_contents( $sharePointImageUrl, $decoded );
								}
								
								if(isset($BrandCode) && trim($BrandCode) != "") {
									$BrandName = isset($brandLookUp[$BrandCode]) ? $brandLookUp[$BrandCode] : '';
								}
								if($BrandName != '' && !empty($BrandName)){
									$brandTaxonomy = get_term_by('name', $BrandName, 'brand');
									if(empty($brandTaxonomy)){
										$clean_brand_name = preg_replace('/\s+/', '-', $BrandName);
										$clean_brand_name = strtolower($clean_brand_name);
										$category_args = array('cat_name' => $BrandName, 'category_description' => '', 'category_nicename' => $clean_brand_name, 'category_parent' => '', 'taxonomy'=> 'brand');
										$brand_id = wp_insert_category($category_args);
									}else{
										$brand_id = $brandTaxonomy->term_id;
									}
								}else{
									$brand_id = '';
								}
								
								if($GROUP != 'Not Used' && !empty($GROUP)){
									$category = get_term_by('name', $GROUP, 'product_cat');
									if(empty($category)){
										$clean_grp_name = preg_replace('/\s+/', '-', $GROUP);
										$clean_grp_name = strtolower($clean_grp_name);
										$category_args = array('cat_name' => $GROUP, 'category_description' => '', 'category_nicename' => $clean_grp_name, 'category_parent' => '', 'taxonomy'=> 'product_cat');
										$category_id = wp_insert_category($category_args);
									} else {
										$category_id = $category->term_id;
									}
								}else{
									$category_id = '';
								}
								//update_option('test_data_'.time(), array($GROUP, $CATEGORY));
								/*Adding child category of Eliquid: start */
								if($GROUP == 'Eliquid' && $CATEGORY == 'Dilutents' && !empty($category_id)){
									update_option('test_data_checked_cat'.time(), array($GROUP, $CATEGORY));
									$child_category = get_term_by('name', $CATEGORY, 'product_cat');
									if(empty($child_category)){
										$clean_cat_name = preg_replace('/\s+/', '-', $CATEGORY);
										$clean_cat_name = strtolower($clean_cat_name);
										$ch_category_args = array('cat_name' => $CATEGORY, 'category_description' => '', 'category_nicename' => $clean_cat_name, 'category_parent' => $category_id, 'taxonomy'=> 'product_cat');
										$child_cat_id = wp_insert_category($ch_category_args);
									} else {
										$child_cat_id = $child_category->term_id;
									}

								}else{
									$child_cat_id = '';
								}
								/*Adding child category of Eliquid: end */
								
								$product_details = $product;
								if($product_details != false){
									echo '<br>if($product_details != false){ <br>'; die();

									$inventory = $product_details->StockLevel;
									if($inventory == null) { $inventory = 0; }
									elseif(empty($inventory)){ $inventory = 0; }
									elseif( $inventory < 0 ){ $inventory = 0; }

									$variation_data = array();
									$variationType = array();
									if($SKU != '') {
										if(!empty($ATTRIBUTES)) {
											$productParentSKU = substr($SKU, 0, 7);
											
											if(isset($ATTRIBUTES['size'])) {
												$variationType[] = 'size';
												$variation_data['size'] =  array($ATTRIBUTES['size']);
											}
											if(isset($ATTRIBUTES['viscosity'])) {
												$variationType[] = 'viscosity';
												$variation_data['viscosity'] =  array($ATTRIBUTES['viscosity']);
											}
											if(isset($ATTRIBUTES['flavour'])) {
												$TITLE = isset($titleLookup[substr($SKU, 0, 7)]) ? $titleLookup[substr($SKU, 0, 7)].' Range' : $product->Category->Name;
												$variationType[] = 'flavour';
												$variation_data['flavour'] =  array($ATTRIBUTES['flavour']);
											}
											if(isset($ATTRIBUTES['piece'])) {
												$variationType[] = 'piece';
												$variation_data['piece'] =  array($ATTRIBUTES['piece']);
											}
											if(isset($ATTRIBUTES['resistance'])) {
												$variationType[] = 'resistance';
												$variation_data['resistance'] =  array($ATTRIBUTES['resistance']);
											}
											if(isset($ATTRIBUTES['colour'])) {
												$variationType[] = 'colour';
												$variation_data['colour'] =  array($ATTRIBUTES['colour']);
											}
											if(isset($ATTRIBUTES['concentrates'])) {
												$productParentSKU = substr($SKU, 0, 8);
												$TITLE = isset($titleLookup[substr($SKU, 0, 8)]) ? $titleLookup[substr($SKU, 0, 8)].' Concentrate' : $product->Category->Name;
												$variationType[] = 'concentrates';
												$variation_data['concentrates'] =  array($ATTRIBUTES['concentrates']);
											}
											if(isset($ATTRIBUTES['type'])) {
												$variationType[] = 'type';
												$variation_data['type'] =  array($ATTRIBUTES['type']);
											}
										} else {
											$productParentSKU = substr($SKU, 0, 7);
											$variationType[] = 'type';
											$variation_data['type'] = $SHORTTITLE;	
										}
									}						
									
									$woo_id = JVA__Functions::get_productid_by_swiftpostid( $ID );
									
									// var_dump($woo_id); die();

									$img_data = "";					
									if( empty($woo_id) || get_post_status($woo_id) === false ){
									//if(empty($woo_id)){
										$variableProductWooId = JVA__Functions::get_productid_by_productparentsku( $productParentSKU, $SKU, $TITLE );
										
										// $variableProductWooId = false;

										var_dump($variableProductWooId); die();

										if($variableProductWooId != false) {
											update_post_meta($variableProductWooId, 'swiftpost_product', 'true');
											$this->update_product_status($variableProductWooId);

											wp_delete_object_term_relationships( $variableProductWooId, 'product_cat' );
											if(!empty($category_id) && !empty($group_id)){
												if(!empty($child_cat_id)){
													$cat_ids = array_map( 'intval', array($category_id, $group_id, $child_cat_id) );
													wp_set_object_terms( $variableProductWooId, $cat_ids, 'product_cat', true );
												}else{
													$cat_ids = array_map( 'intval', array($category_id, $group_id) );
													wp_set_object_terms( $variableProductWooId, $cat_ids, 'product_cat', true );
												}
												
											}elseif(!empty($category_id) && empty($group_id)){
												if(!empty($child_cat_id)){
													wp_set_object_terms( $variableProductWooId, array((int)$category_id, $child_cat_id), 'product_cat', true );
												}else{
													wp_set_object_terms( $variableProductWooId, (int)$category_id, 'product_cat', true );
												}
												
											}elseif(empty($category_id) && !empty($group_id)){
												if(!empty($child_cat_id)){
													wp_set_object_terms( $variableProductWooId, array((int)$group_id, $child_cat_id), 'product_cat', true );
												}else{
													wp_set_object_terms( $variableProductWooId, (int)$group_id, 'product_cat', true );
												}

											}
											
											$stock_status = $inventory > 0 ? 'instock' : 'outofstock';
											$variationData =  array(
												'swiftpost_id'  => $ID,
												'author'        =>  get_current_user_id(),
												'title'         => $TITLE,
												'content'       => $DESC,
												'excerpt'       => '',
												'regular_price' => $product_details->Price,
												'sale_price'    => $product_details->Price,
												'stock'         => $inventory,
												'stock_status'  => $stock_status,
												'sku'           => $SKU,
												'tax_class'     => '',
												'weight'        => '',
												'variation_type'=> $variationType,
												'attributes'    => $variation_data,
												'imgagedata'    => $product_details->Image,
												'standard_title'=> $STANDARDTITLE,
												'_parent_sku' => $productParentSKU,
												'reupload_images'=> $reupload_images
											);										
											JVA__Functions::create_product_variation($variationData, $variableProductWooId, $syncWarehouse);
											
											wp_delete_object_term_relationships( $variableProductWooId, 'brand' );
											if(!empty($brand_id))  {
												wp_set_object_terms( $variableProductWooId, $brand_id, 'brand', true );
											}
										} else {
											$post = array(
												'post_author' => get_current_user_id(),
												'post_content' => '',
												'post_status' => "publish",
												'post_title' => $TITLE,
												'post_parent' => '',
												'post_excerpt' => $DESC,
												'post_type' => "product",
											);
											$post_id = wp_insert_post( $post, false );
											
											$img_data = $product_details->Image;
											update_post_meta($post_id, 'swiftpost_id', $ID);
											update_post_meta($post_id, 'swiftpost_guid', $GUID);
											
											$add_product = JVA__Functions::insert_new_product( $post_id, $ID, $inventory );

											wp_delete_object_term_relationships( $post_id, 'product_cat' );
											if(!empty($category_id) && !empty($group_id)){
												if(!empty($child_cat_id)){
													$cat_ids = array_map( 'intval', array($category_id, $group_id, $child_cat_id) );
													wp_set_object_terms( $post_id, $cat_ids, 'product_cat', true );
												}else{
													$cat_ids = array_map( 'intval', array($category_id, $group_id) );
													wp_set_object_terms( $post_id, $cat_ids, 'product_cat', true );
												}
												
											}elseif(!empty($category_id) && empty($group_id)){
												if(!empty($child_cat_id)){
													wp_set_object_terms( $post_id, array((int)$category_id, $child_cat_id), 'product_cat', true );
												}else{
													wp_set_object_terms( $post_id, (int)$category_id, 'product_cat', true );
												}
												
											}elseif(empty($category_id) && !empty($group_id)){
												if(!empty($child_cat_id)){
													wp_set_object_terms( $post_id, array((int)$group_id, $child_cat_id), 'product_cat', true );
												}else{
													wp_set_object_terms( $post_id, (int)$group_id, 'product_cat', true );
												}

											}

											wp_delete_object_term_relationships( $post_id, 'brand' );
											if(!empty($brand_id))  {
												wp_set_object_terms( $post_id, $brand_id, 'brand', true );
											}

											if($post_id){
												update_post_meta($post_id, 'swiftpost_product', 'true');
												$this->update_product_status($post_id);
												
												$this->updateProductMeta($post_id, $productParentSKU, $inventory, $product_details, $CATEGORY_ID);
												update_post_meta( $post_id, '_parent_sku', $productParentSKU);
												
												$sharePointImageUrl = $rootBaseDirectory.'product_images/'.$productParentSKU.'.jpg';
												$this->setFeaturedImage($sharePointImageUrl, $post_id, $product_details->Image);
												$this->productImageGallery($post_id, $productParentSKU);
												
												$variationData =  array(
													'swiftpost_id'  => $ID,
													'author'        =>  get_current_user_id(),
													'title'         => $TITLE,
													'content'       => $DESC,
													'excerpt'       => '',
													'regular_price' => $product_details->Price,
													'sale_price'    => $product_details->Price,
													'stock'         => $inventory,
													'stock_status'  => $stock_status,
													'sku'           => $SKU,
													'tax_class'     => '',
													'weight'        => '',
													'variation_type'=> $variationType,
													'attributes'    => $variation_data,
													'imgagedata'    => $product_details->Image,
													'standard_title'=> $STANDARDTITLE,
													'_parent_sku' => $productParentSKU,
													'reupload_images'=> false
												);
												JVA__Functions::create_product_variation($variationData, $post_id, $syncWarehouse);
											}
										}
									} else {
										$post_id = $woo_id;
										if($reupload_images == true){
											$img_data = $product_details->Image;
										}
										update_post_meta($post_id, 'swiftpost_product', 'true');
										$this->update_product_status($post_id);
										$update_product = JVA__Functions::update_product_inventory( $ID, $woo_id, $inventory );
										if($post_id){
											$this->update_product_ids[] = $post_id;
											$variableProductWooId = JVA__Functions::get_productid_by_productparentsku( $productParentSKU, $SKU, $TITLE);
											if(!empty($variableProductWooId)){
												wp_delete_object_term_relationships( $variableProductWooId, 'product_cat' );

												if(!empty($category_id) && !empty($group_id)){
													if(!empty($child_cat_id)){
														$cat_ids = array_map( 'intval', array($category_id, $group_id, $child_cat_id) );
														wp_set_object_terms( $variableProductWooId, $cat_ids, 'product_cat', true );
													}else{
														$cat_ids = array_map( 'intval', array($category_id, $group_id) );
														wp_set_object_terms( $variableProductWooId, $cat_ids, 'product_cat', true );
													}
													
												}elseif(!empty($category_id) && empty($group_id)){
													if(!empty($child_cat_id)){
														wp_set_object_terms( $variableProductWooId, array((int)$category_id, $child_cat_id), 'product_cat', true );
													}else{
														wp_set_object_terms( $variableProductWooId, (int)$category_id, 'product_cat', true );
													}
													
												}elseif(empty($category_id) && !empty($group_id)){
													if(!empty($child_cat_id)){
														wp_set_object_terms( $variableProductWooId, array((int)$group_id, $child_cat_id), 'product_cat', true );
													}else{
														wp_set_object_terms( $variableProductWooId, (int)$group_id, 'product_cat', true );
													}

												}
											}
											$this->updateProductMeta($post_id, $productParentSKU, $inventory, $product_details, $CATEGORY_ID);
											update_post_meta( $post_id, '_parent_sku', $productParentSKU);
											
											$sharePointImageUrl = $rootBaseDirectory.'product_images/'.$productParentSKU.'.jpg';
											$this->setFeaturedImage($sharePointImageUrl, $post_id, $product_details->Image);
											
											$this->productImageGallery($post_id, $productParentSKU);
											
											$variationData =  array(
												'swiftpost_id'  => $ID,
												'author'        =>  get_current_user_id(),
												'title'         => $TITLE,
												'content'       => $DESC,
												'excerpt'       => '',
												'regular_price' => $product_details->Price,
												'sale_price'    => $product_details->Price,
												'stock'         => $inventory,
												'stock_status'  => $stock_status,
												'sku'           => $SKU,
												'tax_class'     => '',
												'weight'        => '',
												'variation_type'=> $variationType,
												'attributes'    => $variation_data,
												'imgagedata'    => $product_details->Image,
												'standard_title'=> $STANDARDTITLE,
												'_parent_sku'   => $productParentSKU,
												'reupload_images'=> $reupload_images
											);
											JVA__Functions::create_product_variation($variationData, $post_id, $syncWarehouse);
										}
									}
									$countProduct++;
									$i++;
								}else{
									echo '<br>else -> if($product_details != false){ <br>'; die();

									$failed .= '<span reason="' . $this->errors['response']->Messages[0] . '">'.$ID."</span>, ";
									$n++;
								}
								/* if($i > 10){
									break;
								}  */
							}
							
						} else {
							echo '<br>else -> if(count($allProducts) > 1) {<br>'; die();

							foreach($allProducts as $product){
								// if($countProduct >= $offset && $countProduct < $limit) {
								// } else {
								// 	$countProduct++;
								// 	continue;
								// }
								$ID = $product->Id;
								$GUID = $product->ProductGuid;
								$SKU = $product->InventoryCode;
								$productParentSKU = substr($SKU, 0, 7);
								$TITLE = $product->Description->Standard;
								$ParentTITLE = $product->Category->Name;
								$DESC = $product->Description->Notes;
								$CATEGORY = $product->Category->Name;
								$CATEGORY_ID = $product->Category->Id;
								$GROUP = $product->Group->Name;
								$ATTRIBUTES = isset($product->attributes) ? $product->attributes : '';
								$BrandCode = substr($SKU, 9 ,1);
								$sharePointImageUrl = $rootBaseDirectory.'product_images/'.$SKU.'.jpg';

								if (!@file_exists($sharePointImageUrl) && !empty($product->Image)) {
									$decoded =  base64_decode($product->Image);
									file_put_contents( $sharePointImageUrl, $decoded );
								}
								if(isset($BrandCode) && trim($BrandCode) != "") {
									$BrandName = isset($brandLookUp[$BrandCode]) ? $brandLookUp[$BrandCode] : '';
								}
								if($BrandName != '' && !empty($BrandName)){
									$brandTaxonomy = get_term_by('name', $BrandName, 'brand');
									if(empty($brandTaxonomy)){
										$clean_brand_name = preg_replace('/\s+/', '-', $BrandName);
										$clean_brand_name = strtolower($clean_brand_name);
										$category_args = array('cat_name' => $BrandName, 'category_description' => '', 'category_nicename' => $clean_brand_name, 'category_parent' => '', 'taxonomy'=> 'brand');
										$brand_id = wp_insert_category($category_args);
									}else{
										$brand_id = $brandTaxonomy->term_id;
									}
								}else{
									$brand_id = '';
								}
								
								if($GROUP != 'Not Used' && !empty($GROUP)){
									$category = get_term_by('name', $GROUP, 'product_cat');
									if(empty($category)){
										$clean_grp_name = preg_replace('/\s+/', '-', $GROUP);
										$clean_grp_name = strtolower($clean_grp_name);
										$category_args = array('cat_name' => $GROUP, 'category_description' => '', 'category_nicename' => $clean_grp_name, 'category_parent' => '', 'taxonomy'=> 'product_cat');
										$category_id = wp_insert_category($category_args);
									}else{
										$category_id = $category->term_id;
									}
								}else{
									$category_id = '';
								}
								//update_option('test_data_'.time(), array($GROUP, $CATEGORY));
								/*Adding child category of Eliquid: start */
								if($GROUP == 'Eliquid' && $CATEGORY == 'Dilutents' && !empty($category_id)){
									update_option('test_data_checked_cat'.time(), array($GROUP, $CATEGORY));
									$child_category = get_term_by('name', $CATEGORY, 'product_cat');
									if(empty($child_category)){
										$clean_cat_name = preg_replace('/\s+/', '-', $CATEGORY);
										$clean_cat_name = strtolower($clean_cat_name);
										$ch_category_args = array('cat_name' => $CATEGORY, 'category_description' => '', 'category_nicename' => $clean_cat_name, 'category_parent' => $category_id, 'taxonomy'=> 'product_cat');
										$child_cat_id = wp_insert_category($ch_category_args);
									} else {
										$child_cat_id = $child_category->term_id;
									}

								}else{
									$child_cat_id = '';
								}
								/*Adding child category of Eliquid: end */

								$product_details = $product;

								if($product_details != false){
									$variation_data = array();
									$variationType = array();
									if($SKU != '') {
										if(!empty($ATTRIBUTES)) {
											if(isset($ATTRIBUTES['size'])) {
												$variationType[] = 'size';
												$variation_data['size'] =  array($ATTRIBUTES['size']);
											}
											if(isset($ATTRIBUTES['viscosity'])) {
												$variationType[] = 'viscosity';
												$variation_data['viscosity'] =  array($ATTRIBUTES['viscosity']);
											}
											if(isset($ATTRIBUTES['flavour'])) {
												$TITLE = isset($titleLookup[substr($SKU, 0, 7)]) ? $titleLookup[substr($SKU, 0, 7)].' Range' : $product->Category->Name;
												$variationType[] = 'flavour';
												$variation_data['flavour'] =  array($ATTRIBUTES['flavour']);
											}
											if(isset($ATTRIBUTES['piece'])) {
												$variationType[] = 'piece';
												$variation_data['piece'] =  array($ATTRIBUTES['piece']);
											}
											if(isset($ATTRIBUTES['resistance'])) {
												$variationType[] = 'resistance';
												$variation_data['resistance'] =  array($ATTRIBUTES['resistance']);
											}
											if(isset($ATTRIBUTES['colour'])) {
												$variationType[] = 'colour';
												$variation_data['colour'] =  array($ATTRIBUTES['colour']);
											}
											if(isset($ATTRIBUTES['concentrates'])) {
												$productParentSKU = substr($SKU, 0, 8);
												$TITLE = isset($titleLookup[substr($SKU, 0, 8)]) ? $titleLookup[substr($SKU, 0, 8)].' Concentrate' : $product->Category->Name;
												$variationType[] = 'concentrates';
												$variation_data['concentrates'] =  array($ATTRIBUTES['concentrates']);
											}
											if(isset($ATTRIBUTES['type'])) {
												$variationType[] = 'type';
												$variation_data['type'] =  array($ATTRIBUTES['type']);
											}
										}
									}

									$inventory = $product_details->StockLevel;
									if($inventory == null) { $inventory = 0; }
									elseif(empty($inventory)){ $inventory = 0; }
									elseif( $inventory < 0 ){ $inventory = 0; }
									
									$woo_id = JVA__Functions::get_productid_by_swiftpostid( $ID );
									$img_data = "";
									if( empty($woo_id) || get_post_status($woo_id) === false ){
										$variableProductWooId = JVA__Functions::get_productid_by_productparentsku( $productParentSKU, $SKU, $ParentTITLE );
										if($variableProductWooId != false ) {
											wp_delete_object_term_relationships( $variableProductWooId, 'product_cat' );

											if(!empty($category_id) && !empty($group_id)){
												if(!empty($child_cat_id)){
													$cat_ids = array_map( 'intval', array($category_id, $group_id, $child_cat_id) );
													wp_set_object_terms( $variableProductWooId, $cat_ids, 'product_cat', true );
												}else{
													$cat_ids = array_map( 'intval', array($category_id, $group_id) );
													wp_set_object_terms( $variableProductWooId, $cat_ids, 'product_cat', true );
												}
												
											}elseif(!empty($category_id) && empty($group_id)){
												if(!empty($child_cat_id)){
													wp_set_object_terms( $variableProductWooId, array((int)$category_id, $child_cat_id), 'product_cat', true );
												}else{
													wp_set_object_terms( $variableProductWooId, (int)$category_id, 'product_cat', true );
												}
												
											}elseif(empty($category_id) && !empty($group_id)){
												if(!empty($child_cat_id)){
													wp_set_object_terms( $variableProductWooId, array((int)$group_id, $child_cat_id), 'product_cat', true );
												}else{
													wp_set_object_terms( $variableProductWooId, (int)$group_id, 'product_cat', true );
												}

											}
											

											update_post_meta($variableProductWooId, 'swiftpost_product', 'true');
											$this->update_product_status($variableProductWooId);
											
											$stock_status = $inventory > 0 ? 'instock' : 'outofstock';
											$variationData =  array(
												'swiftpost_id'  => $ID,
												'author'        =>  get_current_user_id(),
												'title'         => $TITLE,
												'content'       => $DESC,
												'excerpt'       => '',
												'regular_price' => $product_details->Price,
												'sale_price'    => $product_details->Price,
												'stock'         => $inventory,
												'stock_status'  => $stock_status,
												'sku'           => $SKU,
												'tax_class'     => '',
												'weight'        => '',
												'variation_type'=> $variationType,
												'attributes'    => $variation_data,
												'imgagedata'    => $product_details->Image,
												'standard_title'=> $STANDARDTITLE,
												'_parent_sku' => $productParentSKU,
												'reupload_images'=> $reupload_images
											);										
											JVA__Functions::create_product_variation($variationData, $variableProductWooId, $syncWarehouse);
											wp_delete_object_term_relationships( $variableProductWooId, 'brand' );
											if(!empty($brand_id))  {
												wp_set_object_terms( $variableProductWooId, $brand_id, 'brand', true );
											}
										} else if(!empty($variation_data)){
											$post = array(
												'post_author' => get_current_user_id(),
												'post_content' => '',
												'post_status' => "publish",
												'post_title' => $TITLE,
												'post_parent' => '',
												'post_excerpt' => $DESC,
												'post_type' => "product",
											);
											$post_id = wp_insert_post( $post, false );
											
											$img_data = $product_details->Image;
											update_post_meta($post_id, 'swiftpost_id', $ID);
											update_post_meta($post_id, 'swiftpost_guid', $GUID);
											
											$add_product = JVA__Functions::insert_new_product( $post_id, $ID, $inventory );
											wp_delete_object_term_relationships( $post_id, 'product_cat' );

											if(!empty($category_id) && !empty($group_id)){
												if(!empty($child_cat_id)){
													$cat_ids = array_map( 'intval', array($category_id, $group_id, $child_cat_id) );
													wp_set_object_terms( $post_id, $cat_ids, 'product_cat', true );
												}else{
													$cat_ids = array_map( 'intval', array($category_id, $group_id) );
													wp_set_object_terms( $post_id, $cat_ids, 'product_cat', true );
												}
												
											}elseif(!empty($category_id) && empty($group_id)){
												if(!empty($child_cat_id)){
													wp_set_object_terms( $post_id, array((int)$category_id, $child_cat_id), 'product_cat', true );
												}else{
													wp_set_object_terms( $post_id, (int)$category_id, 'product_cat', true );
												}
												
											}elseif(empty($category_id) && !empty($group_id)){
												if(!empty($child_cat_id)){
													wp_set_object_terms( $post_id, array((int)$group_id, $child_cat_id), 'product_cat', true );
												}else{
													wp_set_object_terms( $post_id, (int)$group_id, 'product_cat', true );
												}
												
											}
											wp_delete_object_term_relationships( $post_id, 'brand' );

											if(!empty($brand_id))  {
												wp_set_object_terms( $post_id, $brand_id, 'brand', true );
											}
											if($post_id){
												update_post_meta($post_id, 'swiftpost_product', 'true');
												$this->update_product_status($post_id);
												
												$this->updateProductMeta($post_id, $productParentSKU, $inventory, $product_details, $CATEGORY_ID);
												update_post_meta( $post_id, '_parent_sku', $productParentSKU);
												
												$sharePointImageUrl = $rootBaseDirectory.'product_images/'.$productParentSKU.'.jpg';
												$this->setFeaturedImage($sharePointImageUrl, $post_id, $product_details->Image);
												$this->productImageGallery($post_id, $productParentSKU);
												
												$variationData =  array(
													'swiftpost_id'  => $ID,
													'author'        =>  get_current_user_id(),
													'title'         => $TITLE,
													'content'       => $DESC,
													'excerpt'       => '',
													'regular_price' => $product_details->Price,
													'sale_price'    => $product_details->Price,
													'stock'         => $inventory,
													'stock_status'  => $stock_status,
													'sku'           => $SKU,
													'tax_class'     => '',
													'weight'        => '',
													'variation_type'=> $variationType,
													'attributes'    => $variation_data,
													'imgagedata'    => $product_details->Image,
													'standard_title'=> $STANDARDTITLE,
													'_parent_sku' => $productParentSKU,
													'reupload_images'=> $reupload_images
												);
												JVA__Functions::create_product_variation($variationData, $post_id, $syncWarehouse);
											}
										} else  {
											$post = array(
												'post_author' => get_current_user_id(),
												'post_content' => '',
												'post_status' => "publish",
												'post_title' => $TITLE,
												'post_parent' => '',
												'post_excerpt' => $DESC,
												'post_type' => "product",
											);
											$post_id = wp_insert_post( $post, false );
											update_post_meta($post_id, 'swiftpost_product', 'true');
											update_post_meta($post_id, 'swiftpost_id', $ID);
											update_post_meta($post_id, 'swiftpost_guid', $GUID);
											
											$img_data = $product_details->Image;
											$add_product = JVA__Functions::insert_new_product( $post_id, $ID, $inventory );

											wp_delete_object_term_relationships( $post_id, 'product_cat' );

											if(!empty($category_id) && !empty($group_id)){
												if(!empty($child_cat_id)){
													$cat_ids = array_map( 'intval', array($category_id, $group_id, $child_cat_id) );
													wp_set_object_terms( $post_id, $cat_ids, 'product_cat', true );
												}else{
													$cat_ids = array_map( 'intval', array($category_id, $group_id) );
													wp_set_object_terms( $post_id, $cat_ids, 'product_cat', true );
												}
												
											}elseif(!empty($category_id) && empty($group_id)){
												if(!empty($child_cat_id)){
													wp_set_object_terms( $post_id, array((int)$category_id, $child_cat_id), 'product_cat', true );
												}else{
													wp_set_object_terms( $post_id, (int)$category_id, 'product_cat', true );
												}
												
											}elseif(empty($category_id) && !empty($group_id)){
												if(!empty($child_cat_id)){
													wp_set_object_terms( $post_id, arra((int)$group_id, $child_cat_id), 'product_cat', true );
												}else{
													wp_set_object_terms( $post_id, (int)$group_id, 'product_cat', true );
												}
												
											}
										}
									}else{
										$post_id = $woo_id;

										$this->update_product_ids[] = $post_id;

										$variableProductWooId = JVA__Functions::get_productid_by_productparentsku( $productParentSKU, $SKU, $TITLE);
										if(!empty($variableProductWooId)){

											wp_delete_object_term_relationships( $variableProductWooId, 'product_cat' );

											if(!empty($category_id) && !empty($group_id)){
												if(!empty($child_cat_id)){
													$cat_ids = array_map( 'intval', array($category_id, $group_id, $child_cat_id) );
													wp_set_object_terms( $variableProductWooId, $cat_ids, 'product_cat', true );
												}else{
													$cat_ids = array_map( 'intval', array($category_id, $group_id) );
													wp_set_object_terms( $variableProductWooId, $cat_ids, 'product_cat', true );
												}
												
											}elseif(!empty($category_id) && empty($group_id)){
												if(!empty($child_cat_id)){
													wp_set_object_terms( $variableProductWooId, array((int)$category_id, $child_cat_id), 'product_cat', true );
												}else{
													wp_set_object_terms( $variableProductWooId, (int)$category_id, 'product_cat', true );
												}
												
											}elseif(empty($category_id) && !empty($group_id)){
												if(!empty($child_cat_id)){
													wp_set_object_terms( $variableProductWooId, array((int)$group_id, $child_cat_id), 'product_cat', true );
												}else{
													wp_set_object_terms( $variableProductWooId, (int)$group_id, 'product_cat', true );
												}

											}
										}
											
										if($reupload_images == true){
											$img_data = $product_details->Image;
										}
										$update_product = JVA__Functions::update_product_inventory( $ID, $woo_id, $inventory );
									}
									
									if($post_id && empty($variationData)){

										$this->update_product_ids[] = $post_id;

										update_post_meta($post_id, 'swiftpost_product', 'true');
										$this->update_product_status($post_id);
										wp_delete_object_term_relationships( $post_id, 'brand' );
										if(!empty($brand_id))  {
											wp_set_object_terms( $post_id, $brand_id, 'brand', true );
										}
										
										$this->updateProductMeta($post_id, $SKU, $inventory, $product_details, $CATEGORY_ID);
										
										update_post_meta($post_id, '_price_per_inventory', 'global');
										update_post_meta($post_id, '_expirable_inventories', 'global');
										update_post_meta($post_id, '_inventory_iteration', 'global');
										update_post_meta($post_id, '_selling_priority', 'global');
										update_post_meta($post_id, '_multi_inventory', 'global');
										update_post_meta($post_id, '_backorders', 'no');
										
										$this->setFeaturedImage($sharePointImageUrl, $post_id, $product_details->Image);	
										$this->productImageGallery($post_id, $SKU);
										
										// Inventory Sync in Autum
										$JVA__Functions->autumInventorySync($post_id, $supplierId, $supplierName, $inventory, $stock_status, false);
									}
									$i++;
									$countProduct++;
								}else{
									$failed .= '<span reason="' . $this->errors['response']->Messages[0] . '">'.$ID."</span>, ";
									$n++;
								}
							}
							/* if($i > 10){
								break;
							} */
						}
					}
					
					$countSyncProduct++;
				}
				$variationSync = get_option("variationSync", true);
				$newVariationSync = $variationSync + $i;
				update_option("variationSync",$newVariationSync);

				$this->total = ''.$totalProduct;
				$this->variation = ''.$newVariationSync;
				$this->totalVariation = ''.$totalVariation;
				$this->msg .= ''.$newVariationSync.' product (s) synced successfully, and '.$n.' failed.<br>';
				if($n > 0 ){
					$this->msg .= '<br>Product(s) with the following SwiftPOS IDs were not synced: <b>'.trim($failed, ', ').'</b>.';
				}
				$this->status = true;
				$totalVariation = get_option("totalVariation", true);
				if($newVariationSync >= $totalVariation ){
					update_option("variationSync",'');
					update_option($syncWarehouse."_variationSync",$syncWarehouse);
				}
			} else {
				echo 'else -> !empty($all_new_products)'; die();
				$this->status = false;
				$this->msg = 'Inventory synchronization could not be completed.';
			}		
		} else {
			$this->status = false;
			$this->msg = 'Inventory synchronization could not be completed.';
		}
		if($offset == 0){
			// $this->write_SwiftPost_log("Inventory synchronization Logs : ".date("Y-m-d H:is"));
		}
		// $this->write_SwiftPost_log($this);
		return $this;
	}
	
	public function updateProductMeta($post_id, $SKU, $inventory, $product_details, $CATEGORY_ID) {
		$stock_status = $inventory > 0 ? 'instock' : 'outofstock';
		update_post_meta( $post_id, '_stock_status', $stock_status);
		update_post_meta( $post_id, '_regular_price', $product_details->Price );
		update_post_meta( $post_id, '_price', $product_details->Price );
		update_post_meta($post_id, '_sku', $SKU);
		update_post_meta($post_id, '_swiftpos_category_id', $CATEGORY_ID);
		update_post_meta( $post_id, '_manage_stock', 'yes' );
		update_post_meta( $post_id, '_stock', $inventory );
	}

	public function updateProductMetaWithoutInventory($post_id, $SKU, $inventory, $product_details, $CATEGORY_ID) {
		// $stock_status = $inventory > 0 ? 'instock' : 'outofstock';
		// update_post_meta( $post_id, '_stock_status', $stock_status);
		update_post_meta( $post_id, '_regular_price', $product_details->Price );
		update_post_meta( $post_id, '_price', $product_details->Price );
		update_post_meta($post_id, '_sku', $SKU);
		update_post_meta($post_id, '_swiftpos_category_id', $CATEGORY_ID);
		// update_post_meta( $post_id, '_manage_stock', 'yes' );
		// update_post_meta( $post_id, '_stock', $inventory );
	}
	
	public function setFeaturedImage($sharePointImageUrl, $post_id, $img_data = ''){
		if(empty($img_data)){
			delete_post_meta($post_id, '_thumbnail_id');
			return;
		}
		if (!@file_exists($sharePointImageUrl) && !empty($img_data)) {
			$decoded =  base64_decode($img_data);
			file_put_contents( $sharePointImageUrl, $decoded);
		}

		if(@file_exists($sharePointImageUrl)){
			$productImageExist = get_post_meta($post_id, '_thumbnail_id', true);
			$productImageCreateDate = filemtime($sharePointImageUrl);
			if($productImageExist != '') {
				$productImageInsertDate = get_post_meta($productImageExist, '_last_modified_date', true);
				if($productImageCreateDate <= $productImageInsertDate) {
					return true;
				}
			}
			$upload_dir = wp_upload_dir();
			$upload_path = str_replace( '/', DIRECTORY_SEPARATOR, $upload_dir['path'] ) . DIRECTORY_SEPARATOR;
			$decoded = file_get_contents($sharePointImageUrl);
			$filename = basename($sharePointImageUrl);
			$hashed_filename = md5( $filename ) . '_' . $filename;
			$image_upload = file_put_contents( $upload_path . $hashed_filename, $decoded );
			
			if( !function_exists( 'wp_handle_sideload' ) ) {
			  require_once( ABSPATH . 'wp-admin/includes/file.php' );
			}

			if( !function_exists( 'wp_get_current_user' ) ) {
			  require_once( ABSPATH . 'wp-includes/pluggable.php' );
			}
			require_once(ABSPATH . 'wp-admin/includes/image.php');
			$file             = array();
			$file['error']    = '';
			$file['tmp_name'] = $upload_path . $hashed_filename;
			$file['name']     = $hashed_filename;
			$file['type']     = 'image/png';
			$file['size']     = filesize( $upload_path . $hashed_filename );

			// upload file to server
			$file_return = wp_handle_sideload( $file, array( 'test_form' => false ) );
			$filename = $file_return['file'];
			$attachment = array(
			 'post_mime_type' => $file_return['type'],
			 'post_title' => preg_replace('/\.[^.]+$/', '', basename($filename)),
			 'post_content' => '',
			 'post_status' => 'inherit',
			 'post_parent' => $post_id,
			 'guid' => $upload_dir['url'] . '/' . basename($filename)
			 ); 
			$attach_id = wp_insert_attachment( $attachment, $filename);
			$attach_data = wp_generate_attachment_metadata( $attach_id, $file_return['file'] );
			wp_update_attachment_metadata( $attach_id, $attach_data );
			update_post_meta($attach_id, '_last_modified_date', $productImageCreateDate);
			update_post_meta($post_id, '_thumbnail_id', $attach_id);
		}
	}
	
	public function productImageGallery($postId, $sku){
		$galleryImages = array();
		$productGalleryId = array();
		$rootBaseDirectory = ABSPATH;
		$productGallery = get_post_meta($postId, '_product_image_gallery', true);
		if($productGallery != '') {
			$productGalleryId = explode(',', $productGallery);
		}
		for($j=1;$j<=5;$j++) {
			$shareProductGalleryUrl = $rootBaseDirectory.'product_images/'.$sku.'-'.$j.'.jpg';
			$productImageGuid =  site_url() .'/product_images/'.$sku.'-'.$j.'.jpg';
			if(@file_exists($shareProductGalleryUrl)){
				$productImageCreateDate = filemtime($shareProductGalleryUrl);
				$productImageInsertDate = get_post_meta($productGalleryId[($j-1)], '_last_modified_date', true);
				if($productImageCreateDate <= $productImageInsertDate) {
					$galleryImages[] = $productGalleryId[($j-1)];
				} else {
					/* $filetitle = get_the_title($postId).'-'.$j;
					$filename = $sku.'-'.$j.'.jpg';
					if( !function_exists( 'wp_handle_sideload' ) ) {
					  require_once( ABSPATH . 'wp-admin/includes/file.php' );
					}
					if( !function_exists( 'wp_get_current_user' ) ) {
					  require_once( ABSPATH . 'wp-includes/pluggable.php' );
					}
					require_once(ABSPATH . 'wp-admin/includes/image.php');
					$timeout_seconds = '5';
					$temp_file = download_url( $productImageGuid, $timeout_seconds );

					$file             = array();
					$file['error']    = '';
					$file['tmp_name'] = $shareProductGalleryUrl;
					$file['name']     = $filename;
					$file['type']     = 'image/png';
					$file['size']     = filesize( $shareProductGalleryUrl );

					// upload file to server
					$file_return = wp_handle_sideload( $file, array( 'test_form' => false ) );
					//$filename = $file_return['file'];
					$attachment = array(
						'post_mime_type' => $file_return['type'],
						'post_title' => preg_replace('/\.[^.]+$/', '', $filetitle),
						'post_content' => '',
						'post_status' => 'inherit',
						'post_parent' => $postId,
						'guid' => $productImageGuid
					);  */
					
					$upload_dir = wp_upload_dir();
					$upload_path = str_replace( '/', DIRECTORY_SEPARATOR, $upload_dir['path'] ) . DIRECTORY_SEPARATOR;
					$decoded = file_get_contents($shareProductGalleryUrl);
					$filename = basename($shareProductGalleryUrl);
					$hashed_filename = md5( $filename ) . '_' . $filename;
					$image_upload = file_put_contents( $upload_path . $hashed_filename, $decoded );
					
					if( !function_exists( 'wp_handle_sideload' ) ) {
						require_once( ABSPATH . 'wp-admin/includes/file.php' );
					}

					if( !function_exists( 'wp_get_current_user' ) ) {
					  require_once( ABSPATH . 'wp-includes/pluggable.php' );
					}
					require_once(ABSPATH . 'wp-admin/includes/image.php');
					$file             = array();
					$file['error']    = '';
					$file['tmp_name'] = $upload_path . $hashed_filename;
					$file['name']     = $hashed_filename;
					$file['type']     = 'image/png';
					$file['size']     = filesize( $upload_path . $hashed_filename );

					// upload file to server
					$file_return = wp_handle_sideload( $file, array( 'test_form' => false ) );
					$filename = $file_return['file'];
					$attachment = array(
						'post_mime_type' => $file_return['type'],
						'post_title' => preg_replace('/\.[^.]+$/', '', basename($filename)),
						'post_content' => '',
						'post_status' => 'inherit',
						'post_parent' => $post_id,
						'guid' => $upload_dir['url'] . '/' . basename($filename)
					);
					$attach_id = wp_insert_attachment( $attachment, $filename);
					update_post_meta($attach_id, '_last_modified_date', $productImageCreateDate);
					$attach_data = wp_generate_attachment_metadata( $attach_id, $file_return['file'] );
					wp_update_attachment_metadata( $attach_id, $attach_data );
					$galleryImages[] = $attach_id;
				}
			}
		}
		if(!empty($galleryImages)) {
			$galleryArray = array_unique($galleryImages);
			$galleryString = implode(',',$galleryArray);
			update_post_meta($postId, '_product_image_gallery', $galleryString);
		}
	}
	
	function write_SwiftPost_log($log) {
		if (true === WP_DEBUG) {
			if (is_array($log) || is_object($log)) {
				error_log(print_r($log, true));
			} else {
				error_log($log);
			}
		}
	}



	public function update_woo_stock($product_id = ""){
		if(!empty($product_id)){
			// Delay execution until SwiftPOS process the Sale/Finalize request and change stock on their end.
			set_time_limit(120);
			sleep(30);	
			$ID =  JVA__Functions::get_swiftpostid_by_productid( $product_id );
			if($ID != false){
				$function =  "Product/".$ID."";
				$data = '';
				$product_details = $this->request($this->key, $data, $function);
				$inventory = $product_details->StockLevel;
				if($inventory == null) { $inventory = 0; }
				elseif(empty($inventory)){ $inventory = 0; }
				elseif( $inventory < 0 ){ $inventory = 0; }

				$update_stock = JVA__Functions::update_product_inventory( $ID, $product_id, $inventory );
			}

		}else{
			$data = '';
			$all_products = $this->request($this->key, $data, "Product");
			if($all_products != false){
				foreach($all_products as $product){
					$ID = $product->Id;
					$inventory = $product->StockLevel;
					if($inventory == null) { $inventory = 0; }
					elseif(empty($inventory)){ $inventory = 0; }
					elseif( $inventory < 0 ){ $inventory = 0; }

					$product_id = JVA__Functions::get_productid_by_swiftpostid( $ID );
					if(!empty($product_id)){
						$update_stock = JVA__Functions::update_product_inventory( $ID, $product_id, $inventory );
					}
				}
			}
		}
	}
	public function is_swiftpost_member($user_email, $user_firstname, $user_surname, $address, $suburb, $state, $postcode, $country_array){
		$email = $user_email;
		
		$email_data = array('emailAddress' => $email);
		$member = $this->request($this->key, $email_data, "Member");
		
		if($member != false && !empty($member[0]->Id)){
			return $member[0];
		}else{
			
			$data = array( 
						'type'=> 0,
						'firstName'=>$user_firstname,
						'surname'=> $user_surname,
						'shippingAddress'=> array(
											'addressLine1' => $address,
											'suburb' => $suburb,
											'state' => $state,
											'postcode' => $postcode,
											'country' => $country_array,
										),
						'mobilePhone'=> $phone,
						'emailAddress'=> $user_email,
						'classifications'=> array( array('id' => 1) ),
					);

			$new_member = $this->request($this->key, $data, "Member", "POST");

			if($new_member != false){
					$get_member = $this->request($this->key, $email_data, "Member");
					if($get_member != false && !empty($get_member[0]->Id)){
						return $get_member[0];
					}else{
						return false;
					}
			}else{
				return false;
			}
		}
	}

	public function get_country($country_code){
		
		$countries = $this->request($this->key, '', "Country");
		
		foreach($countries as $country){
			$country = (array)$country;
			if($country['IsoCountryCode'] == $country_code){
				return $country;
			}
		}
	}
	
	public function make_order($order_id){
		
		$order = new WC_Order( $order_id );
		$date_created = $order->get_date_created()->date( 'c' );
		$user_email = $order->get_billing_email();
		$user_firstname = $order->get_billing_first_name();
		$user_surname = $order->get_billing_last_name();
		$status = $order->get_status();
		$items =   $order->get_items();
		
		$member = $this->is_swiftpost_member($user_email, $user_firstname, $user_surname);

		
		
		$SwiftPOS_Member = array( 'id' => ''.$member->Id.'', 'type'=> 0);
		$SwiftPOS_Items = array();
		foreach($items as $item){
			$product_id = $item['product_id'];
			$swiftpost_id = JVA__Functions::get_swiftpostid_by_productid ( $product_id );
			$price = $item['total'];
			$qty = $item['qty'];
			
			$SwiftPOS_Items[]= array('id'=> (int)$swiftpost_id, 'quantity'=> $qty, 'price'=> $price ); 
		}
		
		$data = array(
						'id'=> $order_id,
						'type'=> 1,
						'orderDate'=> $date_created,
						'scheduledOrderDate'=> $date_created,
						'member'=> $SwiftPOS_Member,
						'items'=> $SwiftPOS_Items,
					);

		$make_order = $this->request($this->key, $data, "Order", "POST");

		if($make_order != false){
			foreach($items as $item){
				$product_id = $item['product_id'];
				$this->update_woo_stock($product_id);
			}
		}
		return $this;
	}
	
	public function process_sale($order_id){ 

		$order = new WC_Order( $order_id );
		$date_created = $order->get_date_created()->date( 'c' );
		$user_email = $order->get_billing_email();
		$user_firstname = $order->get_billing_first_name();
		$user_surname = $order->get_billing_last_name();
		$phone    = $order->get_billing_phone();
		$address    = $order->get_shipping_address_1() . $order->get_shipping_address_2();
		$suburb    = $order->get_shipping_city();
		$state    = $order->get_shipping_state();
		$postcode    = $order->get_shipping_postcode();
		$country    = get_post_meta( $order_id, '_shipping_country', true );
		
		$address    = !empty($address) ? $address : $order->get_billing_address_1() . $order->get_billing_address_2();
		$suburb    = !empty($suburb) ? $suburb : $order->get_billing_city();
		$state    = !empty($state) ? $state : $order->get_billing_state();
		$postcode    =  !empty($postcode) ? $postcode : $order->get_billing_postcode();
		$country    =  !empty($country) ? $country : get_post_meta( $order_id, '_billing_country', true );
		
		$country_array = $this->get_country($country);
		
		$status = $order->get_status();
		$items =   $order->get_items();
		
		$member = $this->is_swiftpost_member($user_email, $user_firstname, $user_surname, $address, $suburb, $state, $postcode, $country_array);
		$SwiftPOS_Member = (array)$member;
		$SwiftPOS_Items = array();
		
		foreach($items as $item){

			$product_id = $item['product_id'];
			$swiftpost_id = JVA__Functions::get_swiftpostid_by_productid ( $product_id );
			$qty = $item['qty'];
			$total = $item['total'];
			$price = $total / $qty;
			
			
			$categoryId = get_post_meta( $product_id, '_swiftpos_category_id', true );
			$inventoryCode = get_post_meta( $product_id, '_sku', true );
			$SwiftPOS_Items[]= array(
								'id'=> (int)$swiftpost_id,
								'type'=> 1,
								'quantity'=> $qty,
								'price'=> $price,
								'lineTotal'=> number_format($total, 2, '.', ''),
								'categoryId'=> (int)$categoryId,
								'inventoryCode'=> $inventoryCode,
							);
		}
		
		$payment_method_id = 1; // Cash // Change based on the payment method user and shop available payment methods (http://webstores.swiftpos.com.au:4000/SwiftApi/api/Media)
		$amount =  $order->get_total();
		
		$SwiftPOS_Media = array(
							'id' => (int)$payment_method_id,
							'amount' => number_format($amount, 2, '.', '')
						);
		
		$data = array(
						'id'=> $order_id,
						'saleDate'=> $date_created,
						'member'=> $SwiftPOS_Member,
						'items'=> $SwiftPOS_Items,
						'media'=> array($SwiftPOS_Media),
					);
					
		$make_sale = $this->request($this->key, $data, "Sale/Process", "POST");
		/* if($make_sale != false && !empty($make_sale->Id)){
			$sale_id = $make_sale->Id;
			update_post_meta( $order_id, '_swiftpost_sale_id', $sale_id );
			foreach($items as $item){
				$product_id = $item['product_id'];
				$this->update_woo_stock($product_id);
			}
		} */
		return $this;
	}

	public function make_sale($order_id){
		$order = new WC_Order( $order_id );
		$date_created = $order->get_date_created()->date( 'c' );
		$date_display = $order->get_date_created()->date( 'M d,Y' );
		$user_email = $order->get_billing_email();
		$user_firstname = $order->get_billing_first_name();
		$user_surname = $order->get_billing_last_name();
		$phone    = $order->get_billing_phone();
		$address    = $order->get_shipping_address_1() . $order->get_shipping_address_2();
		$suburb    = $order->get_shipping_city();
		$state    = $order->get_shipping_state();
		$postcode    = $order->get_shipping_postcode();
		$country    = get_post_meta( $order_id, '_shipping_country', true );
		$paymentMethod = $order->get_payment_method();
		
		$address    = !empty($address) ? $address : $order->get_billing_address_1() . $order->get_billing_address_2();
		$suburb    = !empty($suburb) ? $suburb : $order->get_billing_city();
		$state    = !empty($state) ? $state : $order->get_billing_state();
		$postcode    =  !empty($postcode) ? $postcode : $order->get_billing_postcode();
		$country    =  !empty($country) ? $country : get_post_meta( $order_id, '_billing_country', true );
		
		$country_array = $this->get_country($country);
		
		$status = $order->get_status();
		$items =   $order->get_items();
		
		$billingData = array(
					'name'       => $user_firstname.' '.$user_surname,
					'user_email' => $user_email,
					'phone'      => $phone,
					'address'    => $order->get_billing_address_1() . $order->get_billing_address_2(),
					'suburb'     => $order->get_billing_city(),
					'state'      => $order->get_billing_state(),
					'postcode'   => $order->get_billing_postcode(),
					'country'    => get_post_meta( $order_id, '_billing_country', true ),
				);
		$shippingData = array(
					'name'       => $user_firstname.' '.$user_surname,
					'user_email' => $user_email,
					'phone'      => $phone,
					'address'    => $address,
					'suburb'     => $suburb,
					'state'      => $state,
					'postcode'   => $postcode,
					'country'    => $country,
				);
		
		$SwiftPOS_Items = array();
		$syncJva = new JVA__Functions();
		$allSaleItems = array();
		if(!empty($items)) {
			foreach($items as $item){
				$orderItemId = $item->get_id();
				$itemName = $item['name'];
				$productId = $item['product_id'];
				$variation_id = $item['variation_id'];
				if($variation_id != '' && $variation_id > 0) {
					$product_id = $variation_id;
				} else {
					$product_id = $productId;
				}
				$orderItemSKU = get_post_meta($product_id,'_sku',true);
				$inventory = $syncJva->getAutumOrderfromOrderItemId($product_id, $orderItemId);
				if(!empty($inventory)) {
					foreach($inventory as $inventoryData) {
						$inventoryId = $inventoryData->ID;
						$qty = $inventoryData->qty;
						$total = $inventoryData->total;
						$is_main = $syncJva->checkInventoryIsMain($inventoryId);
						if(!empty($is_main)) {
							$isMain = $is_main[0]->is_main;
						}
						
						$supplierId = $syncJva->getSupplierFromInventoryId($inventoryId, $product_id, $isMain);
						$supplierCode = get_post_meta($supplierId, '_supplier_details_code', true);
						
						$swiftpost_id = get_post_meta($product_id, 'swiftpost_id', true);
						//$qty = $item['qty'];
						//$total = $item['total'];
						$price = $total / $qty;
						
						$categoryId = get_post_meta( $product_id, '_swiftpos_category_id', true );
						$inventoryCode = get_post_meta( $product_id, '_sku', true );
						$SwiftPOS_Items= array(
											'id'=> (int)$swiftpost_id,
											'type'=> 1,
											'quantity'=> $qty,
											'price'=> $price,
											'lineTotal'=> number_format($total, 2, '.', ''),
											'categoryId'=> (int)$categoryId,
											'inventoryCode'=> $inventoryCode,
										);
						$warehouseOrderData = array(
												'woo_id'=> (int)$orderItemId,
												'swiftpost_id'=> (int)$swiftpost_id,
												'title'    => $itemName,
												'sku'    => $orderItemSKU,
												'quantity' => $qty,
												'price'    => $price,
												'lineTotal'=> number_format($total, 2, '.', '')
											);
						$allSaleItems[$supplierCode]['items'][] = $SwiftPOS_Items;
						$allSaleItems[$supplierCode]['amount'][] = $total;
						$allSaleItems[$supplierCode]['emailOrder'][] = $warehouseOrderData;
					}
				}
			}
			if(!empty($allSaleItems)) {
				foreach($allSaleItems as $supplierCode => $saleItems) {
					$locationId = $syncJva->getApiLoginCredentials($supplierCode, 'locationId');
					$userId = $syncJva->getApiLoginCredentials($supplierCode, 'userId');
					$password = $syncJva->getApiLoginCredentials($supplierCode, 'password');
					$warehouseOrderEmail = get_post_meta($supplierCode,'_supplier_details_ordering_email', true);
					if($locationId && $userId && $password) {
						$ApiKey = $this->assign_api_key($locationId, $userId, $password);
						if($ApiKey == true){
							$member = $this->is_swiftpost_member($user_email, $user_firstname, $user_surname, $address, $suburb, $state, $postcode, $country_array);
						}
					}
					
					$SwiftPOS_Member = (array)$member;
					$payment_method_id = 1; // Cash // Change based on the payment method user and shop available payment methods (http://webstores.swiftpos.com.au:4000/SwiftApi/api/Media)
					$amount =  array_sum($saleItems['amount']);
					
					$SwiftPOS_Media = array(
										'id' => (int)$payment_method_id,
										'amount' => number_format($amount, 2, '.', '')
									);
					$data = array(
							'id'=> $order_id,
							'saleDate'=> $date_created,
							'member'=> $SwiftPOS_Member,
							'items'=> $saleItems['items'],
							'media'=> array($SwiftPOS_Media),
						);
						
					//print_r($data);
					/* $make_sale = $this->request($this->key, $data, "Sale/Finalise", "POST");
					if($make_sale != false && !empty($make_sale->Id)){
						$sale_id = $make_sale->Id;
						update_post_meta( $order_id, '_swiftpost_sale_id', $sale_id );
						foreach($items as $item){
							$product_id = $item['product_id'];
							$this->update_woo_stock($product_id);
						}
						$to = $warehouseOrderEmail;
						$subject = 'A New Order is Received from justvapoursaustralia.com.au';
						$message = $syncJva->sendWarehouseEmail($order_id, $date_display, $saleItems['emailOrder'], $paymentMethod, $billingData, $shippingData);
						$headers = array('Content-Type: text/html; charset=UTF-8');
						$headers[] = 'From: Just Vapour Australia <'.get_option('admin_email',true).'>';
						wp_mail( $to, $subject, $message, $headers, $attachments );
					}  */
				}
			}
			
			//return $this;
		}
	}
	
	/** 
	 * This is to calculate the total quantity of coils from boxes.
	 * 
	 */
	private function recalculate_coil_stock ($coil_products = false, $location = 1) {
		
		if(!$coil_products) return [];

		$_products = [];

		

		foreach($coil_products as $parentSKU => $products) :

			$coil_box_products = array_filter( // isolate the boxes
				$products,
				function ($product) use ($parentSKU, $location) {

					$boxes = [
						'A' 	=> 15,
						'B'		=> 30,
						'C'		=> 50,
						'D'		=> 100
					];
				
					$productSKU = $product->InventoryCode;
		
					$packingSKU = substr($productSKU, 8 ,1);
	
					if( in_array($packingSKU, ['A', 'B', 'C', 'D'])) {

						$inventory = $product->StockLevel;
						if($inventory == null) { $inventory = 0; }
						elseif(empty($inventory)){ $inventory = 0; }
						elseif( $inventory < 0 ){ $inventory = 0; }

						$product->BoxDetail = [
							'box_id'		=> $product->Id,
							'TotalStock'	=> floatval(abs($inventory)) * floatval($boxes[$packingSKU]),
							'Box'			=> $packingSKU,
							'BoxQuantity'	=> $inventory
						];

						

						return $product;
					}
	
				}
			);

		
			$coil_nonbox_products = array_filter( // pull the non-box product and calculate the total stock				
				$products,
				function ($product) use ($coil_box_products, $parentSKU) {
		
					$productSKU = $product->InventoryCode;
		
					$packingSKU = substr($productSKU, 8 ,1);
	
					$typeSKU = substr($productSKU, 10 ,3);
							
					if( ! in_array($packingSKU, ['A', 'B', 'C', 'D']) ) {

						// determine if the packaging is 1pc, 3pcs, 4pcs, 5pcs						
						$product_pieces = floatval($packingSKU);
						
						foreach($coil_box_products as $box_product) {
							
							$box_typeSKU = substr($box_product->InventoryCode, 10 ,3);
	
							if($box_typeSKU == $typeSKU) {

								
								//calculate the right stock for this product
								$_stock = floatval($box_product->BoxDetail['TotalStock']) / floatval(abs($product_pieces));
								

								$iinnvveennttoorryy = $product->StockLevel;
								if($iinnvveennttoorryy == null) { $iinnvveennttoorryy = 0; }
								elseif(empty($iinnvveennttoorryy)){ $iinnvveennttoorryy = 0; }
								elseif( $iinnvveennttoorryy < 0 ){ $iinnvveennttoorryy = 0; }

								$product->StockLevel = floatval( $iinnvveennttoorryy ) + floatval($_stock);
								$product->Box[] = $box_product->BoxDetail; // add the box details for verifying the right stock quantity
								
								// --- save box product id for inventory update purposes
								$coil_box_products_ids = get_option('coil_box_products_ids_' . $parentSKU . '_' . $box_typeSKU, []);
								$_box_product_ids = ( empty($coil_box_products_ids) ) ? [] : $coil_box_products_ids;

								if( ! in_array($box_product->Id, $_box_product_ids) ) $_box_product_ids[] = $box_product->Id;

								update_option('coil_box_products_ids_' . $parentSKU . '_' . $box_typeSKU, $_box_product_ids);
								// --- save box product id for inventory update purposes
	
							}
						}
	
						return $product;
					}
				}
			);

			$_products[$parentSKU] = $coil_nonbox_products;
	
		endforeach; //coil_products

		

		return $_products;

	}
	
	public function assign_api_key2($location, $user, $pass, $ApiKey = ""){

		if(!empty($ApiKey)){
			$this->key = $ApiKey;
			return true;
		}elseif(isset($location) && isset($user) && isset($pass) ){
			$key = 0;
			$data = array('locationId' => $location, 'userId' => $user, 'password' => $pass);
			$function = "Authorisation";
			$response = $this->request2($key, $data, $function);

			if($response == false){
				return false;
			}else{
				$this->key = $response->ApiKey;
				return true;
			}
		}
		
		return false;
	}

	public function assign_api_key($location, $user, $pass, $ApiKey = ""){

		if(!empty($ApiKey)){
			$this->key = $ApiKey;
			return true;
		}elseif(isset($location) && isset($user) && isset($pass) ){
			$key = 0;
			$data = array('locationId' => $location, 'userId' => $user, 'password' => $pass);
			$function = "Authorisation";
			$response = $this->request($key, $data, $function);

			if($response == false){
				return false;
			}else{
				$this->key = $response->ApiKey;
				return true;
			}
		}
		
		return false;
	}
	
	public function request($key, $data, $function, $request = "GET"){
		
		if($key === 0){
			$headers = array(
				'Content-Type: application/json',
				'Accept' => 'application/json',
			);
		}else{
			$headers = array(
				'Content-Type: application/json',
				'Accept' => 'application/json',
				'ApiKey:'.$key.''
			);
		}

		if($request == "GET" && !empty($data)){
			if(!empty($data['includeImage']) && $data['includeImage'] == true){
				unset($data['includeImage']);
				$query = http_build_query($data, '', '&');
				$query .= "&includeImage=true";
				
			}else{
				$query = http_build_query($data, '', '&');
			}
			//$url = "http://webstores.swiftpos.com.au:4000/SwiftApi/api/".$function."?".$query."";
			$url = "http://52.255.32.168:4000/WebApi/api/".$function."?".$query."";
		}else{
			//$url = "http://webstores.swiftpos.com.au:4000/SwiftApi/api/".$function."";
			$url = "http://52.255.32.168:4000/WebApi/api/".$function."";
		}
		$ccurl = curl_init($url); 
		curl_setopt($ccurl, CURLOPT_CUSTOMREQUEST, $request); 
		curl_setopt($ccurl, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($ccurl, CURLOPT_SSL_VERIFYPEER, 0 );
		curl_setopt($ccurl, CURLOPT_RETURNTRANSFER, 1 );
		if($request == "POST"){
			curl_setopt($ccurl, CURLOPT_POSTFIELDS, json_encode($data));
		}
		$result = curl_exec($ccurl);
		$httpcode = curl_getinfo($ccurl, CURLINFO_HTTP_CODE);
		curl_close($ccurl);
		$decoded_result = json_decode($result);
		
		/* print_r($request);
		echo '<br>';
		print_r($url);
		echo '<br>';
		print_r($data);
		echo '<br>';
		print_r($result);
		echo '<br>';
		print_r($headers);
		echo '<br>';
		print_r($httpcode);
		echo '<br>'; */
		
		// if($function == 'xxxxxxxxxxxxxxxxx'){
			// For debugging
			/* echo '<pre> <b> Data:</b> ';
			print_r($function);
			echo '</pre>';
			echo '<pre>';
			print_r($query);
			echo '</pre>';
			echo '________________________________________';
			echo '<pre><b> Decoded Result:</b> ';
			print_r($decoded_result);
			echo '</pre>'; */
			//echo '\*________________________________________*/';
		// }
		if($httpcode == 200 || $httpcode == 201){
			return $decoded_result;
		}else{
			$this->errors = array('key'=> $key, 'data'=> $data, 'function'=> $function, 'response'=> $decoded_result);
			return false;
		}
	}

	public function request2($key, $data, $function, $request = "GET"){
		
		if($key === 0){
			$headers = array(
				'Content-Type: application/json',
				'Accept' => 'application/json',
			);
		}else{
			$headers = array(
				'Content-Type: application/json',
				'Accept' => 'application/json',
				'ApiKey:'.$key.''
			);
		}

		if($request == "GET" && !empty($data)){
			if(!empty($data['includeImage']) && $data['includeImage'] == true){
				unset($data['includeImage']);
				$query = http_build_query($data, '', '&');
				$query .= "&includeImage=true";
				
			}else{
				$query = http_build_query($data, '', '&');
			}
			//$url = "http://webstores.swiftpos.com.au:4000/SwiftApi/api/".$function."?".$query."";
			$url = "http://52.255.32.168:4000/WebApi/api/".$function."?".$query."";
		}else{
			//$url = "http://webstores.swiftpos.com.au:4000/SwiftApi/api/".$function."";
			$url = "http://52.255.32.168:4000/WebApi/api/".$function."";
		}
		$ccurl = curl_init($url); 
		curl_setopt($ccurl, CURLOPT_CUSTOMREQUEST, $request); 
		curl_setopt($ccurl, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($ccurl, CURLOPT_SSL_VERIFYPEER, 0 );
		curl_setopt($ccurl, CURLOPT_RETURNTRANSFER, 1 );
		if($request == "POST"){
			curl_setopt($ccurl, CURLOPT_POSTFIELDS, json_encode($data));
		}
		$result = curl_exec($ccurl);
		$err = curl_error($ccurl);
		$httpcode = curl_getinfo($ccurl, CURLINFO_HTTP_CODE);
		curl_close($ccurl);
		$decoded_result = json_decode($result);
		
		/* print_r($request);
		echo '<br>';
		print_r($url);
		echo '<br>';
		print_r($data);
		echo '<br>';
		print_r($result);
		echo '<br>';
		print_r($headers);
		echo '<br>';
		print_r($httpcode);
		echo '<br>'; */
		
		// if($function == 'xxxxxxxxxxxxxxxxx'){
			// For debugging
			/* echo '<pre> <b> Data:</b> ';
			print_r($function);
			echo '</pre>';
			echo '<pre>';
			print_r($query);
			echo '</pre>';
			echo '________________________________________';
			echo '<pre><b> Decoded Result:</b> ';
			print_r($decoded_result);
			echo '</pre>'; */
			//echo '\*________________________________________*/';
		// }
		if($httpcode == 200 || $httpcode == 201){
			return $decoded_result;
		}else{
			echo $err;
			$this->errors = array('key'=> $key, 'data'=> $data, 'function'=> $function, 'response'=> $decoded_result);
			return false;
		}
	}
	// code by websupreme
    public function heal_product_after_sync($syncWarehouse){
        $productData = array();
	    foreach ($syncWarehouse as $wirehouse){
            switch ( $wirehouse ){
                case 'JVA' :
                    $productData = get_option("swiftPostApi_data");
                    break;
                case 'Melbourne':
                    $productData = get_option("swiftPostApi_melbourne_data");
                    break;
                case 'JAA':
                    $productData = get_option("swiftPostApi_jaa_data");
                    break;
            }
	        //$this->heal_category_sync($productData);
        }
        $args = array(
            'post_type'      => 'product',
            'numberposts' => -1,
            'fields' => 'ids'
        );

        $product_ids = get_posts( $args );
       foreach ($product_ids as $product) {
           $variableProduct = new WC_Product_Variable($product);
           $allVariations = $variableProduct->get_available_variations();
           if (empty($allVariations)) {
               wp_set_post_terms($product, 'simple', 'product_type');
           }
//           $term_slug = get_post_meta($product, '_swiftpos_category_id',true);
//           $term = get_term_by('slug', $term_slug, 'product_cat');
//           if($term != false){
//               wp_set_post_terms($product,$term->term_id,'product_cat',false);
//           }
       };
    }
    public function heal_category_sync($productData){
            foreach ($productData as $product){
                $category = $product->Category;
                if(get_term_by('slug',$category->Id,'product_cat') == false){
                    wp_insert_term(
                        $category->Name,
                        'product_cat', // the taxonomy
                        array(
                            'slug'        => $category->Id,
                        )
                    );
                }
            }
    }
	public function heal_product_sku($products){
	    foreach ($products as $product_details){
            $inventory = $product_details->StockLevel;
            if($inventory == null) { $inventory = 0; }
            elseif(empty($inventory)){ $inventory = 0; }
            elseif( $inventory < 0 ){ $inventory = 0; }
            $ID = $product_details->Id;
            $woo_id = $this->get_product_id_from_meta_sku($product_details->InventoryCode);
//             print_r('<');
//             print_r($product_details->InventoryCode);
//             print_r(':');
//             print_r($inventory);
//             print_r(':');
//             print_r($woo_id);
//             print_r('>');
            if($woo_id) {
                $stock_status = $inventory > 0 ? 'instock' : 'outofstock';
                update_post_meta( $woo_id, '_stock_status', $stock_status);
                update_post_meta($woo_id, '_stock', $inventory);
            }
        }
    }
    public function get_product_id_from_meta_sku($sku){
        global $wpdb;
        $data = $wpdb->get_results( "select post_id from $wpdb->postmeta where meta_key='_sku' AND meta_value = '".$sku."'", ARRAY_A );
        if(!empty($data)){
           return $data[0]['post_id'];
        }
        return 0;
    }

}