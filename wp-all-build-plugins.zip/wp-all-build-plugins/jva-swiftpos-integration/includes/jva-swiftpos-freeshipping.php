<?php
/**
* @snippet Notice with $$$ remaining to Free Shipping @ WooCommerce Cart
*/
 
function jva_free_shipping_cart_notice_zones() {
 
	global $woocommerce;
	 
	// Get Free Shipping Methods for Rest of the World Zone & populate array $min_amounts
	 
	$default_zone = new WC_Shipping_Zone(0);
	$default_methods = $default_zone->get_shipping_methods();
	 
	foreach( $default_methods as $key => $value ) {
		if ( $value->id === "free_shipping" ) {
		  if ( $value->min_amount > 0 ) $min_amounts[] = $value->min_amount;
		}
	}
	 
	// Get Free Shipping Methods for all other ZONES & populate array $min_amounts
	 
	$delivery_zones = WC_Shipping_Zones::get_zones();
	 
	foreach ( $delivery_zones as $key => $delivery_zone ) {
	  foreach ( $delivery_zone['shipping_methods'] as $key => $value ) {
		if ( $value->id === "free_shipping" ) {
		if ( $value->min_amount > 0 ) $min_amounts[] = $value->min_amount;
		}
	  }
	}
	 
	// Find lowest min_amount
	 
	if ( is_array($min_amounts) ) {
	 
		$min_amount = min($min_amounts);
		 
		// Get Cart Subtotal inc. Tax excl. Shipping
		 
		$current = WC()->cart->subtotal;
		 
		// If Subtotal < Min Amount Echo Notice
		// and add "Continue Shopping" button
		 
		if ( $current < $min_amount ) {
			$added_text = esc_html__('Spend an additional ', 'woocommerce' ) . wc_price( $min_amount - $current ) . esc_html__(', and get free shipping.', 'woocommerce' );
			$return_to = apply_filters( 'woocommerce_continue_shopping_redirect', wc_get_raw_referer() ? wp_validate_redirect( wc_get_raw_referer(), false ) : wc_get_page_permalink( 'shop' ) );
			$notice = sprintf( '<a href="%s" class="button wc-forward">%s</a> %s', esc_url( $return_to ), esc_html__( 'Continue Shopping', 'woocommerce' ), $added_text );
			wc_print_notice( $notice, 'notice' );
		}elseif($current == 0){
			$added_text = esc_html__('Free shipping of orders over ', 'woocommerce' ) . wc_price( $min_amount );
			$return_to = apply_filters( 'woocommerce_continue_shopping_redirect', wc_get_raw_referer() ? wp_validate_redirect( wc_get_raw_referer(), false ) : wc_get_page_permalink( 'shop' ) );
			$notice = sprintf( '<a href="%s" class="button wc-forward">%s</a> %s', esc_url( $return_to ), esc_html__( 'Continue Shopping', 'woocommerce' ), $added_text );
			wc_print_notice( $notice, 'notice' );
		}elseif($current >= $min_amount){
			$added_text = esc_html__('Congratulations, you will now receive free shipping for your order', 'woocommerce' );
			$return_to = apply_filters( 'woocommerce_continue_shopping_redirect', wc_get_raw_referer() ? wp_validate_redirect( wc_get_raw_referer(), false ) : wc_get_page_permalink( 'shop' ) );
			$notice = sprintf( '<a href="%s" class="button wc-forward">%s</a> %s', esc_url( $return_to ), esc_html__( 'Continue Shopping', 'woocommerce' ), $added_text );
			wc_print_notice( $notice, 'notice' );
		}
	 
	}
 
}
add_action( 'woocommerce_before_cart', 'jva_free_shipping_cart_notice_zones' );

/**
* @snippet Notice with $$$ remaining to Free Shipping @ WooCommerce Mini Cart
*/
 
function jva_mini_cart_notice() {
 
	// Get Min Amount from Woo Settings
	$free_shipping_settings = get_option( 'woocommerce_free_shipping_settings' );
	$min_amount = $free_shipping_settings['min_amount']; 
	$min_amount = !empty($min_amount) ? $min_amount : '100';
	// Get Cart Subtotal inc. Tax
	$current = WC()->cart->subtotal;
	 
	// If Subtotal < Min Amount Echo Notice
	if ( $current < $min_amount ) {
		echo '<div class="woocommerce-message">Spend an additional ' . wc_price( $min_amount - $current ) . ', and get free shipping.</div>';
	}elseif($current == 0){
		echo '<div class="woocommerce-message">Free shipping of orders over ' . wc_price( $min_amount ) . '</div>';
	}elseif($current >= $min_amount){
		echo '<div class="woocommerce-message">Congratulations, you will now receive free shipping for your order</div>';
	}
}
add_action( 'woocommerce_before_mini_cart', 'jva_mini_cart_notice' );

/**
* @snippet Banner at the top of the page
*/
 
function jva_freeshipping_banner() {
 
	// Get Min Amount from Woo Settings
	$free_shipping_settings = get_option( 'woocommerce_free_shipping_settings' );
	$min_amount = $free_shipping_settings['min_amount']; 
	$min_amount = !empty($min_amount) ? $min_amount : '100';
	// Get Cart Subtotal inc. Tax
	$current = WC()->cart->subtotal;
	 
	// If Subtotal < Min Amount Echo Notice
	?>
		<div id="jva-shipping-notice" class="woocommerce">
			<div class="jva-top-message" style="display: block;">
				<?php 
				if(($current < $min_amount) || ($current == 0)){
					echo $current < $min_amount ? 'Spend an additional '. wc_price($min_amount - $current) .', and get free shipping.' : 'Free shipping of orders over '. wc_price($min_amount);
				}elseif($current > $min_amount){
				 
					echo 'Congratulations, you will now receive free shipping for your order';
				}
				?>
			</div>
		</div>
	<?php
// 	if ( $current < $min_amount ) {
// 		echo '<style>.jva-top-message { position: absolute; bottom: -33px; right: 0px; width: auto; text-align: center; padding: 5px 25px; background: #2ea3f2; color: #fff; }</style>';
// 		echo '<div class="jva-top-message">Spend an additional ' . wc_price( $min_amount - $current ) . ', and get free shipping.</div>';
// 	}elseif($current == 0){
// 		echo '<style>.jva-top-message { position: absolute; bottom: -33px; right: 0px; width: auto; text-align: center; padding: 5px 25px; background: #2ea3f2; color: #fff; }</style>';
// 		echo '<div class="jva-top-message">Free shipping of orders over ' . wc_price( $min_amount ) . '</div>';
// 	}
}
add_action( 'jva_banner_hook', 'jva_freeshipping_banner' );


if( !function_exists('jvaPackageRates') ) :
	add_filter('woocommerce_package_rates', 'jvaPackageRates', 10, 2);
	function jvaPackageRates($rates) {
		$free = [];
		
		foreach($rates as $rateID => $rate) :
			if( 'free_shipping' === $rate->method_id ) :
				$free[$rateID] = $rate;
				break;
			endif;
		endforeach;
		
		return !empty($free) ? $free : $rates;
	}
endif;