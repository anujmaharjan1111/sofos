<?php
/**
 * Create metaboxes for the ritzfit post type
 *
 * This file is used to manage the metaboxes used in (product) post type.
 *
 * @link       https://wpali.com
 * @since      1.0.0
 *
 * @package    Wpali_Ritzfit_Coupons_Management
 * @subpackage Wpali_Ritzfit_Coupons_Management/includes */
// Import CMB2-Trunk version 
if ( file_exists( dirname( __FILE__ ) . '/CMB2/init.php' ) ) {
	require_once dirname( __FILE__ ) . '/CMB2/init.php';
} elseif ( file_exists( dirname( __FILE__ ) . '/CMB2/init.php' ) ) {
	require_once dirname( __FILE__ ) . '/CMB2/init.php';
}

/**
 * Register metabox on publications on product post-type.
 */
function jva_integration_metabox() {
	$prefix = "sushi_";
	
	$cmb_phcc = new_cmb2_box( array(
		'id'           => $prefix . 'metabox',
		'title'        =>  __( 'Shop Details', 'jva-functions' ),
		'object_types' => array( 'shops' ),
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true,
	) );
	

}
add_action( 'cmb2_admin_init', 'jva_integration_metabox' );
