<?php
/**
 * @wordpress-plugin
 * Plugin Name:       JVA & SwiftPOS Integration
 * Plugin URI:        https://professionalwebsolutions.com.au
 * Description:       Custom integration with SwiftPOS
 * Version:           1.0.0
 * Author:            PWS
 * Author URI:        https://professionalwebsolutions.com.au
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       jva-functions
 * Domain Path:       /languages
 */
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}
define( 'JVA_PLUGIN', '1.0.0' );
/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-jva-swiftpos-integration.php';
register_activation_hook( __FILE__, array( 'JVA__Functions', 'jvai_on_plugin_activation_tasks' ) );

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function Run_JVA__Functions() {
	$plugin = new JVA__Functions();
}
Run_JVA__Functions();