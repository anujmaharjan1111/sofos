<?php
/**
 * @wordpress-plugin
 * Plugin Name:       JVA & SwiftPOS Integration
 * Plugin URI:        https://professionalwebsolutions.com.au
 * Description:       Custom integration with SwiftPOS
 * Version:           1.0.0
 * Author:            PWS
 * Author URI:        https://professionalwebsolutions.com.au
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       jva-functions
 * Domain Path:       /languages
 */
// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
	die;
}
define( 'JVA_PLUGIN', '1.0.0' );
define( 'PLUGIN_BASE_PATH' , plugin_dir_path( __FILE__ ) );
define( 'PLUGIN_BASE_URL' , plugin_dir_url( __FILE__ ) );


if(file_exists(PLUGIN_BASE_PATH . 'includes/classes/class-jva-swiftpos-main-integration.php')){
	require PLUGIN_BASE_PATH . 'includes/classes/class-jva-swiftpos-main-integration.php';
	// register_activation_hook( __FILE__, array( 'JVA__Functions', 'jvai_on_plugin_activation_tasks' ) );
	$plugin = new jva_swiftpos_main_integration();
}